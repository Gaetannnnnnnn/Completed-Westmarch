// ============================================================
// accessibility.js — Accessibilité & confort d'interface
//
// Réimplémentation MAISON (aucune reprise de code tiers) de quelques
// idées d'ergonomie popularisées par des modules d'UI, orientées
// ACCESSIBILITÉ — notamment pour les joueurs daltoniens.
//
// Tous les réglages sont « user » (par COMPTE, pas par navigateur) : chaque joueur
// choisit ses propres options via une fenêtre « Accessibilité »
// accessible à tout le monde (restricted:false).
//
//   1. Daltonisme  — filtre de CORRECTION (daltonisation) appliqué à
//      l'interface et à la carte : protanopie / deutéranopie /
//      tritanopie. Redistribue l'information de couleur perdue vers des
//      canaux perceptibles (algorithme de daltonisation classique,
//      implémenté en filtre SVG feColorMatrix + feComposite).
//   2. Fort contraste — renforce texte, bordures et fonds de l'UI.
//   3. Avatars des joueurs — miniature du portrait dans la liste.
//   4. Auto-masquage — fond d'écran des contrôles/nav/macros/joueurs
//      estompés tant que la souris ne les survole pas.
//   5. Contrôles compacts — barre d'outils de gauche réduite.
//   6. Health Estimate — chaque joueur choisit s'il voit ou non l'état de
//      santé estimé des tokens (module « Health Estimate », s'il est actif).
//      Le module tiers reste actif pour la table : on coupe seulement son
//      affichage sur ce client.
//
// © 2026 Soruta.
// ============================================================

import { MOD } from "./const.js";
import { rafraichirFiches } from "./gere.js";

import { journal } from "./log.js";
import { tl } from "./i18n.js";
import { K_FUN, ouvrirTableau } from "./funnystats.js";
// Clés de réglages (toutes "client").
const K_DALTON   = "a11yDaltonism";      // "none" | "protan" | "deutan" | "tritan"
const K_CONTRAST = "a11yContrast";        // Boolean
const K_CONTRASTCOL = "a11yContrastColor"; // String (couleur des contours)
const K_AVATARS  = "a11yPlayerAvatars";   // Boolean
const K_AUTOHIDE = "a11yAutoHide";        // Boolean
const K_COMPACT  = "a11yCompactControls"; // Boolean
const K_GERE     = "a11yManagedBadge";    // Boolean (ancien : indicateur « géré par le module », plus affiché)
const K_CACHEICO = "a11yHideModuleIcons"; // Boolean (cacher les icônes « géré / modifié par le module »)
const K_HEALTH   = "a11yHealthEstimate";  // Boolean (afficher Health Estimate)
const K_PCLOCK   = "a11yPartyClock";      // Boolean (afficher l'horloge de la party, partytime.js)

const DEFAULT_BORDER = "#ffd54a";

const DALTON_CHOICES = {
    none:   tl("Aucun (couleurs normales)"),
    protan: tl("Protanopie (rouge)"),
    deutan: tl("Deutéranopie (vert)"),
    tritan: tl("Tritanopie (bleu)")
};

const _get = (k) => { try { return game.settings.get(MOD, k); } catch { return undefined; } };

// ── Réglages ────────────────────────────────────────────────
function registerA11ySettings() {
    game.settings.register(MOD, K_DALTON, {
        name: tl("Mode daltonisme"), scope: "user", config: false,
        type: String, choices: DALTON_CHOICES, default: "none",
        onChange: applyAccessibility
    });
    game.settings.register(MOD, K_CONTRAST, {
        name: tl("Fort contraste"), scope: "user", config: false,
        type: Boolean, default: false, onChange: applyAccessibility
    });
    game.settings.register(MOD, K_CONTRASTCOL, {
        name: tl("Couleur des contours (fort contraste)"), scope: "user", config: false,
        type: String, default: DEFAULT_BORDER, onChange: applyAccessibility
    });
    game.settings.register(MOD, K_AVATARS, {
        name: tl("Avatars dans la liste des joueurs"), scope: "user", config: false,
        type: Boolean, default: true, onChange: () => { applyAccessibility(); try { ui.players?.render(); } catch {} }
    });
    game.settings.register(MOD, K_AUTOHIDE, {
        name: tl("Auto-masquage de l'interface"), scope: "user", config: false,
        type: Boolean, default: true, onChange: applyAccessibility
    });
    game.settings.register(MOD, K_GERE, {
        name: tl("Indicateur « géré par le module »"), scope: "user", config: false,
        type: Boolean, default: true, onChange: () => rafraichirFiches()
    });
    game.settings.register(MOD, K_CACHEICO, {
        name: tl("Cacher les icônes du module sur la fiche"), scope: "user", config: false,
        type: Boolean, default: false, onChange: () => rafraichirFiches()
    });
    game.settings.register(MOD, K_HEALTH, {
        name: tl("Afficher l'état de santé estimé (Health Estimate)"), scope: "user", config: false,
        type: Boolean, default: true, onChange: () => applyHealthEstimate()
    });
    game.settings.register(MOD, K_PCLOCK, {
        name: tl("Afficher l'horloge de la party"), scope: "user", config: false,
        type: Boolean, default: true
    });
    game.settings.register(MOD, K_COMPACT, {
        name: tl("Contrôles de gauche compacts"), scope: "user", config: false,
        type: Boolean, default: true, onChange: applyAccessibility
    });
}

// ── Menu « Accessibilité » (visible par tous les joueurs) ────
function registerA11yMenu() {
    try {
        game.settings.registerMenu(MOD, "menu-accessibility", {
            name:  tl("Accessibilité"),
            label: tl("Ouvrir"),
            hint:  tl("Options personnelles : daltonisme, contraste, avatars, auto-masquage, contrôles compacts, Health Estimate. Chaque joueur règle les siennes."),
            icon:  "fas fa-universal-access",
            type:  class extends foundry.applications.api.ApplicationV2 {
                static DEFAULT_OPTIONS = { id: "scwm-menu-accessibility", window: { title: tl("Accessibilité") } };
                async render() { openA11yDialog(); return this; }
                async close()  { return this; }
            },
            restricted: false
        });
    } catch (e) {
        journal.critique(tl("[{0}] registerMenu « Accessibilité » échec :", MOD), e);
    }
}

export async function openA11yDialog() {
    const uid = "scwm-a11y-form";
    // Idempotent : si la fenêtre est déjà ouverte (ex. tutoriel), ne pas en
    // rouvrir une seconde par-dessus.
    if (document.getElementById(uid)) return;
    const dalton = _get(K_DALTON) ?? "none";
    const opts = Object.entries(DALTON_CHOICES)
        .map(([v, lbl]) => `<option value="${v}" ${dalton === v ? "selected" : ""}>${lbl}</option>`).join("");

    const row = (key, label, hint, rowKey) => `
        <div class="scwm-a11y-row" data-a11y-row="${rowKey ?? key}" style="padding:8px 4px;border-bottom:1px solid rgba(255,255,255,0.07);">
            <label style="display:flex;align-items:center;justify-content:space-between;gap:12px;cursor:pointer;font-weight:600;margin:0;">
                <span>${label}</span>
                <input type="checkbox" name="${key}" ${_get(key) ? "checked" : ""} style="width:18px;height:18px;flex-shrink:0;">
            </label>
            <p style="margin:3px 0 0;font-size:.8em;color:#999;">${hint}</p>
        </div>`;

    const content = `
    <div id="${uid}" style="display:flex;flex-direction:column;max-height:62vh;overflow-y:auto;padding-right:4px;">
        <div style="display:flex;align-items:center;gap:8px;margin:0 0 8px;padding:7px 10px;
                    border:1px solid rgba(201,162,39,0.5);border-radius:5px;
                    background:linear-gradient(180deg,rgba(201,162,39,0.12),rgba(0,0,0,0.15));">
            <i class="fa-solid fa-universal-access" style="color:#c9a227;font-size:16px;"></i>
            <div style="font-size:.82em;line-height:1.4;color:#d8cfa8;">
                ${tl("<strong>Options d'accessibilité</strong><br>\n                Personnelles à ton compte : elles n'affectent que ton affichage.")}
            </div>
        </div>

        <div data-a11y-row="dalton" style="padding:8px 4px;border-bottom:1px solid rgba(255,255,255,0.07);">
            <label style="display:block;font-weight:600;margin:0 0 4px;">${tl("Mode daltonisme")}</label>
            <select name="${K_DALTON}" style="width:100%;">${opts}</select>
            <p style="margin:4px 0 0;font-size:.8em;color:#999;">
                ${tl("Applique un filtre de correction des couleurs sur l'interface et la carte,\n                pour mieux distinguer les teintes selon ton type de vision.")}
            </p>
        </div>

        ${row(K_CONTRAST, tl("Fort contraste"), tl("Renforce le contraste du texte, des bordures et des fonds de l'interface."), "contrast")}
        <div class="scwm-a11y-row" data-a11y-row="contrastcol" style="padding:8px 4px;border-bottom:1px solid rgba(255,255,255,0.07);">
            <label style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin:0;font-weight:600;">
                <span>${tl("Couleur des contours")}</span>
                <span style="display:inline-flex;align-items:center;gap:6px;">
                    <input type="color" name="${K_CONTRASTCOL}" value="${_get(K_CONTRASTCOL) || DEFAULT_BORDER}"
                           style="width:42px;height:26px;padding:0;border:none;background:none;cursor:pointer;">
                    ${tl("<a class=\"scwm-a11y-col-reset\" style=\"font-size:.8em;color:#c9a227;cursor:pointer;\">réinit.</a>")}
                </span>
            </label>
            <p style="margin:3px 0 0;font-size:.8em;color:#999;">${tl("Couleur des bordures et du contour de focus en mode fort contraste (jaune par défaut).")}</p>
        </div>
        ${row(K_AVATARS,  tl("Avatars dans la liste des joueurs"), tl("Affiche la miniature du portrait de chaque joueur à côté de son nom."), "avatars")}
        ${row(K_AUTOHIDE, tl("Auto-masquage de l'interface"), tl("Estompe contrôles, navigation, macros et liste des joueurs tant que la souris ne les survole pas."), "autohide")}
        ${row(K_COMPACT,  tl("Contrôles de gauche compacts"), tl("Réduit la taille des icônes de la barre d'outils de gauche."), "compact")}
        ${healthEstimateActive() ? row(K_HEALTH, tl("Afficher l'état de santé estimé"), tl("Texte du module Health Estimate au survol des tokens (« Blessé », « Mal en point »…). Décoche pour ne plus le voir sur ton compte ; les autres joueurs gardent leur propre choix."), "health") : ""}
        ${partyClockOffered() ? row(K_PCLOCK, tl("Afficher l'horloge de la party"), tl("Horloge à droite de la liste des joueurs (avec les secondes) : heure de ta party pendant l'expédition, sinon celle du monde."), "partyclock") : ""}
        ${row(K_CACHEICO, tl("Cacher les icônes du module sur la fiche"), tl("Masque les petites icônes d'engrenages ⚙ de ta fiche : « géré par le module » (Healer, Alert, Large Form…), « modifié par le module » (dés du moine, Tavern Brawler…) et règles de poids sur la barre d'encombrement. Les règles restent appliquées, seules les icônes disparaissent. Décoché par défaut."), "gere")}

        <div style="margin:10px 0 4px;font-weight:700;color:#c9a227;font-size:.9em;">${tl("Divertissement")}</div>
        ${row(K_FUN, tl("FunnyStats — tableau de fin de combat"), tl("À la fin de chaque combat, ouvre un tableau des stats de tout le monde (dégâts infligés et reçus, soins, éliminations, critiques…) avec des titres, façon fin de partie. <a class=\"scwm-fun-voir\" style=\"color:#c9a227;cursor:pointer;\">Voir le dernier tableau</a>"), "funnystats")}

    </div>`;

    await foundry.applications.api.DialogV2.wait({
        window:      { title: tl("Accessibilité"), icon: "fas fa-universal-access" },
        position:    { width: 520 },
        rejectClose: false,
        content,
        render: () => {
            const root = document.getElementById(uid);
            root?.querySelector(".scwm-a11y-col-reset")?.addEventListener("click", (e) => {
                e.preventDefault();
                const inp = root.querySelector(`[name="${K_CONTRASTCOL}"]`);
                if (inp) inp.value = DEFAULT_BORDER;
            });
            root?.querySelector(".scwm-fun-voir")?.addEventListener("click", (e) => { e.preventDefault(); ouvrirTableau(); });
        },
        buttons: [
            {
                action: "save", default: true,
                label: tl("Enregistrer"), icon: '<i class="fa-solid fa-save"></i>',
                callback: async (ev, btn) => {
                    const root = btn.form ?? document.getElementById(uid);
                    if (!root) return;
                    const sel = root.querySelector(`[name="${K_DALTON}"]`);
                    await game.settings.set(MOD, K_DALTON, sel?.value ?? "none");
                    const col = root.querySelector(`[name="${K_CONTRASTCOL}"]`);
                    await game.settings.set(MOD, K_CONTRASTCOL, col?.value || DEFAULT_BORDER);
                    for (const k of [K_CONTRAST, K_AVATARS, K_AUTOHIDE, K_COMPACT, K_CACHEICO, K_FUN]) {
                        const cb = root.querySelector(`[name="${k}"]`);
                        await game.settings.set(MOD, k, !!cb?.checked);
                    }
                    // Health Estimate : la case n'existe que si le module est actif.
                    const he = root.querySelector(`[name="${K_HEALTH}"]`);
                    if (he) await game.settings.set(MOD, K_HEALTH, !!he.checked);
                    const pc = root.querySelector(`[name="${K_PCLOCK}"]`);
                    if (pc) await game.settings.set(MOD, K_PCLOCK, !!pc.checked);

                    applyAccessibility();
                    try { ui.players?.render(); } catch {}
                }
            },
            { action: "close", label: tl("Fermer"), icon: '<i class="fa-solid fa-xmark"></i>', callback: () => {} }
        ]
    });
}

// ── Daltonisation de la SCÈNE via un filtre PIXI ────────────
// Un filtre CSS url() sur le canvas WebGL de Foundry est ignoré par le
// navigateur. On applique donc un PIXI.ColorMatrixFilter sur le stage du
// canvas. La matrice est la daltonisation (correction) précalculée en une
// seule matrice linéaire : M = I + Shift·(I − Sim), où Sim simule la
// déficience et Shift redistribue l'information de couleur perdue vers des
// canaux perceptibles. Format PIXI : 4 lignes (R,G,B,A) × 5 colonnes
// (r, g, b, a, offset).
const DALTON_MATRIX = {
    protan: [
        1,       0,       0,     0, 0,
       -0.2549,  1.2549,  0,     0, 0,
        0.3031, -0.5451,  1.242, 0, 0,
        0,       0,       0,     1, 0
    ],
    deutan: [
        1,       0,       0,   0, 0,
       -0.4375,  1.4375,  0,   0, 0,
        0.2625, -0.5625,  1.3, 0, 0,
        0,       0,       0,   1, 0
    ],
    tritan: [
        1.05, -0.3825,  0.3325, 0, 0,
        0,     1.2345, -0.2345, 0, 0,
        0,     0,       1,      0, 0,
        0,     0,       0,      1, 0
    ]
};

// Applique (ou retire) le filtre de daltonisation sur le canvas de la scène.
function applyCanvasDaltonism() {
    const stage = canvas?.stage;
    const app   = canvas?.app;
    if (!stage || !app) return;   // canvas pas encore prêt

    // Retire notre éventuel filtre précédent.
    const others = (stage.filters ?? []).filter(f => !f?._scwmDalton);

    const mode = _get(K_DALTON) ?? "none";
    const matrix = DALTON_MATRIX[mode];
    if (!matrix) {                 // « none » ou valeur inconnue → on nettoie
        stage.filters = others.length ? others : null;
        return;
    }

    const CMF = globalThis.PIXI?.filters?.ColorMatrixFilter ?? globalThis.PIXI?.ColorMatrixFilter;
    if (!CMF) { journal.avert(tl("[{0}] PIXI.ColorMatrixFilter indisponible : daltonisme non appliqué.", MOD)); return; }

    try {
        const f = new CMF();
        f.matrix = matrix.slice();
        f._scwmDalton = true;
        stage.filters = [...others, f];
        // Zone de filtre = tout l'écran de rendu (sinon le filtre suit le stage
        // qui se déplace/zoome et ne couvre pas le viewport).
        stage.filterArea = app.renderer.screen;
    } catch (e) {
        journal.erreur(tl("[{0}] Application du filtre daltonisme :", MOD), e);
    }
}

// ── Daltonisation de l'INTERFACE (DOM) via un filtre SVG ────
// Complète le filtre PIXI du canvas : mêmes matrices, mais appliquées à l'UI
// (fenêtres, fiches, chat, barres) via `filter: url(#…)`. On ne touche PAS au
// canvas ici (#board) — il a déjà son filtre PIXI (sinon double correction).
function ensureDaltonSvg() {
    if (document.getElementById("scwm-dalton-svg")) return;
    const filt = (id, m) =>
        `<filter id="${id}" color-interpolation-filters="sRGB"><feColorMatrix type="matrix" values="${m.join(" ")}"/></filter>`;
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.id = "scwm-dalton-svg";
    svg.setAttribute("aria-hidden", "true");
    svg.style.cssText = "position:absolute;width:0;height:0;overflow:hidden;pointer-events:none;";
    svg.innerHTML = `<defs>${filt("scwm-dalton-protan", DALTON_MATRIX.protan)}${filt("scwm-dalton-deutan", DALTON_MATRIX.deutan)}${filt("scwm-dalton-tritan", DALTON_MATRIX.tritan)}</defs>`;
    document.body.appendChild(svg);
}

// Éléments d'UI ciblés (jamais le canvas #board / #ui-middle).
const DALTON_UI_SEL = "#sidebar, #ui-left, #ui-right, #ui-top, #ui-bottom, #players, #hotbar, #controls, #navigation, #hud, #chat-notifications, #camera-views, .application, .app, #tooltip, #context-menu, aside.notifications, .notifications, #pause";
const DALTON_UI_CSS = `
body.scwm-a11y-dalton-protan :is(${DALTON_UI_SEL}) { filter: url(#scwm-dalton-protan); }
body.scwm-a11y-dalton-deutan :is(${DALTON_UI_SEL}) { filter: url(#scwm-dalton-deutan); }
body.scwm-a11y-dalton-tritan :is(${DALTON_UI_SEL}) { filter: url(#scwm-dalton-tritan); }
`;
function ensureDaltonUiCss() {
    let st = document.getElementById("scwm-dalton-ui-style");
    if (!st) { st = document.createElement("style"); st.id = "scwm-dalton-ui-style"; document.head.appendChild(st); }
    if (st.textContent !== DALTON_UI_CSS) st.textContent = DALTON_UI_CSS;
}

// Pose/retire les classes body qui déclenchent le filtre UI selon le mode.
function applyUiDaltonism() {
    const body = document.body;
    if (!body) return;
    ensureDaltonSvg();
    ensureDaltonUiCss();
    const mode = _get(K_DALTON) ?? "none";
    for (const m of ["protan", "deutan", "tritan"]) {
        body.classList.toggle(`scwm-a11y-dalton-${m}`, mode === m);
    }
}

// ── Avatars dans la liste des joueurs ───────────────────────
function decoratePlayers(root) {
    if (!_get(K_AVATARS)) return;
    const host = root instanceof HTMLElement ? root : document.getElementById("players");
    if (!host) return;
    host.querySelectorAll("[data-user-id]").forEach(row => {
        if (row.closest(".scwm-player-search")) return;
        if (row.querySelector(".scwm-player-avatar")) return;
        const uid = row.getAttribute("data-user-id");
        const user = game.users?.get(uid);
        if (!user) return;
        const src = user.character?.img || user.avatar || "icons/svg/mystery-man.svg";
        const img = document.createElement("img");
        img.className = "scwm-player-avatar";
        img.src = src;
        img.alt = "";
        // Insérer avant le nom (premier enfant utile de la ligne).
        const nameEl = row.querySelector(".player-name, .player-active, h3, .name") ?? row.firstElementChild;
        if (nameEl && nameEl.parentElement === row) row.insertBefore(img, nameEl);
        else row.insertBefore(img, row.firstChild);
    });
}

// ── Health Estimate (par joueur) ────────────────────────────
// Le module « Health Estimate » est activé pour tout le monde (réglage de
// monde). Pour qu'un joueur puisse s'en passer sur SON compte, on remplace
// sur ce client la méthode d'affichage de l'instance (game.healthEstimate.
// _handleOverlay) par une fonction vide, et on masque son calque PIXI.
// Toutes ses mises à jour passent par cette méthode (survol, combat,
// changement de PV) : rien ne s'affiche plus. Recocher la case supprime la
// surcharge et la méthode d'origine (celle de la classe) reprend la main.
// L'horloge de la party n'est proposée que si le MJ l'a activée.
function partyClockOffered() {
    try {
        return !!game.settings.get(MOD, "enableParty") && !!game.settings.get(MOD, "enablePartyTime")
            && game.settings.get(MOD, "partyTimeShowClock") !== false;
    } catch { return false; }
}

function healthEstimateActive() {
    return !!game.modules?.get("healthEstimate")?.active;
}

function applyHealthEstimate() {
    const he = game.healthEstimate;
    if (!healthEstimateActive() || !he) return;
    const show = _get(K_HEALTH) !== false;
    try {
        if (!show && !Object.hasOwn(he, "_handleOverlay")) {
            he.clearOverlays?.();                    // retire les textes déjà affichés
            he._handleOverlay = function () {};      // plus rien ne s'affiche sur ce client
        } else if (show && Object.hasOwn(he, "_handleOverlay")) {
            delete he._handleOverlay;                // retour à la méthode du module
        }
        const layer = canvas?.interface?.healthEstimate;
        if (layer) layer.visible = show;
    } catch (e) {
        journal.avert(tl("[{0}] Health Estimate : préférence d'affichage non appliquée.", MOD), e);
    }
}

// ── Application des classes/état sur le <body> ──────────────
export function applyAccessibility() {
    const body = document.body;
    if (!body) return;

    // Daltonisme : filtre PIXI sur la scène + filtre SVG sur l'interface.
    applyCanvasDaltonism();
    applyUiDaltonism();

    body.classList.toggle("scwm-a11y-contrast", !!_get(K_CONTRAST));
    body.classList.toggle("scwm-a11y-autohide", !!_get(K_AUTOHIDE));
    body.classList.toggle("scwm-a11y-compact",  !!_get(K_COMPACT));

    // Couleur des contours du mode fort contraste (variable CSS lue par le CSS).
    body.style.setProperty("--scwm-a11y-border", _get(K_CONTRASTCOL) || DEFAULT_BORDER);

    try { decoratePlayers(document.getElementById("players")); } catch {}
    applyHealthEstimate();
}

// ── Hooks ───────────────────────────────────────────────────
export function AccessibilityHooks() {
    registerA11ySettings();
    registerA11yMenu();

    Hooks.once("ready", () => applyAccessibility());
    // Le stage du canvas est reconstruit à chaque (re)dessin de scène : on
    // réapplique alors le filtre de daltonisation.
    Hooks.on("canvasReady", () => { applyCanvasDaltonism(); applyHealthEstimate(); });
    // Réappliquer après chaque rendu de la liste des joueurs (Foundry la
    // reconstruit à chaque changement de statut de connexion).
    Hooks.on("renderPlayers", (app, html) => {
        const root = html instanceof HTMLElement ? html : html?.[0];
        applyAccessibility();
        decoratePlayers(root);
    });
    // La barre d'outils de gauche est reconstruite au changement de contrôle.
    Hooks.on("renderSceneControls", () => { if (_get(K_COMPACT) || _get(K_AUTOHIDE)) applyAccessibility(); });
}
