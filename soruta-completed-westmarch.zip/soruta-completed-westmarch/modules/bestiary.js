// ============================================================
// bestiary.js — Bestiaire personnel par personnage
//
// Stockage : flag scope MOD → "list" sur chaque acteur PJ
//            [ { id, targetId, targetName, targetImg,
//                hostility(-2→+2), note, firstScene, lastPosition,
//                ca (estimation), degats { type: faiblesse|resistance|immunite } } ]
// Interface : onglet "Bestiaire" sur la fiche personnage (PJ uniquement)
// Auto-det. : canvasReady / createToken / updateToken (GM only)
//             → créatures issues du compendium configuré (ou importées de celui-ci)
// © 2026 Soruta — Tous droits réservés. Usage personnel autorisé. Redistribution et modification interdites.
// ============================================================

import { MOD } from "./const.js";
import { journal } from "./log.js";
import { commonFolderPJ, commonPackCreatures } from "./settings.js";
import { jetonDuPersonnage, voit, surCarteExpedition, ouvrirImage, dateDeRencontre, memeRencontre, texteRencontre } from "./perception.js";
import { tl } from "./i18n.js";
export const MODULE = MOD;

// ---- État de session ---------------------------------------

const _expanded  = new Set();   // IDs d'entrées dont les notes sont ouvertes
let   _noteTimer = null;        // Debounce auto-save notes
let   _scanning  = false;       // Guard anti-doublon scan
let   _sightTimer = null;       // Debounce sightRefresh

// ---- Niveaux d'hostilité (-2 → +2) -------------------------

const HOSTILITY_CFG = {
    "-2": { icon: "fa-skull",              color: "#8b0000", label: tl("Très hostile") },
    "-1": { icon: "fa-fire",               color: "#e74c3c", label: "Hostile"      },
     "0": { icon: "fa-question",           color: "#888888", label: tl("Inconnue")     },
     "1": { icon: "fa-eye",                color: "#a8d5a2", label: tl("Observée")     },
     "2": { icon: "fa-handshake",          color: "#27ae60", label: tl("Amicale")      },
};

function hostilityIcon(h) {
    const cfg = HOSTILITY_CFG[String(h ?? 0)] ?? HOSTILITY_CFG["0"];
    return `<i class="fas ${cfg.icon}" style="color:${cfg.color};" title="${cfg.label}"></i>`;
}

function hostilitySelector(current, canEdit) {
    const cur = HOSTILITY_CFG[String(current ?? 0)] ?? HOSTILITY_CFG["0"];
    if (!canEdit) return `<div class="bst-hostility">${hostilityIcon(current)}</div>`;
    const btns = Object.entries(HOSTILITY_CFG)
        .sort(([a],[b]) => parseInt(a) - parseInt(b))
        .map(([h, cfg]) => {
            const active = parseInt(h) === (current ?? 0);
            const col    = active ? `style="color:${cfg.color};"` : "";
            return `<a class="bst-h-btn${active ? " active" : ""}" data-hostility="${h}" title="${cfg.label}">
                <i class="fas ${cfg.icon}" ${col}></i>
            </a>`;
        }).join("");
    return `<div class="bst-hostility-selector">
        <span class="bst-h-label" style="color:${cur.color};">${cur.label}</span>
        ${btns}
    </div>`;
}

// ---- Options (désactivables dans les réglages) -------------

const opt = (k) => { try { return game.settings.get(MOD, k) !== false; } catch { return true; } };
const escB = (s) => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

// Types de dégâts (identifiants dnd5e) et leur nom affiché.
const DEGATS = [
    ["acid", tl("Acide")], ["bludgeoning", tl("Contondant")], ["cold", tl("Froid")], ["fire", tl("Feu")],
    ["force", tl("Force")], ["lightning", tl("Foudre")], ["necrotic", tl("Nécrotique")], ["piercing", tl("Perforant")],
    ["poison", tl("Poison")], ["psychic", tl("Psychique")], ["radiant", tl("Radiant")], ["slashing", tl("Tranchant")],
    ["thunder", tl("Tonnerre")]
];
// Les 4 états d'une étiquette, dans l'ordre des clics. Chacun a sa forme :
// neutre = pointillés gris ; faiblesse = rouge, coins carrés ; résistance =
// bleu, arrondi ; immunité = doré, plein, en forme de pilule.
const ETATS_DEGATS = ["", "faiblesse", "resistance", "immunite"];
const STYLE_ETAT = {
    "":          { icon: "",                   label: tl("non noté"),   css: "border:1px dashed rgba(255,255,255,.25);color:#888;background:transparent;border-radius:3px;" },
    faiblesse:   { icon: "fa-heart-crack",     label: tl("Faiblesse"),  css: "border:1px solid #c0392b;color:#ff8a7a;background:rgba(192,57,43,.18);border-radius:0;" },
    resistance:  { icon: "fa-shield-halved",   label: tl("Résistance"), css: "border:1px solid #2e86c1;color:#8cc8f0;background:rgba(46,134,193,.18);border-radius:6px;" },
    immunite:    { icon: "fa-shield",          label: tl("Immunité"),   css: "border:1px solid #c9a227;color:#1b1406;background:#c9a227;border-radius:999px;font-weight:700;" }
};
const etatSuivant = (e) => ETATS_DEGATS[(ETATS_DEGATS.indexOf(e ?? "") + 1) % ETATS_DEGATS.length];

function etiquetteDegatHtml(cle, nom, etat, canEdit) {
    const st = STYLE_ETAT[etat ?? ""] ?? STYLE_ETAT[""];
    const titre = canEdit ? tl("{0} : {1} (cliquer pour changer)", nom, st.label) : `${nom} : ${st.label}`;
    return `<a class="bst-dmg${canEdit ? " bst-dmg-edit" : ""}" data-dmg="${cle}" data-etat="${etat ?? ""}" title="${escB(titre)}"
        style="display:inline-flex;align-items:center;gap:3px;padding:1px 6px;margin:2px;font-size:11px;line-height:16px;cursor:${canEdit ? "pointer" : "default"};user-select:none;${st.css}">${st.icon ? `<i class="fa-solid ${st.icon}" style="font-size:9px;"></i>` : ""}${escB(nom)}</a>`;
}

// Ordre d'affichage : faiblesses, puis résistances, puis immunités, puis les
// types non notés ; ordre alphabétique (nom affiché) dans chaque groupe.
const ORDRE_ETAT = { faiblesse: 0, resistance: 1, immunite: 2, "": 3 };
function degatsTries(d) {
    return DEGATS.slice().sort(([ka, na], [kb, nb]) =>
        (ORDRE_ETAT[d[ka] ?? ""] - ORDRE_ETAT[d[kb] ?? ""]) || na.localeCompare(nb, "fr"));
}
function listeDegatsHtml(entry, canEdit) {
    const d = entry.degats ?? {};
    const liste = degatsTries(d).filter(([k]) => canEdit || d[k]);
    return liste.length ? liste.map(([k, nom]) => etiquetteDegatHtml(k, nom, d[k], canEdit)).join("") : `${tl("<em style=\"font-size:11px;opacity:.7;\">Rien de noté.</em>")}`;
}

function blocDegatsHtml(entry, canEdit) {
    const legende = `<span style="font-size:10px;opacity:.65;margin-left:4px;">
        ${tl("<i class=\"fa-solid fa-heart-crack\" style=\"color:#ff8a7a;\"></i> faiblesse ·\n        <i class=\"fa-solid fa-shield-halved\" style=\"color:#8cc8f0;\"></i> résistance ·\n        <i class=\"fa-solid fa-shield\" style=\"color:#c9a227;\"></i> immunité")}</span>`;
    return `<div class="bst-dmg-row" style="margin:6px 0;">
        <div style="display:flex;align-items:center;gap:6px;"><i class="fa-solid fa-burst"></i>
            <span class="bst-field-label">${tl("Dégâts :")}</span>${legende}</div>
        <div class="bst-dmg-list" data-bst-id="${entry.id}" style="display:flex;flex-wrap:wrap;margin-top:2px;transition:opacity .15s;">
            ${listeDegatsHtml(entry, canEdit)}
        </div>
    </div>`;
}

// Classe d'armure estimée par le joueur.
const CA_NIVEAUX = [
    ["", "— inconnue —"], ["tres-faible", tl("Très faible (13 ou moins)")], ["faible", tl("Faible (14–15)")],
    ["moyenne", tl("Moyenne (16–17)")], ["elevee", tl("Élevée (18–19)")], ["tres-elevee", tl("Très élevée (20–21)")],
    ["extreme", tl("Extrême (22 ou plus)")]
];
// Jauge de CA : 6 barres de hauteur croissante, remplies jusqu'au niveau
// choisi (style du bestiaire, pas de liste déroulante native). Cliquer sur
// la barre déjà choisie remet « inconnue ».
function jaugeCaHtml(val, canEdit) {
    const niv = CA_NIVEAUX.findIndex(([k]) => k === val);   // 0 = inconnue
    const barres = CA_NIVEAUX.slice(1).map(([k, l], i) => {
        const rempli = niv > 0 && i + 1 <= niv;
        const h = 7 + i * 3;
        return `<a class="bst-ca-bar${canEdit ? " bst-ca-edit" : ""}" data-ca="${k}" title="${escB(l)}"
            style="display:inline-block;width:11px;height:${h}px;margin-right:3px;border-radius:2px 2px 0 0;cursor:${canEdit ? "pointer" : "default"};
                   background:${rempli ? "linear-gradient(180deg,#f0d27a,#c9a227)" : "rgba(255,255,255,0.08)"};
                   border:1px solid ${rempli ? "#c9a227" : "rgba(201,162,39,0.3)"};box-sizing:border-box;"></a>`;
    }).join("");
    const lib = niv > 0 ? CA_NIVEAUX[niv][1] : tl("Inconnue");
    return `<span class="bst-ca-jauge" style="display:inline-flex;align-items:flex-end;height:24px;">${barres}</span>
        <span class="bst-ca-label" style="font-size:12px;color:${niv > 0 ? "#e0c169" : "#888"};${niv > 0 ? "" : "font-style:italic;"}">${escB(lib)}</span>`;
}
function blocCaHtml(entry, canEdit) {
    return `<div class="bst-ca-row" data-bst-id="${entry.id}" style="display:flex;align-items:center;gap:8px;margin:6px 0;">
        <i class="fa-solid fa-shield-heart"></i>
        <span class="bst-field-label">${tl("CA :")}</span>
        ${jaugeCaHtml(entry.ca ?? "", canEdit)}
    </div>`;
}

// Dernière position : remplie automatiquement, jamais modifiable à la main.
function blocDernierePositionHtml(entry) {
    const val = escB(entry.lastPosition ?? entry.firstScene ?? "");
    return `<div class="bst-scene-row">
        <i class="fa-solid fa-location-crosshairs"></i>
        <span class="bst-field-label">${tl("Dernière position :")}</span>
        <span class="bst-scene-value bst-last-value" data-bst-id="${entry.id}" title="${tl("Mise à jour automatiquement quand le personnage revoit la créature")}">${val || `${tl("<em>Inconnue</em>")}`}</span>
    </div>`;
}

// Date de la dernière rencontre (automatique, non modifiable).
function blocDerniereRencontreHtml(entry) {
    const { texte, titre } = texteRencontre(entry.lastSeen);
    return `<div class="bst-scene-row">
        <i class="fa-solid fa-calendar-day"></i>
        <span class="bst-field-label">${tl("Dernière rencontre :")}</span>
        <span class="bst-scene-value bst-seen-value" data-bst-id="${entry.id}" title="${escB(titre)}">${texte ? escB(texte) : `${tl("<em>Inconnue</em>")}`}</span>
    </div>`;
}

// ---- CRUD --------------------------------------------------

function beastList(actor) {
    return actor.getFlag(MOD, "bestiaryList") ?? [];
}

async function beastSave(actor, list) {
    await actor.update({ [`flags.${MOD}.bestiaryList`]: list }, { render: false });
}

async function beastUpdate(actor, id, patch) {
    await beastSave(actor, beastList(actor).map(e => e.id === id ? { ...e, ...patch } : e));
}

async function beastDelete(actor, id) {
    await beastSave(actor, beastList(actor).filter(e => e.id !== id));
}

// ---- Helpers dossiers --------------------------------------

function isInFolder(actor, folderId) {
    if (!folderId) return false;
    let f = actor.folder;
    while (f) {
        if (f.id === folderId) return true;
        f = f.folder;
    }
    return false;
}
function isInPJFolder(actor) { return isInFolder(actor, commonFolderPJ()); }

// Créatures disponibles pour ajout manuel (compendium en priorité, sinon dossier monde)
async function availableCreatures(actor) {
    const existing = new Set(beastList(actor).map(e => e.targetId));
    const packId   = commonPackCreatures();
    const pack     = packId ? game.packs.get(packId) : null;
    if (!pack) return [];
    const docs = await pack.getDocuments();
    return docs
        .filter(a => !existing.has(a.id))
        .sort((a, b) => a.name.localeCompare(b.name));
}

// Index (noms) du compendium des créatures, mis en cache pour la détection.
let _creatureIndex = null;
let _creatureIndexPack = null;
async function ensureCreatureIndex() {
    const packId = commonPackCreatures();
    if (!packId) { _creatureIndex = null; _creatureIndexPack = null; return; }
    if (_creatureIndex && _creatureIndexPack === packId) return;
    const pack = game.packs.get(packId);
    if (!pack) { _creatureIndex = null; return; }
    try {
        const idx = await pack.getIndex();
        _creatureIndex = new Set(idx.map(e => e.name));
        _creatureIndexPack = packId;
    } catch (e) {
        journal.avert(tl("[Bestiaire] Index du compendium illisible :"), e);
        _creatureIndex = null;
    }
}

// Source COMPENDIUM d'un acteur : { pack, id } ou null. Permet de garder le lien
// même si l'acteur du monde est supprimé (le bestiaire reste correct).
function compendiumSourceOf(actor) {
    if (!actor) return null;
    const packId = commonPackCreatures();
    if (actor.pack && actor.id) return { pack: actor.pack, id: actor.id };   // déjà dans un compendium
    const src = actor._stats?.compendiumSource ?? actor.getFlag?.("core", "sourceId") ?? "";
    if (typeof src === "string") {
        const m = src.match(/^Compendium\.(.+)\.Actor\.([^.]+)$/);
        if (m) return { pack: m[1], id: m[2] };
    }
    if (packId) {   // repli : match par nom dans le compendium configuré
        const e = game.packs.get(packId)?.index?.find?.(x => x.name === actor.name);
        if (e) return { pack: packId, id: e._id };
    }
    return null;
}

// Résout (SYNCHRONE, via l'index déjà chargé) l'entrée compendium d'une entrée
// de bestiaire → { name, img, uuid } ou null.
function compendiumIndexEntry(entry) {
    if (!entry?.sourcePack || !entry?.sourceId) return null;
    const idx = game.packs.get(entry.sourcePack)?.index?.get?.(entry.sourceId);
    if (!idx) return null;
    return { name: idx.name, img: idx.img, uuid: `Compendium.${entry.sourcePack}.Actor.${entry.sourceId}` };
}

// Retourne true si le token est une créature du compendium configuré.
function isCreatureToken(token) {
    const actor = token.actor;
    if (!actor?.id) return false;
    const packId = commonPackCreatures();
    if (!packId) return false;
    // (1) token directement lié à un acteur du compendium
    if (actor.pack === packId) return true;
    // (2) acteur du monde importé depuis ce compendium (compendiumSource / sourceId)
    const src = actor._stats?.compendiumSource ?? actor.getFlag?.("core", "sourceId") ?? "";
    if (typeof src === "string" && src.startsWith(`Compendium.${packId}.`)) return true;
    // (3) repli : le nom de l'acteur correspond à une entrée du compendium
    if (_creatureIndex && _creatureIndex.has(actor.name)) return true;
    return false;
}

// ---- HTML onglet -------------------------------------------

function emptyStateHtml() {
    return `<div class="bst-empty">
        <i class="fa-solid fa-dragon"></i>
        <span>${tl("Aucune créature répertoriée.")}</span>
    </div>`;
}

function buildRowHtml(entry, actor, canEdit) {
    const target   = game.actors.get(entry.targetId);
    // Si l'acteur du monde n'existe plus, on retombe sur le COMPENDIUM (lien stable).
    const src      = target ? null : compendiumIndexEntry(entry);
    const revealed = entry.revealed ?? true;
    const img      = target?.img  ?? src?.img  ?? entry.targetImg  ?? "icons/svg/mystery-man.svg";
    const name     = revealed ? (target?.name ?? src?.name ?? entry.targetName ?? tl("Inconnue")) : tl("Inconnue");
    const open   = _expanded.has(entry.id);

    return `
    <div class="bst-row" data-bst-id="${entry.id}">
        <div class="bst-row-header">
            <img class="bst-avatar" src="${escB(img)}" alt="${escB(name)}">
            <span class="bst-name">${escB(name)}</span>
            ${hostilitySelector(entry.hostility ?? 0, canEdit)}
            <div class="bst-btns">
                ${game.user.isGM && (target || src) ? `<a class="bst-open-sheet" data-target-id="${entry.targetId}" data-source-uuid="${target ? "" : (src?.uuid ?? "")}" title="Ouvrir la fiche"><i class="fa-solid fa-external-link-alt"></i></a>` : ""}
                <a class="bst-toggle" title="${tl("Notes")}"><i class="fa-solid fa-chevron-${open ? "up" : "down"}"></i></a>
                ${canEdit ? `<a class="bst-delete" title="Retirer du bestiaire"><i class="fa-solid fa-trash"></i></a>` : ""}
            </div>
        </div>
        <div class="bst-notes"${open ? "" : ' style="display:none;"'}>
            <div class="bst-scene-row">
                <i class="fa-solid fa-map-marker-alt"></i>
                <span class="bst-field-label">${tl("Première rencontre :")}</span>
                <span class="bst-scene-value" title="${tl("Scène où le personnage a vu la créature pour la première fois")}">${escB(entry.firstScene ?? "") || `${tl("<em>Inconnue</em>")}`}</span>
            </div>
            ${opt("bestiaryLastPosition") ? blocDernierePositionHtml(entry) : ""}
            ${opt("bestiaryLastSeen") ? blocDerniereRencontreHtml(entry) : ""}
            ${opt("bestiaryArmorClass") ? blocCaHtml(entry, canEdit) : ""}
            ${opt("bestiaryDamageTags") ? blocDegatsHtml(entry, canEdit) : ""}
            ${canEdit ? `
            <textarea class="bst-note-input" data-bst-id="${entry.id}"
                placeholder="${tl("Notes sur cette créature…")}">${escB(entry.note)}</textarea>
            ` : `
            <p class="bst-note-ro" style="white-space:pre-wrap;">${entry.note ? escB(entry.note) : `${tl("<em>Aucune note.</em>")}`}</p>
            `}
        </div>
    </div>`;
}

export function buildTabHtml(actor) {
    const isGM    = game.user.isGM;
    const canEdit = isGM || actor.isOwner;

    // Tri : plus hostile en premier, puis alphabétique
    const list = beastList(actor).slice().sort((a, b) => {
        const hDiff = (a.hostility ?? 0) - (b.hostility ?? 0);
        return hDiff !== 0 ? hDiff : (a.targetName ?? "").localeCompare(b.targetName ?? "");
    });

    // Styles inline — contournement cache CSS Foundry
    const S = {
        titleBar:  `display:flex;align-items:center;justify-content:space-between;padding:9px 12px 7px;flex-shrink:0;background:linear-gradient(180deg,rgba(201,162,39,0.06),transparent);border-bottom:2px solid transparent;border-image:linear-gradient(90deg,transparent,rgba(201,162,39,0.55) 15%,rgba(201,162,39,0.55) 85%,transparent) 1;`,
        title:     `display:flex;align-items:center;gap:8px;font-size:17px;font-weight:700;text-transform:uppercase;letter-spacing:0.14em;color:#c9a227;font-family:'Modesto Condensed','Enchanted Land','Signika',serif;text-shadow:0 1px 2px rgba(0,0,0,0.6);`,
        addBtn:    `display:flex;align-items:center;gap:5px;padding:3px 9px;` +
                   `background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);border-radius:4px;` +
                   `color:#aaa;font-size:11px;cursor:pointer;white-space:nowrap;transition:background 0.12s,color 0.12s;`,
        searchBar: `display:flex;align-items:center;gap:6px;padding:6px 10px;flex-shrink:0;border-bottom:1px solid rgba(201,162,39,0.15);`,
        wrap:      `flex:1;display:flex;align-items:center;gap:6px;background:rgba(0,0,0,0.28);border:1px solid rgba(201,162,39,0.28);border-radius:4px;padding:5px 9px;`,
        srchIcon:  `color:#a8863a;font-size:12px;flex-shrink:0;`,
        srchInput: `flex:1;background:transparent;border:none;box-shadow:none;outline:none;color:#cbb98f;font-size:12px;padding:0;min-width:0;font-family:'Bookinsanity',Georgia,serif;`,
        clear:     `display:none;color:#444;font-size:10px;cursor:pointer;padding:2px 3px;`,
    };

    const rows = list.map(e => buildRowHtml(e, actor, canEdit)).join("");

    return `
    <div class="bst-tab" data-actor-id="${actor.id}">
        <div style="${S.titleBar}">
            <span style="${S.title}">
                ${tl("<i class=\"fa-solid fa-dragon\" style=\"color:#e0a13a;font-size:15px;filter:drop-shadow(0 1px 1px rgba(0,0,0,0.5));\"></i>\n                Bestiaire")}
            </span>
            ${isGM ? `${tl("<a class=\"bst-add-btn\">\n                <i class=\"fa-solid fa-plus\" style=\"font-size:10px;\"></i> Ajouter\n            </a>")}` : ""}
        </div>
        <div style="${S.searchBar}">
            <div class="bst-search-wrap" style="${S.wrap}">
                <i class="fa-solid fa-search" style="${S.srchIcon}"></i>
                <input class="bst-search-input" type="text"
                    placeholder="${tl("Rechercher une créature…")}" style="${S.srchInput}">
                <a class="bst-search-clear" style="${S.clear}" title="${tl("Effacer")}">
                    <i class="fa-solid fa-times"></i>
                </a>
            </div>
        </div>
        <div class="bst-list">
            ${rows || emptyStateHtml()}
        </div>
    </div>`;
}

// ---- Dialog ajout manuel (GM only) -------------------------

function buildCreaturePickerHtml(creatures, uid) {
    const rows = creatures.map(a => `
        <div class="bst-picker-actor" data-actor-id="${a.id}" data-name="${escB(a.name.toLowerCase())}">
            <img src="${escB(a.img ?? "icons/svg/mystery-man.svg")}" alt="${escB(a.name)}">
            <span>${escB(a.name)}</span>
        </div>`).join("");

    return `
    <div id="${uid}" style="display:flex;flex-direction:column;gap:10px;padding:4px 0;">
        <input class="bst-picker-search" type="text" placeholder="🔍 Rechercher une créature…"
            style="width:100%;box-sizing:border-box;padding:5px 8px;
                   border:1px solid #555;border-radius:4px;background:#111;color:#ddd;font-size:12px;">
        <div class="bst-picker-list" style="max-height:280px;overflow-y:auto;">
            ${rows || `<p style="color:#666;font-style:italic;font-size:12px;text-align:center;padding:12px 0;">
                ${tl("Aucune créature disponible.")}</p>`}
        </div>
    </div>`;
}

async function openAddDialog(actor) {
    const uid       = `bst-add-${Date.now()}`;
    const creatures = await availableCreatures(actor);
    // Index par ID pour retrouver nom/img dans le callback de confirmation
    const creaturesById = new Map(creatures.map(c => [c.id, c]));
    let selectedId  = null;
    let result      = null;

    await foundry.applications.api.DialogV2.wait({
        window:      { title: tl("Ajouter au bestiaire") },
        position:    { width: 360 },
        rejectClose: false,
        content:     buildCreaturePickerHtml(creatures, uid),
        render: () => {
            const d = document.getElementById(uid);
            if (!d) return;

            // Sélection d'une créature
            d.querySelectorAll(".bst-picker-actor").forEach(el => {
                el.addEventListener("click", () => {
                    d.querySelectorAll(".bst-picker-actor").forEach(e => e.classList.remove("selected"));
                    el.classList.add("selected");
                    selectedId = el.dataset.actorId;
                });
            });

            // Recherche en temps réel
            d.querySelector(".bst-picker-search")?.addEventListener("input", function () {
                const q = this.value.trim().toLowerCase();
                d.querySelectorAll(".bst-picker-actor").forEach(el => {
                    el.style.display = (!q || el.dataset.name.includes(q)) ? "" : "none";
                });
            });

            setTimeout(() => d.querySelector(".bst-picker-search")?.focus(), 60);
        },
        buttons: [
            {
                action: "confirm", default: true,
                label: tl("Ajouter"), icon: '<i class="fa-solid fa-check"></i>',
                callback: () => {
                    if (!selectedId) return;
                    // Acteur monde ou acteur compendium (retrouvé via l'index du dialog)
                    const target = game.actors.get(selectedId) ?? creaturesById.get(selectedId);
                    const s = compendiumSourceOf(target);
                    result = {
                        targetId:   selectedId,
                        targetName: target?.name ?? tl("Inconnue"),
                        targetImg:  target?.img  ?? "",
                        sourcePack: s?.pack ?? null,
                        sourceId:   s?.id ?? null,
                        hostility:  0,
                        note:       "",
                        firstScene: game.scenes.current?.name ?? "",
                        lastPosition: game.scenes.current?.name ?? "",
                        lastSeen:   dateDeRencontre(),
                        revealed:   !(target?.getFlag?.(MOD, "anonymous") ?? false),
                    };
                }
            },
            { action: "cancel", label: tl("Annuler"), icon: '<i class="fa-solid fa-times"></i>', callback: () => {} }
        ]
    });

    return result;
}

// ---- Événements de l'onglet --------------------------------

function _autoResize(el) {
    el.style.height = "auto";
    el.style.height = el.scrollHeight + "px";
}

export function wireTab(actor, $html) {
    const $tab = $html.find(".bst-tab");
    if (!$tab.length) return;

    // Resize textareas déjà visibles (sections ouvertes depuis _expanded)
    $tab.find(".bst-note-input").each((_, el) => _autoResize(el));

    // Clic sur la ligne → ouvrir le portrait
    $tab.on("click", ".bst-row-header", function (e) {
        if ($(e.target).closest("a, input, .bst-h-btn, .bst-btns").length) return;
        const bstId  = String($(this).closest(".bst-row").data("bst-id"));
        const entry  = beastList(actor).find(en => en.id === bstId);
        if (!entry) return;
        const target = game.actors.get(entry.targetId);
        const img    = target?.img  ?? entry.targetImg  ?? "icons/svg/mystery-man.svg";
        const name   = target?.name ?? entry.targetName ?? tl("Inconnue");
        ouvrirImage(img, name);
    });

    // Ajouter manuellement (GM uniquement)
    $tab.on("click", ".bst-add-btn", async () => {
        const data = await openAddDialog(actor);
        if (!data) return;
        const list = beastList(actor);
        if (list.some(e => e.targetId === data.targetId)) return; // doublon
        const entry = { id: foundry.utils.randomID(12), ...data };
        await beastSave(actor, [...list, entry]);
        $tab.find(".bst-empty").remove();
        $tab.find(".bst-list").append(buildRowHtml(entry, actor, true));
    });

    // Déplier / replier notes
    $tab.on("click", ".bst-toggle", function () {
        const $row   = $(this).closest(".bst-row");
        const id     = String($row.data("bst-id"));
        const $notes = $row.find(".bst-notes");
        const $icon  = $(this).find("i");
        if ($notes.is(":visible")) {
            _expanded.delete(id);
            $notes.slideUp(150);
            $icon.removeClass("fa-chevron-up").addClass("fa-chevron-down");
        } else {
            _expanded.add(id);
            $notes.slideDown(150, function () {
                $(this).find(".bst-note-input").each((_, el) => _autoResize(el));
            });
            $icon.removeClass("fa-chevron-down").addClass("fa-chevron-up");
        }
    });

    // Changer l'hostilité (optimiste)
    $tab.on("click", ".bst-h-btn", async function () {
        const $btn = $(this);
        const id   = String($btn.closest(".bst-row").data("bst-id"));
        const h    = parseInt($btn.data("hostility"));
        const cfg  = HOSTILITY_CFG[String(h)];
        const $sel = $btn.closest(".bst-hostility-selector");
        $sel.find(".bst-h-btn").removeClass("active").find("i").css("color", "");
        $btn.addClass("active").find("i").css("color", cfg.color);
        $sel.find(".bst-h-label").text(cfg.label).css("color", cfg.color);
        await beastUpdate(actor, id, { hostility: h });
    });

    // Ouvrir la fiche de la créature (GM uniquement). Acteur du monde si présent,
    // sinon la fiche du COMPENDIUM (lien stable après suppression du monde).
    $tab.on("click", ".bst-open-sheet", async function (e) {
        e.stopPropagation();
        const targetId = String($(this).data("target-id") ?? "");
        const world = game.actors.get(targetId);
        if (world) { world.sheet?.render(true); return; }
        const uuid = String($(this).data("source-uuid") ?? "");
        if (uuid) { try { (await fromUuid(uuid))?.sheet?.render(true); } catch (err) {} }
    });

    // Supprimer avec confirmation
    $tab.on("click", ".bst-delete", async function () {
        const $row  = $(this).closest(".bst-row");
        const id    = String($row.data("bst-id"));
        const entry = beastList(actor).find(e => e.id === id);
        if (!entry) return;
        const ok = await foundry.applications.api.DialogV2.confirm({
            window: { title: tl("Retirer du bestiaire") },
            content: `<p>${tl("Retirer <strong>{0}</strong> du bestiaire ?<br>\n                      <small style=\"color:#999;\">Cette action est irréversible.</small>", escB(entry.targetName))}</p>`,
        });
        if (!ok) return;
        _expanded.delete(id);
        $row.remove();
        await beastDelete(actor, id);
        if (!$tab.find(".bst-row").length) {
            $tab.find(".bst-list").html(emptyStateHtml());
        }
    });

    // CA estimée : clic sur une barre (re-clic sur la barre choisie = inconnue)
    $tab.on("click", ".bst-ca-edit", async function (e) {
        e.preventDefault();
        const $row = $(this).closest(".bst-ca-row");
        const id   = String($row.data("bst-id"));
        const entry = beastList(actor).find(en => en.id === id);
        if (!entry) return;
        const choisi = String($(this).data("ca"));
        const ca = entry.ca === choisi ? "" : choisi;
        $row.find(".bst-ca-jauge, .bst-ca-label").remove();
        $row.append(jaugeCaHtml(ca, true));
        await beastUpdate(actor, id, { ca });
    });

    // Étiquettes de dégâts : neutre → faiblesse → résistance → immunité → neutre
    $tab.on("click", ".bst-dmg-edit", async function (e) {
        e.preventDefault();
        const $tag = $(this);
        const id   = String($tag.closest(".bst-dmg-list").data("bst-id"));
        const cle  = String($tag.data("dmg"));
        const nom  = (DEGATS.find(([k]) => k === cle) ?? [cle, cle])[1];
        const suivant = etatSuivant(String($tag.attr("data-etat") ?? ""));
        $tag.replaceWith(etiquetteDegatHtml(cle, nom, suivant, true));
        const entry = beastList(actor).find(en => en.id === id);
        if (!entry) return;
        const degats = { ...(entry.degats ?? {}) };
        if (suivant) degats[cle] = suivant; else delete degats[cle];
        await beastUpdate(actor, id, { degats });
        programmerTri($tag.length ? $tab.find(`.bst-dmg-list[data-bst-id="${id}"]`) : null, id);
    });

    // Réordonnancement des étiquettes (groupes faiblesse / résistance /
    // immunité) : pas pendant qu'on clique, pour que l'étiquette ne se
    // déplace pas sous la souris, mais quand la souris quitte la liste ou
    // 1,5 s après le dernier clic.
    const _tris = new Map();
    const trier = (id) => {
        clearTimeout(_tris.get(id)); _tris.delete(id);
        const $liste = $tab.find(`.bst-dmg-list[data-bst-id="${id}"]`);
        const entry = beastList(actor).find(en => en.id === id);
        if (!$liste.length || !entry) return;
        const el = $liste[0];
        el.style.opacity = "0.35";
        setTimeout(() => { el.innerHTML = listeDegatsHtml(entry, true); el.style.opacity = "1"; }, 150);
    };
    function programmerTri($liste, id) {
        clearTimeout(_tris.get(id));
        _tris.set(id, setTimeout(() => trier(id), 1500));
    }
    $tab.on("mouseleave", ".bst-dmg-list", function () {
        const id = String($(this).data("bst-id"));
        if (_tris.has(id)) trier(id);
    });

    // Auto-save note (debounce + blur immédiat)
    $tab.on("input", ".bst-note-input", function () {
        _autoResize(this);
        clearTimeout(_noteTimer);
        const id  = String($(this).data("bst-id"));
        const val = this.value;
        _noteTimer = setTimeout(() => beastUpdate(actor, id, { note: val }), 1200);
    });
    $tab.on("blur", ".bst-note-input", async function () {
        clearTimeout(_noteTimer);
        await beastUpdate(actor, String($(this).data("bst-id")), { note: this.value });
    });

    // Recherche en temps réel
    $tab.on("input", ".bst-search-input", function () {
        const q = this.value.trim().toLowerCase();
        $tab.find(".bst-search-clear").toggle(!!q);
        let visible = 0;
        $tab.find(".bst-row").each(function () {
            const match = !q || $(this).find(".bst-name").text().toLowerCase().includes(q);
            $(this).toggle(match);
            if (match) visible++;
        });
        $tab.find(".bst-no-results").remove();
        if (q && $tab.find(".bst-row").length && !visible) {
            $tab.find(".bst-list").append(
                `<div class="bst-no-results bst-empty">
                    <i class="fa-solid fa-search"></i>
                    <span>${tl("Aucune créature trouvée.")}</span>
                </div>`
            );
        }
    });

    $tab.on("click", ".bst-search-clear", function (e) {
        e.stopPropagation();
        $tab.find(".bst-search-input").val("").trigger("input");
    });
}

// Met à jour le champ « Dernière position » dans les fiches ouvertes (sans
// re-rendu, l'update se fait avec render:false).
function _rafraichirPosition(actor, entry) {
    const sel = (c) => `.bst-tab[data-actor-id="${actor.id}"] .${c}[data-bst-id="${entry.id}"]`;
    document.querySelectorAll(sel("bst-last-value")).forEach(el => { el.textContent = entry.lastPosition ?? ""; });
    const { texte, titre } = texteRencontre(entry.lastSeen);
    document.querySelectorAll(sel("bst-seen-value")).forEach(el => { el.textContent = texte; el.title = titre; });
}

// ---- Détection automatique (GM only) -----------------------

async function scanVisibleTokens() {
    if (!game.settings.get(MOD, "bestiaryEnabled")) return;
    if (game.user.isGM) return;  // scan côté joueur uniquement
    if (_scanning) return;
    _scanning = true;

    try {
        await ensureCreatureIndex();

        // Détection sur la scène affichée, pour le personnage sur lequel le
        // joueur est CONNECTÉ (Configuration du joueur → personnage), et
        // seulement les créatures que SON jeton voit (murs qui bloquent la
        // vue, porte fermée, jeton caché, lumière : voir perception.js).
        // Jamais sur les cartes des expéditions.
        if (surCarteExpedition()) return;
        const tokens    = canvas.tokens?.placeables ?? [];
        const sceneName = canvas.scene?.name ?? game.scenes.current?.name ?? "";

        const myToken = jetonDuPersonnage();
        if (!myToken || myToken.actor?.type !== "character" || !isInPJFolder(myToken.actor)) return;
        const myActor = myToken.actor;

        const existing = new Set(beastList(myActor).map(e => e.targetId));
        const seenIds  = new Set();

        // Créatures déjà connues que le personnage revoit : dernière position
        // et date de dernière rencontre (une écriture au plus par changement).
        const avecPos = opt("bestiaryLastPosition") && !!sceneName, avecDate = opt("bestiaryLastSeen");
        const quand = dateDeRencontre();
        if (avecPos || avecDate) {
            const revues = new Set(tokens.filter(t => t.actor?.id && existing.has(t.actor.id) && voit(myToken, t)).map(t => t.actor.id));
            const liste = beastList(myActor);
            const aJour = (e) => {
                if (!revues.has(e.targetId)) return e;
                const patch = {};
                if (avecPos && e.lastPosition !== sceneName) patch.lastPosition = sceneName;
                if (avecDate && !memeRencontre(e.lastSeen, quand)) patch.lastSeen = quand;
                return Object.keys(patch).length ? { ...e, ...patch } : e;
            };
            const nouvelle = liste.map(aJour);
            if (nouvelle.some((e, i) => e !== liste[i])) {
                await myActor.update({ [`flags.${MOD}.bestiaryList`]: nouvelle }, { render: false });
                for (const e of nouvelle) if (revues.has(e.targetId)) _rafraichirPosition(myActor, e);
            }
        }

        const toAdd = tokens.filter(t => {
            if (!t.actor?.id) return false;
            if (t.actor.id === myActor.id) return false;
            if (!isCreatureToken(t)) return false;
            if (existing.has(t.actor.id)) return false;
            if (seenIds.has(t.actor.id)) return false;
            if (t.actor.getFlag(MOD, "excludedFromBestiary") ?? false) return false;
            if (!voit(myToken, t)) return false;
            seenIds.add(t.actor.id);
            return true;
        });

        if (!toAdd.length) return;

        const newEntries = toAdd.map(t => {
            const s = compendiumSourceOf(t.actor);
            return {
                id:         foundry.utils.randomID(12),
                targetId:   t.actor.id,
                targetName: t.actor.name,
                targetImg:  t.actor.img ?? "",
                sourcePack: s?.pack ?? null,
                sourceId:   s?.id ?? null,
                hostility:  0,
                note:       "",
                firstScene: sceneName,
                lastPosition: sceneName,
                lastSeen:   quand,
                revealed:   !(t.actor.getFlag(MOD, "anonymous") ?? false),
            };
        });

        await myActor.update(
            { [`flags.${MOD}.bestiaryList`]: [...beastList(myActor), ...newEntries] },
            { render: false }
        );
    } finally {
        _scanning = false;
    }
}

// ---- Anonymisation (GM only) --------------------------------

function currentScenePJs() {
    return (canvas.tokens?.placeables ?? [])
        .filter(t => t.actor?.type === "character" && t.actor.id)
        .map(t => t.actor)
        .filter((a, i, arr) => arr.findIndex(b => b.id === a.id) === i);
}

async function revealBestiaryToParty(actorId) {
    if (!game.user.isGM) return;
    for (const pj of currentScenePJs()) {
        const list = beastList(pj);
        if (!list.some(e => e.targetId === actorId)) continue;
        await pj.update({ [`flags.${MOD}.bestiaryList`]: list.map(e =>
            e.targetId === actorId ? { ...e, revealed: true } : e
        )});
    }
}

async function anonymizeBestiary(actorId) {
    if (!game.user.isGM) return;
    for (const pj of currentScenePJs()) {
        const list = beastList(pj);
        if (!list.some(e => e.targetId === actorId)) continue;
        await pj.update({ [`flags.${MOD}.bestiaryList`]: list.map(e =>
            e.targetId === actorId ? { ...e, revealed: false } : e
        )});
    }
}

// Retire définitivement cet acteur de TOUS les bestiaires du monde
async function removeFromAllBestiary(actorId) {
    if (!game.user.isGM) return;
    for (const actor of game.actors ?? []) {
        const list = beastList(actor);
        if (!list.some(e => e.targetId === actorId)) continue;
        await actor.setFlag(MOD, "bestiaryList", list.filter(e => e.targetId !== actorId));
    }
}

export function BestiaryHooks() {
    // Scan initial — sight déjà calculé au moment de canvasReady
    Hooks.on("canvasReady", () => scanVisibleTokens());
    // sightRefresh couvre les scènes avec vision active
    Hooks.on("sightRefresh", () => {
        clearTimeout(_sightTimer);
        _sightTimer = setTimeout(() => scanVisibleTokens(), 500);
    });
    // createToken couvre les scènes sans vision (sightRefresh ne tire pas)
    Hooks.on("createToken", () => {
        clearTimeout(_sightTimer);
        _sightTimer = setTimeout(() => scanVisibleTokens(), 300);
    });
    // Jeton qui bouge / apparaît, porte ouverte, changement de personnage.
    const relancer = () => { clearTimeout(_sightTimer); _sightTimer = setTimeout(() => scanVisibleTokens(), 400); };
    Hooks.on("updateToken", (doc, ch) => { if ("x" in ch || "y" in ch || "hidden" in ch) relancer(); });
    Hooks.on("updateWall", (doc, ch) => { if ("ds" in ch) relancer(); });
    Hooks.on("controlToken", relancer);
    Hooks.on("updateUser", (u, ch) => { if (u.id === game.user?.id && "character" in ch) relancer(); });

    // Boutons en-tête : Anonyme + Révéler en fallback si Relations n'est pas actif
    // (le bouton "Retirer" unifié est injecté par le module Relations)
    Hooks.on("renderApplicationV2", (app, element) => {
        if (!game.user.isGM) return;
        if (!app.document || !(app.document instanceof Actor)) return;
        const actor = app.document;
        const header = element.querySelector(".window-header");
        if (!header || header.querySelector(".scwm-reveal-btn")) return;
        const id = actor.id;

        // Relations inactif : injecter Anonyme + Révéler + bouton Exclure
        const isAnon = () => !!(actor.getFlag(MOD, "anonymous") ?? false);
        const btnAnon = document.createElement("button");
        btnAnon.type = "button";
        btnAnon.classList.add("header-control", "icon", "fa-solid", "fa-eye-slash", "scwm-anon-btn");
        const refreshAnon = () => {
            btnAnon.style.color     = isAnon() ? "#e74c3c" : "";
            btnAnon.dataset.tooltip = isAnon() ? tl("Anonyme — cliquer pour désactiver") : tl("Rendre anonyme");
        };
        refreshAnon();
        btnAnon.addEventListener("click", async () => {
            await actor.setFlag(MOD, "anonymous", !isAnon());
            refreshAnon();
        });

        const btnReveal = document.createElement("button");
        btnReveal.type = "button";
        btnReveal.classList.add("header-control", "icon", "fa-solid", "fa-eye", "scwm-reveal-btn");
        btnReveal.dataset.tooltip = tl("Révéler à la party");
        btnReveal.addEventListener("click", () => Hooks.callAll("scwm:revealToParty", id));

        // Bouton 1 : bloquer l'ajout automatique (toggle des flags uniquement).
        const isExcluded = () =>
            !!(actor.getFlag(MOD, "excludedFromRelations") ?? false) ||
            !!(actor.getFlag(MOD,             "excludedFromBestiary")  ?? false);
        const btnBlock = document.createElement("button");
        btnBlock.type = "button";
        btnBlock.classList.add("header-control", "icon", "fa-solid", "fa-ban", "scwm-exclude-btn");
        const refreshBlock = () => {
            btnBlock.style.color     = isExcluded() ? "#e74c3c" : "";
            btnBlock.dataset.tooltip = isExcluded()
                ? tl("Ajout automatique bloqué — cliquer pour réactiver")
                : "Bloquer l'ajout automatique (Relations & Bestiaire)";
        };
        refreshBlock();
        btnBlock.addEventListener("click", async () => {
            const nowExcluded = !isExcluded();
            await actor.setFlag(MOD, "excludedFromRelations", nowExcluded);
            await actor.setFlag(MOD,             "excludedFromBestiary",  nowExcluded);
            refreshBlock();
        });

        // Bouton 2 : retirer de chez tous les joueurs (action ponctuelle).
        const btnRemove = document.createElement("button");
        btnRemove.type = "button";
        btnRemove.classList.add("header-control", "icon", "fa-solid", "fa-users-slash", "scwm-removeall-btn");
        btnRemove.dataset.tooltip = tl("Retirer de chez tous les joueurs (Relations & Bestiaire)");
        btnRemove.addEventListener("click", async () => {
            const ok = await foundry.applications.api.DialogV2.confirm({
                window:  { title: tl("Retirer de chez tous les joueurs") },
                content: `<p>${tl("Retirer <strong>{0}</strong> des Relations et du Bestiaire de <strong>tous les joueurs</strong> ?", escB(actor.name))}</p>
                          <p style="opacity:0.7;font-size:0.9em;">${tl("Les listes existantes sont nettoyées. Sans blocage, ce personnage pourra être ré-ajouté automatiquement s'il est recroisé.")}</p>`
            });
            if (!ok) return;
            Hooks.callAll("scwm:removeFromRelations", id);
            Hooks.callAll("scwm:removeFromBestiary",  id);
            ui.notifications.info(tl("{0} retiré des listes de tous les joueurs.", actor.name));
        });

        const title = header.querySelector(".window-title");
        if (title) {
            title.insertAdjacentElement("afterend", btnAnon);
            title.insertAdjacentElement("afterend", btnReveal);
            title.insertAdjacentElement("afterend", btnRemove);
            title.insertAdjacentElement("afterend", btnBlock);
        } else {
            const close = header.querySelector(".close");
            header.insertBefore(btnAnon,   close);
            header.insertBefore(btnReveal, btnAnon);
            header.insertBefore(btnRemove, btnReveal);
            header.insertBefore(btnBlock,  btnRemove);
        }
    });

    // Migration : rattache les entrées de bestiaire existantes au COMPENDIUM
    // (via l'acteur du monde s'il existe, sinon par nom), pour garder le lien
    // même après suppression de la créature du monde.
    Hooks.once("ready", async () => {
        if (!game.user.isGM || !game.settings.get(MOD, "bestiaryEnabled")) return;
        try {
            await ensureCreatureIndex();
            const packId = commonPackCreatures();
            const packIdx = packId ? game.packs.get(packId)?.index : null;
            for (const actor of game.actors ?? []) {
                if (actor.type !== "character") continue;
                const list = beastList(actor);
                if (!list.length) continue;
                let changed = false;
                const next = list.map(e => {
                    if (e.sourcePack && e.sourceId) return e;
                    const world = game.actors.get(e.targetId);
                    const s = world ? compendiumSourceOf(world) : null;
                    if (s) { changed = true; return { ...e, sourcePack: s.pack, sourceId: s.id }; }
                    const idxE = packIdx?.find?.(x => x.name === (world?.name ?? e.targetName));
                    if (idxE) { changed = true; return { ...e, sourcePack: packId, sourceId: idxE._id }; }
                    return e;
                });
                if (changed) await actor.update({ [`flags.${MOD}.bestiaryList`]: next }, { render: false });
            }
        } catch (e) { journal.avert("[Bestiaire] Migration source compendium :", e); }
    });

    // Répondre aux hooks (appels depuis les boutons, quel que soit le module émetteur)
    Hooks.on("scwm:revealToParty",       actorId => revealBestiaryToParty(actorId));
    Hooks.on("scwm:anonymize",           actorId => anonymizeBestiary(actorId));
    Hooks.on("scwm:removeFromBestiary",  actorId => removeFromAllBestiary(actorId));
}
