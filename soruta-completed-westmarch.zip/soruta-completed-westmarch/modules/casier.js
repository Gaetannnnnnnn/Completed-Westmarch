// ============================================================
// casier.js — « Casier de [GM] » : tableau de bord du meneur
//
// Bouton dans la barre WestMarch (GM uniquement) → ouvre un tableau de
// bord avec, à gauche en mode livret, deux onglets :
//   - « Rapports à finaliser » : les brouillons de rapport de session
//     enregistrés (via « Enregistrer pour plus tard » à la clôture) ;
//     éditables (notes) puis clôturables → envoi sur le salon Discord.
//   - « Sessions en cours »    : les expéditions/sessions ouvertes des PJ.
// © 2026 Soruta.
// ============================================================

import { MOD } from "./const.js";
import { getExpeditions, formatDate } from "./carnet.js";
import {
    getSessionDrafts, saveSessionDraft, deleteSessionDraft, sendSessionReport, getSessionLog, expeditionSessionCount
} from "./session.js";
import {
    getCreationRequests, approveCreation, rejectCreation,
    getPendingActors, validateActor, returnActor,
    getLevelUpRequests, grantLevelUp
} from "./charvalidation.js";
import { downtimeContentHtml, wireDowntime, applyDowntimeFromRoot } from "./tm.js";

const esc = (s) => String(s ?? "").replace(/[&<>"']/g, c =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

// Brouillons du GM courant (les rapports sont rangés par gmId).
function draftsFor(gmId) {
    return getSessionDrafts().filter(d => d.gmId === gmId)
        .sort((a, b) => (b.dateISO ?? "").localeCompare(a.dateISO ?? ""));
}
function myDrafts() { return draftsFor(game.user.id); }

// Expéditions EN COURS du GM (issues de l'onglet Expédition des fiches),
// regroupées par expédition (nom + date de début). La party actuelle du GM
// sert à marquer "En session" l'expédition qu'il MJ en ce moment.
function gmExpeditions(gmId = game.user.id) {
    // Personnages de la party actuellement menée par ce GM.
    const partyCharIds = new Set(
        (game.users ?? [])
            .filter(u => u.getFlag(MOD, "partyId") === gmId)
            .map(u => u.character?.id)
            .filter(Boolean)
    );

    const groups = new Map();
    for (const actor of game.actors ?? []) {
        if (actor.type !== "character") continue;
        for (const e of getExpeditions(actor)) {
            if (!e.startDate || e.endDate) continue;
            // Uniquement les expéditions dont CE GM est le MJ (tag gmId).
            if (e.gmId !== gmId) continue;
            const key = `${e.name || "Expédition"}|${JSON.stringify(e.startDate)}`;
            if (!groups.has(key)) groups.set(key, { name: e.name || "Expédition sans nom", startDate: e.startDate, gmId: e.gmId, startReal: e.startReal ?? null, endReal: null, participants: [] });
            groups.get(key).participants.push({ id: actor.id, name: actor.name });
        }
    }

    const out = [...groups.values()].map(g => ({
        ...g,
        sessions: expeditionSessionCount(g),
        // "En session" = l'expédition dont des participants sont dans la party
        // actuelle du GM (la session qu'il mène en ce moment).
        current: partyCharIds.size > 0 && g.participants.some(p => partyCharIds.has(p.id))
    }));
    out.sort((a, b) => (Number(b.current) - Number(a.current)) || a.name.localeCompare(b.name));
    return out;
}

// Présentation du dashboard (par GM), persistée dans le réglage casierProfiles.
function getPresentation(gmId) {
    const p = game.settings.get(MOD, "casierProfiles");
    return (p && typeof p === "object" && p[gmId]?.presentation) || "";
}
async function setPresentation(gmId, text) {
    const p = foundry.utils.deepClone(game.settings.get(MOD, "casierProfiles") ?? {});
    p[gmId] = { ...(p[gmId] ?? {}), presentation: text };
    await game.settings.set(MOD, "casierProfiles", p);
}

// Valeur numérique comparable d'une date d'expédition (objet calendrier ou nombre).
function dateVal(d) {
    if (d == null) return 0;
    if (typeof d === "number") return d;
    if (typeof d === "object") return (d.year ?? 0) * 10000 + (d.month ?? 0) * 100 + (d.day ?? 0);
    return 0;
}

// Nom du joueur derrière un PJ (createdFor → propriétaire non-MJ → nom du PJ).
function playerOf(actor) {
    const uid = actor.getFlag(MOD, "createdFor");
    const u = uid ? game.users.get(uid) : null;
    if (u) return u.name;
    const owner = game.users.find(x => !x.isGM && actor.testUserPermission?.(x, "OWNER"));
    return owner?.name ?? actor.name;
}

// Expéditions CLÔTURÉES distinctes (regroupées par nom + début + MJ), avec les
// PJ participants. Base de l'assiduité (jamais les connexions).
function closedExpeditions() {
    const map = new Map();
    for (const actor of game.actors ?? []) {
        if (actor.type !== "character") continue;
        for (const e of getExpeditions(actor)) {
            if (!e.startDate || !e.endDate) continue;   // seulement clôturées
            const key = `${e.name || "?"}|${JSON.stringify(e.startDate)}|${e.gmId || ""}`;
            if (!map.has(key)) map.set(key, { name: e.name || "Expédition sans nom", startDate: e.startDate, endDate: e.endDate, gmId: e.gmId || null, startReal: e.startReal ?? null, endReal: e.endReal ?? null, participants: new Set() });
            const g = map.get(key);
            g.participants.add(actor.id);
            if (e.endReal && (!g.endReal || e.endReal > g.endReal)) g.endReal = e.endReal;      // date réelle de clôture
            if (e.startReal && (!g.startReal || e.startReal < g.startReal)) g.startReal = e.startReal; // ouverture
        }
    }
    return [...map.values()]
        .map(x => ({ ...x, participants: [...x.participants] }))
        .sort((a, b) => dateVal(b.endDate) - dateVal(a.endDate));
}

// Date IRL lisible + ancienneté (« il y a X j ») pour juger de l'activité.
function realDateLabel(iso) {
    if (!iso) return "jamais";
    const d = new Date(iso);
    if (isNaN(d)) return "—";
    const days = Math.floor((Date.now() - d.getTime()) / 86400000);
    const ago = days <= 0 ? "aujourd'hui" : days === 1 ? "hier" : `il y a ${days} j`;
    return `${d.toLocaleDateString("fr-FR")} (${ago})`;
}

// Barres horizontales (graphique CSS, sans librairie). r.extra = texte à droite.
function barChart(rows, color) {
    if (!rows.length) return `<p class="scwm-casier-empty">Aucune donnée.</p>`;
    const max = Math.max(1, ...rows.map(r => r.value));
    return rows.map(r => `
        <div style="display:flex;align-items:center;gap:8px;margin:3px 0;">
            <span style="flex:0 0 150px;text-align:right;font-size:.85em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${esc(r.label)}</span>
            <div style="flex:1;background:rgba(255,255,255,.06);border-radius:3px;overflow:hidden;">
                <div style="width:${(r.value / max * 100).toFixed(1)}%;background:${color};height:15px;border-radius:3px;min-width:2px;"></div>
            </div>
            <span style="flex:0 0 28px;font-size:.85em;font-weight:600;">${r.value}</span>
            ${r.extra ? `<span style="flex:0 0 150px;font-size:.78em;opacity:.75;white-space:nowrap;">${esc(r.extra)}</span>` : ""}
        </div>`).join("");
}

// Suivi de tous les GM : leurs expéditions EN COURS (taguées gmId), le nom de
// chacune et les joueurs qui y participent.
function gmTracking() {
    // Regroupe les expéditions ouvertes par GM puis par expédition (nom+date).
    const byGm = new Map();
    for (const actor of game.actors ?? []) {
        if (actor.type !== "character") continue;
        for (const e of getExpeditions(actor)) {
            if (!e.startDate || e.endDate || !e.gmId) continue;
            if (!byGm.has(e.gmId)) byGm.set(e.gmId, new Map());
            const groups = byGm.get(e.gmId);
            const key = `${e.name || "Expédition"}|${JSON.stringify(e.startDate)}`;
            if (!groups.has(key)) groups.set(key, { name: e.name || "Expédition sans nom", startDate: e.startDate, gmId: e.gmId, startReal: e.startReal ?? null, endReal: null, participants: [] });
            groups.get(key).participants.push(actor.name);
        }
    }

    return (game.users ?? []).filter(u => u.isGM).map(gm => {
        const exps = (byGm.has(gm.id) ? [...byGm.get(gm.id).values()] : [])
            .map(x => ({ ...x, sessions: expeditionSessionCount(x) }));
        return { id: gm.id, name: gm.name, count: exps.length, exps };
    });
}

class CasierApp extends foundry.applications.api.ApplicationV2 {
    static DEFAULT_OPTIONS = {
        id:       "scwm-casier",
        classes:  ["scwm-casier"],
        window:   { title: "Casier", icon: "fa-solid fa-box-archive", resizable: true },
        position: { width: 760, height: 560 }
    };

    #tab = "dashboard";
    #selectedId = null;
    #viewGmId = null;   // GM dont on consulte le dashboard depuis « Suivi des GM »

    get title() { return `Casier de ${game.user.name}`; }

    async _renderHTML() { return this.#buildHTML(); }
    _replaceHTML(result, content) { content.innerHTML = result; this.#wire(content); }

    // ---- Rendu ----
    #buildHTML() {
        const drafts = myDrafts();

        const cvEnabled = game.settings.get(MOD, "enableCharValidation");
        const cvCount = cvEnabled ? (getCreationRequests().length + getPendingActors().length) : 0;
        const tmEnabled = game.settings.get(MOD, "tmEnabled");
        const tmDeclared = tmEnabled
            ? (game.actors?.filter(a => a.type === "character" && a.hasPlayerOwner && a.getFlag(MOD, "tm")?.declared).length ?? 0)
            : 0;

        const TABS = [
            { key: "dashboard",   icon: "fa-gauge-high", label: "Dashboard" },
            { key: "reports",     icon: "fa-scroll",     label: `Rapports${drafts.length ? ` (${drafts.length})` : ""}` },
            { key: "expeditions", icon: "fa-route",      label: "Expéditions" },
            ...(tmEnabled ? [{ key: "downtime", icon: "fa-hourglass-half", label: `Temps morts${tmDeclared ? ` (${tmDeclared})` : ""}` }] : []),
            { key: "gms",         icon: "fa-users-gear", label: "Suivi des GM" },
            { key: "attendance",  icon: "fa-chart-column", label: "Assiduité" },
            ...(cvEnabled ? [{ key: "validation", icon: "fa-id-card", label: `Validation${cvCount ? ` (${cvCount})` : ""}` }] : [])
        ];
        const tabsHtml = TABS.map(t => `
            <button type="button" class="scwm-casier-tab ${this.#tab === t.key ? "active" : ""}" data-tab="${t.key}">
                <i class="fas ${t.icon}"></i> ${t.label}
            </button>`).join("");

        // Liste du livret (colonne gauche) — seulement pour l'onglet Rapports.
        let sideList = "";
        if (this.#tab === "reports") {
            sideList = drafts.length
                ? drafts.map(d => `
                    <div class="scwm-casier-page ${d.id === this.#selectedId ? "active" : ""}" data-draft-id="${esc(d.id)}">
                        <i class="fa-solid fa-scroll"></i>
                        <span class="scwm-casier-page-title">Rapport — ${esc(d.dateDisplay)}</span>
                    </div>`).join("")
                : `<div class="scwm-casier-empty">Aucun rapport en attente.</div>`;
        }

        let detail;
        if (this.#tab === "dashboard")      detail = this.#dashboardDetail(drafts);
        else if (this.#tab === "reports") {
            const draft = drafts.find(d => d.id === this.#selectedId);
            detail = draft ? this.#draftDetail(draft) : `<div class="scwm-casier-placeholder"><i class="fa-solid fa-book-open"></i><p>Sélectionnez un rapport à finaliser dans le livret.</p></div>`;
        }
        else if (this.#tab === "expeditions") detail = this.#expeditionsDetail();
        else if (this.#tab === "downtime")    detail = this.#downtimeDetail();
        else if (this.#tab === "attendance")  detail = this.#attendanceDetail();
        else if (this.#tab === "validation")  detail = this.#validationDetail();
        else                                  detail = this.#gmsDetail();

        return `
            <div class="scwm-casier-body">
                <aside class="scwm-casier-side">
                    <div class="scwm-casier-tabs">${tabsHtml}</div>
                    <div class="scwm-casier-pages">${sideList}</div>
                </aside>
                <section class="scwm-casier-content">${detail}</section>
            </div>`;
    }

    // ---- Onglet Dashboard ----
    #dashboardDetail(drafts) {
        const exps = gmExpeditions();
        return `
            <div class="scwm-casier-detail scwm-casier-dashboard">
                <h2><i class="fa-solid fa-box-archive"></i> Casier de ${esc(game.user.name)}</h2>
                <p class="scwm-casier-meta">Tableau de bord du meneur</p>

                <div class="scwm-casier-stats">
                    <div class="scwm-casier-stat"><b>${drafts.length}</b><span>Rapport(s) à finaliser</span></div>
                    <div class="scwm-casier-stat"><b>${exps.length}</b><span>Expédition(s) en cours</span></div>
                </div>

                <h3>Présentation</h3>
                <textarea class="scwm-casier-presentation" rows="8"
                    placeholder="Présentez-vous, vos critères, vos horaires… (visible ici, sauvegardé automatiquement)">${esc(getPresentation(game.user.id))}</textarea>
            </div>`;
    }

    // ---- Onglet Expéditions (du GM) ----
    #expeditionsDetail() {
        const exps = gmExpeditions();
        if (!exps.length) return `<div class="scwm-casier-placeholder"><i class="fa-solid fa-route"></i><p>Aucune expédition en cours.</p></div>`;
        return `
            <div class="scwm-casier-detail">
                <h2>Expéditions en cours</h2>
                ${exps.map(x => `
                    <div class="scwm-casier-exp-card ${x.current ? "current" : ""}">
                        <div class="scwm-casier-exp-head">
                            <i class="fa-solid fa-route"></i>
                            <span class="scwm-casier-exp-name">${esc(x.name)}</span>
                            ${x.current ? `<span class="scwm-casier-exp-badge">En session</span>` : ""}
                            <span class="scwm-casier-date">${esc(formatDate(x.startDate))}</span>
                            ${x.sessions != null ? `<span class="scwm-casier-date" style="opacity:.7;">· ${x.sessions} session${x.sessions > 1 ? "s" : ""}</span>` : ""}
                        </div>
                        ${x.participants.length ? `<div class="scwm-casier-exp-parts">${x.participants.map(p => esc(p.name)).join(", ")}</div>` : ""}
                    </div>`).join("")}
            </div>`;
    }

    // ---- Onglet Temps morts (panneau embarqué) ----
    #downtimeDetail() {
        return `
            <div class="scwm-casier-detail scwm-casier-downtime">
                <h2><i class="fa-solid fa-hourglass-half"></i> Temps morts</h2>
                <div class="scwm-tm-embed">${downtimeContentHtml(true)}</div>
                <div class="scwm-casier-actions" style="margin-top:10px;">
                    <button type="button" class="scwm-casier-apply-tm"><i class="fa-solid fa-coins"></i> Appliquer les gains</button>
                </div>
            </div>`;
    }

    // ---- Onglet Validation des personnages ----
    #validationDetail() {
        const reqs = getCreationRequests();
        const pend = getPendingActors();

        const reqRows = reqs.length ? reqs.map(r => `
            <div class="scwm-casier-cv-row" data-cv-user="${esc(r.userId)}">
                <div class="scwm-cv-info">
                    <strong>${esc(r.name || "Sans nom")}</strong> — <em>${esc(r.userName)}</em>
                    ${r.concept ? `<br><small>${esc(r.concept)}</small>` : ""}
                </div>
                <div class="scwm-cv-row-actions">
                    <button type="button" class="scwm-cv-approve" data-user="${esc(r.userId)}"><i class="fa-solid fa-check"></i> Créer &amp; assigner</button>
                    <button type="button" class="scwm-cv-reject" data-user="${esc(r.userId)}"><i class="fa-solid fa-times"></i> Refuser</button>
                </div>
            </div>`).join("") : `<div class="scwm-casier-empty">Aucune demande de création.</div>`;

        const pendRows = pend.length ? pend.map(a => {
            // Dépliant des modifications de montée de niveau (si présentes).
            const changes = Array.isArray(a.changes) ? a.changes : [];
            const changesBlock = (a.kind === "levelup" && changes.length) ? `
                <details class="scwm-cv-changes" style="margin-top:6px;">
                    <summary style="cursor:pointer;opacity:.85;font-size:.9em;"><i class="fa-solid fa-list-check"></i> Modifications de la fiche (${changes.length})</summary>
                    <ul style="margin:4px 0 0;padding-left:18px;font-size:.85em;opacity:.9;">${changes.map(c => `<li>${esc(c)}</li>`).join("")}</ul>
                </details>` : "";
            return `
            <div class="scwm-casier-cv-row" data-cv-actor="${esc(a.id)}">
                <div class="scwm-cv-info">
                    <strong>${esc(a.name)}</strong> — <em>${esc(a.ownerName)}</em>
                    ${a.kind === "levelup"
                        ? `<span class="scwm-cv-tag scwm-cv-tag-levelup"><i class="fa-solid fa-arrow-up-1-9"></i> Montée de niveau</span>`
                        : `<span class="scwm-cv-tag scwm-cv-tag-creation"><i class="fa-solid fa-user-plus"></i> Création</span>`}
                    ${changesBlock}
                </div>
                <div class="scwm-cv-row-actions">
                    <button type="button" class="scwm-cv-openactor" data-actor="${esc(a.id)}" title="Ouvrir la fiche"><i class="fa-solid fa-user"></i></button>
                    <button type="button" class="scwm-cv-validate" data-actor="${esc(a.id)}"><i class="fa-solid fa-lock"></i> Valider &amp; verrouiller</button>
                    <button type="button" class="scwm-cv-return" data-actor="${esc(a.id)}"><i class="fa-solid fa-rotate-left"></i> Renvoyer</button>
                </div>
            </div>`; }).join("") : `<div class="scwm-casier-empty">Aucune fiche à valider.</div>`;

        return `
            <div class="scwm-casier-detail scwm-casier-validation">
                <h2><i class="fa-solid fa-id-card"></i> Validation des personnages</h2>
                <div class="scwm-casier-cv-section">
                    <h3>Demandes de création</h3>
                    ${reqRows}
                </div>
                <div class="scwm-casier-cv-section">
                    <h3>Fiches à valider</h3>
                    ${pendRows}
                </div>
            </div>`;
    }

    // ---- Onglet Suivi des GM ----
    #gmsDetail() {
        // Si un GM est sélectionné → on affiche uniquement SON dashboard.
        if (this.#viewGmId) return this.#gmDashboardDetail(this.#viewGmId);

        const gms = gmTracking();
        if (!gms.length) return `<div class="scwm-casier-placeholder"><i class="fa-solid fa-users-gear"></i><p>Aucun GM.</p></div>`;
        return `
            <div class="scwm-casier-detail">
                <h2>Suivi des GM</h2>
                ${gms.map(gm => `
                    <div class="scwm-casier-gm-card ${gm.count ? "active" : ""}">
                        <div class="scwm-casier-gm-head">
                            <i class="fa-solid fa-user-shield"></i>
                            <span class="scwm-casier-gm-name scwm-casier-gm-open" data-gm="${esc(gm.id)}" title="Voir le dashboard de ${esc(gm.name)}">${esc(gm.name)}</span>
                            <span class="scwm-casier-gm-badge">${gm.count} expédition${gm.count > 1 ? "s" : ""}</span>
                        </div>
                        ${gm.exps.length
                            ? `<ul class="scwm-casier-gm-exps">${gm.exps.map(e => `
                                <li>
                                    <strong>${esc(e.name)}</strong>
                                    <span class="scwm-casier-date">(${esc(formatDate(e.startDate))})</span>
                                    ${e.sessions != null ? `<span class="scwm-casier-date" style="opacity:.7;">· ${e.sessions} session${e.sessions > 1 ? "s" : ""}</span>` : ""}
                                    <div class="scwm-casier-gm-parts">${e.participants.length ? e.participants.map(esc).join(", ") : "Aucun joueur"}</div>
                                </li>`).join("")}</ul>`
                            : `<div class="scwm-casier-gm-line" style="opacity:.6;">Aucune expédition en cours.</div>`}
                    </div>`).join("")}
            </div>`;
    }

    // ---- Onglet Assiduité ----
    // Cœur (compteurs, barres, tableau) = EXPÉDITIONS clôturées.
    // Activité (joueurs/MJ actifs + date de dernière activité) = SESSIONS.
    // Chaque expédition affiche (N sessions) = sessions du même MJ dans sa période.
    #attendanceDetail() {
        const list = closedExpeditions();
        const sessions = getSessionLog();

        // Dernière SESSION (date réelle) par joueur et par MJ → mesure d'activité.
        const sessPlayerLast = new Map();   // nom joueur -> ISO
        const sessGmLast     = new Map();   // nom MJ     -> ISO
        const keepMax = (m, k, iso) => { if (!iso) return; const cur = m.get(k); if (!cur || iso > cur) m.set(k, iso); };
        for (const s of sessions) {
            const gmName = s.gmName || (s.gmId ? (game.users.get(s.gmId)?.name ?? "MJ inconnu") : "MJ inconnu");
            keepMax(sessGmLast, gmName, s.dateISO);
            for (const p of (s.players ?? [])) {
                const a = game.actors.get(p.actorId);
                keepMax(sessPlayerLast, a ? playerOf(a) : (p.name ?? "?"), s.dateISO);
            }
        }
        if (!list.length) {
            return `<div class="scwm-casier-placeholder"><i class="fa-solid fa-chart-column"></i>
                <p>Aucune expédition clôturée pour l'instant. L'assiduité se calcule sur les expéditions terminées.</p></div>`;
        }

        // Agrégats EXPÉDITIONS (par joueur / par MJ).
        const players = new Map();   // nom joueur -> count
        const gms     = new Map();   // nom MJ     -> { count, parts }
        for (const e of list) {
            const gmName = e.gmId ? (game.users.get(e.gmId)?.name ?? "MJ inconnu") : "— (sans MJ)";
            if (!gms.has(gmName)) gms.set(gmName, { count: 0, parts: 0 });
            const g = gms.get(gmName); g.count++; g.parts += e.participants.length;

            const pn = new Set(e.participants.map(id => { const a = game.actors.get(id); return a ? playerOf(a) : null; }).filter(Boolean));
            for (const name of pn) players.set(name, (players.get(name) ?? 0) + 1);
        }

        // Barres : valeur = nb d'expéditions ; date à droite = dernière SESSION (activité).
        const playerRows = [...players.entries()].map(([label, count]) => ({ label, value: count, extra: realDateLabel(sessPlayerLast.get(label)) })).sort((a, b) => b.value - a.value);
        const gmRows     = [...gms.entries()].map(([label, g]) => ({ label, value: g.count, parts: g.parts, extra: realDateLabel(sessGmLast.get(label)) })).sort((a, b) => b.value - a.value);

        // « Actifs » (trimestre = 90 j) : basé sur la dernière SESSION.
        const ACTIVE_DAYS = 90;
        const isRecent = (iso) => iso && (Date.now() - new Date(iso).getTime()) <= ACTIVE_DAYS * 86400000;
        const totalExp = list.length;
        const totalPlayers = [...sessPlayerLast.values()].filter(isRecent).length;
        const totalGms = [...sessGmLast.entries()].filter(([k, iso]) => !k.startsWith("—") && isRecent(iso)).length;

        // Tableau des expéditions (40 plus récentes) avec (N sessions).
        const expRows = list.slice(0, 40).map(e => {
            const ns = expeditionSessionCount(e);
            return `
            <tr>
                <td>${esc(e.name)}${ns != null ? ` <span style="opacity:.65;">(${ns} session${ns > 1 ? "s" : ""})</span>` : ""}</td>
                <td>${esc(formatDate(e.endDate))}</td>
                <td style="font-size:.85em;opacity:.8;">${esc(e.endReal ? new Date(e.endReal).toLocaleDateString("fr-FR") : "—")}</td>
                <td>${esc(e.gmId ? (game.users.get(e.gmId)?.name ?? "?") : "—")}</td>
                <td style="font-size:.85em;">${e.participants.map(id => esc(game.actors.get(id)?.name ?? "?")).join(", ") || "—"}</td>
            </tr>`;
        }).join("");

        const card = (n, l) => `<div style="flex:1;background:var(--scwm-panel,rgba(255,255,255,.05));border-radius:8px;padding:8px 10px;text-align:center;">
            <div style="font-size:1.5em;font-weight:700;">${n}</div><div style="font-size:.8em;opacity:.7;">${l}</div></div>`;

        return `
            <div class="scwm-casier-detail scwm-casier-attendance" style="overflow:auto;">
                <h2><i class="fa-solid fa-chart-column"></i> Assiduité</h2>
                <div style="display:flex;gap:10px;margin:0 0 14px;">
                    ${card(totalExp, "expéditions clôturées")}
                    ${card(totalPlayers, "joueurs actifs (trimestre)")}
                    ${card(totalGms, "MJ actifs (trimestre)")}
                </div>

                <div class="scwm-casier-cv-section">
                    <h3>Expéditions par joueur <span style="font-weight:400;font-size:.75em;opacity:.7;">(nombre · dernière session jouée)</span></h3>
                    ${barChart(playerRows, "#8fd19e")}
                </div>

                <div class="scwm-casier-cv-section">
                    <h3>Expéditions menées par MJ <span style="font-weight:400;font-size:.75em;opacity:.7;">(nombre · dernière session menée)</span></h3>
                    ${barChart(gmRows, "#c9a227")}
                    <div style="font-size:.8em;opacity:.7;margin-top:4px;">${gmRows.map(g => `${esc(g.label)} : ${g.parts} participation(s)`).join(" · ")}</div>
                </div>

                <div class="scwm-casier-cv-section">
                    <h3>Expéditions clôturées (récentes)</h3>
                    <table style="width:100%;border-collapse:collapse;font-size:.9em;">
                        <thead><tr style="text-align:left;border-bottom:1px solid rgba(255,255,255,.15);">
                            <th style="padding:3px 4px;">Expédition</th><th style="padding:3px 4px;">Fin (IG)</th><th style="padding:3px 4px;">Clôturée (IRL)</th><th style="padding:3px 4px;">MJ</th><th style="padding:3px 4px;">Participants</th>
                        </tr></thead>
                        <tbody>${expRows}</tbody>
                    </table>
                </div>
            </div>`;
    }

    // Dashboard d'un GM donné, consulté depuis « Suivi des GM » (uniquement le
    // dashboard). Éditable si c'est le sien, en lecture seule sinon.
    #gmDashboardDetail(gmId) {
        const gm     = game.users?.get(gmId);
        const name   = gm?.name ?? "GM";
        const drafts = draftsFor(gmId);
        const exps   = gmExpeditions(gmId);
        const isSelf = gmId === game.user.id;
        const pres   = getPresentation(gmId);
        const presHtml = isSelf
            ? `<textarea class="scwm-casier-presentation" rows="8"
                    placeholder="Présentez-vous, vos critères, vos horaires… (visible ici, sauvegardé automatiquement)">${esc(pres)}</textarea>`
            : (pres
                ? `<div class="scwm-casier-presentation-view">${esc(pres).replace(/\n/g, "<br>")}</div>`
                : `<div class="scwm-casier-empty">Aucune présentation renseignée.</div>`);
        return `
            <div class="scwm-casier-detail scwm-casier-dashboard">
                <button type="button" class="scwm-casier-gm-back"><i class="fa-solid fa-arrow-left"></i> Retour au suivi des GM</button>
                <h2><i class="fa-solid fa-box-archive"></i> Casier de ${esc(name)}</h2>
                <p class="scwm-casier-meta">Tableau de bord du meneur${isSelf ? "" : " — lecture seule"}</p>

                <div class="scwm-casier-stats">
                    <div class="scwm-casier-stat"><b>${drafts.length}</b><span>Rapport(s) à finaliser</span></div>
                    <div class="scwm-casier-stat"><b>${exps.length}</b><span>Expédition(s) en cours</span></div>
                </div>

                <h3>Présentation</h3>
                ${presHtml}
            </div>`;
    }

    #draftDetail(d) {
        const players = (d.players ?? []).map(p => {
            let l = `<strong>${esc(p.name)}</strong> — XP ${p.xpBefore} → ${p.xpAfter}`;
            if (p.xpGained > 0) l += ` (+${p.xpGained})`;
            if (p.levelUp)      l += ` ⬆ <em>Niveau ${p.levelAfter}</em>`;
            return `<li>${l}</li>`;
        }).join("") || "<li>—</li>";

        const enemies = (d.combatants ?? []).map(e => `<li>${esc(e.name)}${e.cr != null ? ` — CR ${esc(e.cr)}` : ""}</li>`).join("");
        const npcs    = (d.npcs ?? []).map(n => `<li>${esc(n.name)}</li>`).join("");
        const items   = (d.items ?? []).map(i => `<li><strong>${esc(i.playerName)}</strong> — ${esc(i.itemName)}</li>`).join("");

        return `
            <div class="scwm-casier-detail" data-draft-id="${esc(d.id)}">
                <h2>Rapport de session — ${esc(d.dateDisplay)}</h2>
                <p class="scwm-casier-meta">Meneur : ${esc(d.gmName)}</p>

                <h3>Joueurs</h3>
                <ul class="scwm-casier-players">${players}</ul>

                ${enemies ? `<h3>Ennemis rencontrés</h3><ul>${enemies}</ul>` : ""}
                ${npcs    ? `<h3>PNJ rencontrés</h3><ul>${npcs}</ul>` : ""}
                ${items   ? `<h3>Objets récupérés</h3><ul>${items}</ul>` : ""}

                <h3>Notes de session</h3>
                <textarea class="scwm-casier-notes" rows="7" placeholder="Rédigez ou complétez le compte-rendu…">${esc(d.notes ?? "")}</textarea>

                <div class="scwm-casier-actions">
                    <button type="button" class="scwm-casier-send"><i class="fa-solid fa-paper-plane"></i> Clôturer &amp; envoyer sur Discord</button>
                    <button type="button" class="scwm-casier-delete"><i class="fa-solid fa-trash"></i> Supprimer</button>
                </div>
            </div>`;
    }

    // ---- Écouteurs ----
    #wire(root) {
        root.querySelectorAll(".scwm-casier-tab").forEach(btn =>
            btn.addEventListener("click", () => {
                this.#tab = btn.dataset.tab;
                this.#viewGmId = null;   // on quitte la vue dashboard d'un GM
                this.render();
            }));

        // ---- Suivi des GM : ouvrir / fermer le dashboard d'un GM ----
        root.querySelectorAll(".scwm-casier-gm-open").forEach(el =>
            el.addEventListener("click", () => { this.#viewGmId = el.dataset.gm; this.render(); }));
        root.querySelector(".scwm-casier-gm-back")?.addEventListener("click", () => { this.#viewGmId = null; this.render(); });

        root.querySelectorAll(".scwm-casier-page[data-draft-id]").forEach(pg =>
            pg.addEventListener("click", () => {
                this.#selectedId = pg.dataset.draftId;
                this.render();
            }));

        // ---- Onglet Validation ----
        root.querySelectorAll(".scwm-cv-approve").forEach(b => b.addEventListener("click", async () => { await approveCreation(b.dataset.user); this.render(); refreshCasierBadge(); }));
        root.querySelectorAll(".scwm-cv-reject").forEach(b => b.addEventListener("click", async () => { await rejectCreation(b.dataset.user); this.render(); refreshCasierBadge(); }));
        root.querySelectorAll(".scwm-cv-validate").forEach(b => b.addEventListener("click", async () => { await validateActor(b.dataset.actor); this.render(); refreshCasierBadge(); }));
        root.querySelectorAll(".scwm-cv-return").forEach(b => b.addEventListener("click", async () => { await returnActor(b.dataset.actor); this.render(); refreshCasierBadge(); }));
        root.querySelectorAll(".scwm-cv-grantlvl").forEach(b => b.addEventListener("click", async () => { await grantLevelUp(b.dataset.actor); this.render(); refreshCasierBadge(); }));
        root.querySelectorAll(".scwm-cv-openactor").forEach(b => b.addEventListener("click", () => game.actors.get(b.dataset.actor)?.sheet.render(true)));

        // Onglet Temps morts embarqué : câblage + application des gains.
        if (this.#tab === "downtime") {
            wireDowntime(root);
            root.querySelector(".scwm-casier-apply-tm")?.addEventListener("click", async () => {
                await applyDowntimeFromRoot(root);
                this.render();
            });
        }

        // Présentation du dashboard : sauvegarde à la perte de focus.
        const pres = root.querySelector(".scwm-casier-presentation");
        if (pres) pres.addEventListener("change", () => setPresentation(game.user.id, pres.value));

        // Sauvegarde des notes à la volée (perte de focus).
        const notes = root.querySelector(".scwm-casier-notes");
        if (notes) {
            notes.addEventListener("change", async () => {
                const d = myDrafts().find(x => x.id === this.#selectedId);
                if (!d) return;
                d.notes = notes.value;
                await saveSessionDraft(d);
            });
        }

        root.querySelector(".scwm-casier-send")?.addEventListener("click", async () => {
            const d = myDrafts().find(x => x.id === this.#selectedId);
            if (!d) return;
            if (notes) d.notes = notes.value;
            const ok = await sendSessionReport(d);
            if (!ok) return;   // avertissement déjà émis (webhook manquant / échec)
            await deleteSessionDraft(d.id);
            this.#selectedId = null;
            ui.notifications.info("Rapport de session envoyé sur Discord.");
            refreshCasierBadge();
            this.render();
        });

        root.querySelector(".scwm-casier-delete")?.addEventListener("click", async () => {
            const d = myDrafts().find(x => x.id === this.#selectedId);
            if (!d) return;
            const ok = await foundry.applications.api.DialogV2.confirm({
                window:  { title: "Supprimer le rapport" },
                content: `<p>Supprimer définitivement le brouillon <strong>Rapport — ${esc(d.dateDisplay)}</strong> ?</p>`
            });
            if (!ok) return;
            await deleteSessionDraft(d.id);
            this.#selectedId = null;
            refreshCasierBadge();
            this.render();
        });
    }
}

let _casierApp = null;
export function openCasier() {
    if (!_casierApp) _casierApp = new CasierApp();
    _casierApp.render(true);
}

// Force un rafraîchissement du badge de notif sur le bouton Casier.
export function refreshCasierBadge() {
    try { ui.controls?.render?.(); } catch (e) {}
}

// Fenêtre (lecture seule) des présentations des MJ — accessible aux joueurs.
export function openGmPresentations() {
    const gms = (game.users ?? []).filter(u => u.isGM);
    const cards = gms.map(gm => {
        const pres = getPresentation(gm.id);
        return `<div style="border:1px solid rgba(255,255,255,.12);border-radius:8px;padding:8px 10px;margin:0 0 8px;">
            <div style="font-weight:700;margin-bottom:4px;"><i class="fa-solid fa-user-shield"></i> ${esc(gm.name)}</div>
            <div style="font-size:.92em;opacity:.9;">${pres ? esc(pres).replace(/\n/g, "<br>") : "<em>Aucune présentation.</em>"}</div>
        </div>`;
    }).join("") || "<p>Aucun MJ.</p>";
    foundry.applications.api.DialogV2.wait({
        window:   { title: "Présentations des MJ", icon: "fa-solid fa-user-shield" },
        position: { width: 480 },
        content:  `<div style="max-height:60vh;overflow:auto;">${cards}</div>`,
        rejectClose: false,
        buttons: [{ action: "close", label: "Fermer", icon: "fa-solid fa-xmark", default: true }]
    }).catch(() => {});
}

export function CasierHooks() {
    Hooks.on("getSceneControlButtons", (controls) => {
        if (!game.user.isGM) return;
        if (!controls.westmarch) {
            controls.westmarch = { name: "westmarch", title: "WestMarch", icon: "fa-solid fa-hammer", layer: "tokens", tools: {} };
        }
        controls.westmarch.tools.casier = {
            name:     "casier",
            title:    `Casier de ${game.user.name}`,
            icon:     "fa-solid fa-box-archive",
            button:   true,
            onChange: () => openCasier(),
            visible:  true
        };
    });

    // Bouton JOUEUR : voir les présentations des MJ (lecture seule).
    Hooks.on("getSceneControlButtons", (controls) => {
        if (game.user.isGM) return;   // le MJ a déjà le Casier complet
        if (!controls.westmarch) {
            controls.westmarch = { name: "westmarch", title: "WestMarch", icon: "fa-solid fa-hammer", layer: "tokens", tools: {} };
        }
        controls.westmarch.tools.gmPresentations = {
            name:     "gmPresentations",
            title:    "Présentations des MJ",
            icon:     "fa-solid fa-user-shield",
            button:   true,
            onChange: () => openGmPresentations(),
            visible:  true
        };
    });

    // Pastille de notification sur le bouton Casier si des rapports sont en
    // attente (par GM — aucun suivi inter-GM des rapports).
    Hooks.on("renderSceneControls", (app, html) => {
        if (!game.user.isGM) return;
        const root = html instanceof HTMLElement ? html : html?.[0];
        const btn = root?.querySelector('[data-tool="casier"]');
        if (btn) btn.classList.toggle("scwm-has-drafts", myDrafts().length > 0);
    });

    Hooks.once("ready", () => {
        if (!game.user.isGM) return;

        // Ouvre le Casier via le bouton du message d'alerte (délégation globale).
        document.body.addEventListener("click", (e) => {
            if (e.target?.closest?.(".scwm-casier-open")) openCasier();
        });

        // Message chuchoté à soi-même (self-roll) rappelant les rapports en attente.
        setTimeout(() => {
            const n = myDrafts().length;
            if (n <= 0) return;
            ChatMessage.create({
                speaker: { alias: "Casier" },
                whisper: [game.user.id],
                content: `<div class="scwm-casier-alert">
                    <p><i class="fa-solid fa-box-archive"></i> Vous avez <strong>${n}</strong> rapport(s) de session en attente de finalisation.</p>
                    <button type="button" class="scwm-casier-open"><i class="fa-solid fa-up-right-from-square"></i> Ouvrir le Casier</button>
                </div>`
            });
        }, 1500);
    });
}
