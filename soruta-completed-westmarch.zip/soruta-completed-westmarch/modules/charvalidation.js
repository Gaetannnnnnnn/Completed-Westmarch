// ============================================================
// charvalidation.js — Validation des personnages (tickets)
//
// Flux :
//   1. Le joueur fait une DEMANDE DE CRÉATION (nom + concept). Stockée sur
//      son propre flag utilisateur (aucun GM requis en ligne pour l'émettre).
//   2. N'importe quel GM la valide depuis le Casier → un acteur est créé dans
//      le dossier dédié, dont le joueur devient Propriétaire. Il le construit
//      (y compris via ses imports Plutonium).
//   3. Le joueur SOUMET la fiche pour validation. Un GM la valide → la fiche
//      est VERROUILLÉE : les champs de CONSTRUCTION deviennent non modifiables
//      côté joueur, mais tout ce qui relève du JEU reste libre (tout ce que
//      surveille anticheat.js : préparation de sorts, attunement, équipé,
//      utilisations, emplacements — plus PV, monnaie, conditions, etc.).
//
// Le verrou est sélectif (hooks preUpdate/preCreate/preDelete) et non un
// changement d'ownership : le joueur garde OWNER pour pouvoir jouer.
// La respec / montée de niveau (déverrouillage via xp.js) est prévue pour
// une passe ultérieure.
// © 2026 Soruta.
// ============================================================

import { MOD } from "./const.js";
import { estHorsPrincipale } from "./horsprincipale.js";
import { journal } from "./log.js";
import { Dialog } from "./compat.js";
import { commonFolderNewChars, commonFolderPJ } from "./settings.js";
import { tl, memeNom } from "./i18n.js";
import { starXpEnabled, progressFor } from "./starxp.js";

// ---- Frontière construction / jeu -------------------------------------------
// Chemins d'acteur relevant de la CONSTRUCTION (verrouillés).
const BLOCKED_ACTOR_PATHS = [
    "system.abilities", "system.skills", "system.tools", "system.traits", "system.bonuses"
];
// Types d'items de CONSTRUCTION (ajout/retrait verrouillé).
const BUILD_ITEM_TYPES = new Set(["class", "subclass", "background", "race", "feat", "spell"]);
// Sur un item de construction, sous-clés system qui restent du JEU (autorisées).
// On inclut la consommation d'usage/activités : lancer un sort ou utiliser une
// capacité (ex. Divine Smite) met à jour "uses"/"activities" — c'est du JEU, pas
// de la construction, donc à ne PAS bloquer.
const ITEM_PLAY_KEYS = {
    feat:  ["uses", "activities"],
    spell: ["preparation", "prepared", "uses", "activities"]
};

const enabled = () => game.settings.get(MOD, "enableCharValidation");
// Mode « confiance » : les montées de niveau sont libres (aucun verrou sur la
// construction après la validation initiale). Voir réglage charFreeLevelUp.
const freeLevelUp = () => { try { return game.settings.get(MOD, "charFreeLevelUp") === true; } catch { return false; } };
const notifyLevelUp = () => { try { return game.settings.get(MOD, "charNotifyLevelUp") === true; } catch { return false; } };
const isLocked = (actor) => actor?.getFlag(MOD, "locked") === true;

// ---- Webhook Discord des validations ----------------------------------------
// Copie des notifications « Validation » (habituellement chuchotées aux MJ)
// vers un salon Discord : demandes de création, fiches soumises, montées de
// niveau. Envoyé par le client qui fait l'action (un seul client : pas de
// doublon). Les mentions (@everyone, @rôle…) sont neutralisées.
// Réglage : charValidationWebhookUrl (vide = désactivé).
const WEBHOOK_RE = /^https:\/\/(canary\.|ptb\.)?discord(app)?\.com\/api\/webhooks\//;
const md = (t) => String(t ?? "").replace(/([\\*_~`|>])/g, "\\$1");   // échappe la mise en forme Discord
function notifierDiscord(lignes) {
    try {
        if (!enabled()) return;
        const url = String(game.settings.get(MOD, "charValidationWebhookUrl") ?? "").trim();
        if (!url || !WEBHOOK_RE.test(url)) return;
        const texte = (Array.isArray(lignes) ? lignes : [lignes]).filter(Boolean).join("\n").slice(0, 1900);
        fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ content: texte, username: "WestMarch — Validation", allowed_mentions: { parse: [] } })
        }).catch(e => journal.erreurLocale?.(tl("[{0}] Webhook des validations :", MOD), e));
    } catch (e) { journal.avert(tl("[{0}] Webhook des validations :", MOD), e); }
}
// Liste à puces pour Discord, limitée pour rester sous la taille d'un message.
function listeDiscord(items, max = 15) {
    const l = items.slice(0, max).map(x => `• ${md(x)}`);
    if (items.length > max) l.push(tl("… et {0} autre(s)", items.length - max));
    return l;
}

// ============================================================
// DONNÉES / ÉTAT
// ============================================================
export function getCreationRequests() {
    return (game.users ?? [])
        .filter(u => !u.isGM && u.getFlag(MOD, "charRequest"))
        .map(u => ({ userId: u.id, userName: u.name, ...u.getFlag(MOD, "charRequest") }));
}
export function getPendingActors() {
    return (game.actors ?? [])
        .filter(a => a.type === "character" && !estHorsPrincipale(a) && a.getFlag(MOD, "pendingValidation") === true)
        .map(a => ({
            id: a.id,
            name: a.name,
            ownerName: game.users.get(a.getFlag(MOD, "createdFor"))?.name ?? "—",
            // Déjà validé une fois → c'est une montée de niveau / respec ; sinon création.
            kind: a.getFlag(MOD, "validated") === true ? "levelup" : "creation",
            // Liste des modifications apportées lors de la montée de niveau (dépliant).
            changes: a.getFlag(MOD, "levelUpChanges") ?? []
        }));
}
// ---- Stock / actifs -------------------------------------------------------
const maxTotal  = () => Number(game.settings.get(MOD, "charMaxTotal"))  || 0;   // 0 = illimité
const maxActive = () => Math.max(1, Number(game.settings.get(MOD, "charMaxActive")) || 2);
const isStock   = (a) => a?.getFlag?.(MOD, "stock") === true;

// Le personnage est-il EN CONSTRUCTION ? (création pas encore soumise, ou
// montée de niveau en cours). Même logique que le statut « 🛠️ » du hub :
// pas verrouillé, pas en attente de validation, pas en stock, et pris dans
// le circuit de validation. Sert au log Discord : pas de ⚠️ pendant la
// construction, c'est normal que le joueur modifie sa fiche.
export function estEnConstruction(actor) {
    try {
        if (!enabled() || !actor || actor.type !== "character") return false;
        if (estHorsPrincipale(actor)) return false;
        const f = (k) => actor.getFlag(MOD, k);
        if (f("locked") === true || f("pendingValidation") === true || isStock(actor)) return false;
        return !!(f("createdFor") || f("validated") === true || f("levelUpGranted") === true);
    } catch { return false; }
}

// Le PJ a-t-il atteint le seuil d'XP pour monter de niveau ? (XP dnd5e :
// value = XP actuelle, max = XP requise pour le niveau suivant.)
function canLevelUp(actor) {
    const xp = actor?.system?.details?.xp;
    if (!xp) return false;
    const value = Number(xp.value) || 0;
    const max   = Number(xp.max)   || 0;
    return max > 0 && value >= max;
}

// Personnages d'un utilisateur : ceux du circuit de validation (createdFor) ET
// ceux qu'il possède directement (Propriétaire), par ex. créés à la main par le
// MJ. Les persos en stock (Observateur) restent inclus via createdFor.
function actorsForUser(userId) {
    const L = CONST.DOCUMENT_OWNERSHIP_LEVELS;
    return (game.actors ?? []).filter(a =>
        a.type === "character" && !estHorsPrincipale(a) &&
        (a.getFlag(MOD, "createdFor") === userId || a.ownership?.[userId] === L.OWNER));
}
function activeCountForUser(userId) {
    return actorsForUser(userId).filter(a => !isStock(a)).length;
}

// GM : (dés)active un personnage — bascule le flag « stock » et l'ownership du
// joueur (Propriétaire si actif, Observateur si en stock).
async function applyCharStock(actorId, stock) {
    if (!game.user.isGM) return;
    const actor = game.actors.get(actorId);
    if (!actor) return;
    const uid = actor.getFlag(MOD, "createdFor");
    if (!uid) return;
    const L = CONST.DOCUMENT_OWNERSHIP_LEVELS;
    await actor.update({
        [`flags.${MOD}.stock`]: !!stock,
        [`ownership.${uid}`]: stock ? L.OBSERVER : L.OWNER
    });
}

// Joueur : passe par une requête au GM (changement d'ownership réservé au GM).
async function requestCharStock(actorId, stock) {
    if (game.user.isGM) { await applyCharStock(actorId, stock); return; }
    const gm = game.users.find(u => u.isGM && u.active);
    if (!gm) { ui.notifications?.warn(tl("Aucun MJ en ligne pour (dés)activer ce personnage.")); return; }
    try { await gm.query("westmarch.charStock", { actorId, stock }); }
    catch (e) { journal.avert(`[${MOD}] charStock :`, e); }
}

async function ensureFolder() {
    const val = commonFolderNewChars();
    const looksLikeId = (s) => /^[A-Za-z0-9]{16}$/.test(s ?? "");
    if (val) {
        // Le sélecteur de dossier stocke un id ; on l'accepte en priorité.
        const byId = game.folders?.get(val);
        if (byId?.type === "Actor") return byId;
        // Sinon on traite la valeur comme un nom de dossier (saisie libre).
        if (!looksLikeId(val)) {
            const byName = game.folders?.find(f => f.type === "Actor" && f.name === val);
            if (byName) return byName;
        }
    }
    const name = (val && !looksLikeId(val)) ? val : tl("Personnages");
    let f = game.folders?.find(x => x.type === "Actor" && x.name === name);
    if (!f) f = await Folder.create({ name, type: "Actor" });
    return f;
}

// Sous-dossier au nom du joueur, à l'intérieur du dossier parent configuré.
async function ensurePlayerFolder(user) {
    const parent = await ensureFolder();
    const name = user?.name ?? tl("Joueur");
    let f = game.folders?.find(x =>
        x.type === "Actor" && x.name === name && (x.folder?.id ?? null) === (parent?.id ?? null));
    if (!f) f = await Folder.create({ name, type: "Actor", folder: parent?.id ?? null });
    return f;
}

// Résout le « Dossier des PJ » configuré (setting commonFolderPJ) : accepte un
// id de dossier (stocké par le sélecteur) ou un nom (saisie libre).
function resolvePJFolder() {
    const val = commonFolderPJ();
    if (!val) return null;
    const looksLikeId = (s) => /^[A-Za-z0-9]{16}$/.test(s ?? "");
    const byId = game.folders?.get(val);
    if (byId?.type === "Actor") return byId;
    if (!looksLikeId(val)) {
        const byName = game.folders?.find(f => f.type === "Actor" && f.name === val);
        if (byName) return byName;
    }
    return null;
}

// Crée (une seule fois) un sous-dossier au nom du joueur dans le Dossier des PJ.
// Exécuté côté GM uniquement (la création de dossier requiert des droits GM).
async function ensurePlayerPJFolder(user) {
    if (!game.user.isGM) return null;
    if (!game.settings.get(MOD, "autoPlayerFolder")) return null;
    if (!user || user.isGM) return null;
    const parent = resolvePJFolder();
    if (!parent) return null;                       // aucun Dossier des PJ configuré
    const name = user.name ?? tl("Joueur");
    let f = game.folders?.find(x =>
        x.type === "Actor" && x.name === name && (x.folder?.id ?? null) === (parent.id ?? null));
    if (!f) {
        f = await Folder.create({ name, type: "Actor", folder: parent.id });
        journal.debug(tl("[{0}] Sous-dossier PJ créé pour « {1} ».", MOD, name));
    }
    return f;
}

// Crée (une seule fois) un sous-dossier au nom du MJ dans un dossier parent
// (même nom dans Acteurs, Journaux et Scènes), configuré dans les réglages.
async function ensureGmFolders(user) {
    if (!game.user.isGM) return;
    if (!user?.isGM) return;
    const parentName = (game.settings.get(MOD, "gmAutoFolderParent") ?? "").trim();
    if (!parentName) return;
    const name = user.name ?? "MJ";
    for (const type of ["Actor", "JournalEntry", "Scene"]) {
        let parent = game.folders?.find(f => f.type === type && f.name === parentName && !f.folder);
        if (!parent) {
            try { parent = await Folder.create({ name: parentName, type }); }
            catch (e) { journal.avert(tl("[{0}] Dossier parent MJ ({1}) :", MOD, type), e); continue; }
        }
        const exists = game.folders?.find(f =>
            f.type === type && f.name === name && (f.folder?.id ?? null) === (parent.id ?? null));
        if (!exists) {
            try { await Folder.create({ name, type, folder: parent.id }); }
            catch (e) { journal.avert(tl("[{0}] Sous-dossier MJ ({1}) :", MOD, type), e); }
        }
    }
}

// Dossier Acteurs du MJ (parent configuré → sous-dossier à son nom), créé au besoin.
async function gmActorSubfolder(user) {
    const parentName = (game.settings.get(MOD, "gmAutoFolderParent") ?? "").trim();
    if (!parentName) return null;
    let parent = game.folders?.find(f => f.type === "Actor" && f.name === parentName && !f.folder);
    if (!parent) parent = await Folder.create({ name: parentName, type: "Actor" });
    const name = user.name ?? "MJ";
    let sub = game.folders?.find(f => f.type === "Actor" && f.name === name && (f.folder?.id ?? null) === parent.id);
    if (!sub) sub = await Folder.create({ name, type: "Actor", folder: parent.id });
    return sub;
}

// À l'import d'une créature depuis un compendium (arrivée à la racine des Acteurs),
// la ranger dans un dossier « Créatures » du dossier Acteurs du MJ qui importe.
async function placeImportedCreature(actor, userId) {
    if (!game.user.isGM || userId !== game.user.id) return;
    if (actor.type !== "npc" || actor.pack) return;              // PNJ du monde uniquement
    if (actor.folder) return;                                    // déjà rangé
    const src = actor._stats?.compendiumSource ?? actor.getFlag?.("core", "sourceId") ?? "";
    const deCompendium = typeof src === "string" && src.startsWith("Compendium.");
    const dePlutonium = !!actor.flags?.plutonium;                // import Plutonium (pas de source « Compendium. »)
    if (!deCompendium && !dePlutonium) return;                   // seulement les créatures importées
    try {
        const gmSub = await gmActorSubfolder(game.user);
        if (!gmSub) return;
        let dest = game.folders?.find(f =>
            f.type === "Actor" && memeNom(f.name, tl("Import")) && (f.folder?.id ?? null) === gmSub.id);
        if (!dest) dest = await Folder.create({ name: tl("Import"), type: "Actor", folder: gmSub.id });
        await actor.update({ folder: dest.id });
    } catch (e) { journal.avert(tl("[{0}] Rangement créature importée :", MOD), e); }
}

// ---- Rangement auto des créatures DANS le compendium (Type → CR) ----
const _formatCR = (cr) => {
    const n = Number(cr);
    if (!Number.isFinite(n)) return "?";
    if (n === 0.125) return "1/8";
    if (n === 0.25) return "1/4";
    if (n === 0.5) return "1/2";
    return String(n);
};
// Couleur de dossier par type de créature dnd5e.
const COULEURS_TYPE = {
    aberration: "#6b3fa0", beast: "#5c8a3a", celestial: "#d4af37", construct: "#8a8d93",
    dragon: "#b02a2a", elemental: "#2a9d8f", fey: "#c65fa0", fiend: "#7a1f2b",
    giant: "#a9744f", humanoid: "#3f6fb0", monstrosity: "#4a7a6f", ooze: "#7a9a2a",
    plant: "#3f8a5a", undead: "#556b4f"
};
const _typeValue = (actor) => {
    const t = actor.system?.details?.type;
    return (t && typeof t === "object") ? t.value : t;
};
function _labelTypeCreature(actor) {
    const t = actor.system?.details?.type;
    const v = _typeValue(actor);
    if (v === "custom") {
        const c = (t && typeof t === "object" ? t.custom : "") || "";
        return c.trim() || tl("Autre");
    }
    const def = CONFIG.DND5E?.creatureTypes?.[v];
    if (def) return game.i18n?.localize?.(def.label ?? def) ?? String(v);
    return v ? (String(v).charAt(0).toUpperCase() + String(v).slice(1)) : tl("Sans type");
}
async function _ensurePackFolder(pack, name, parentId, color = null) {
    const found = pack.folders.find(f => f.name === name && (f.folder?.id ?? null) === (parentId ?? null));
    if (found) {
        if (color && !found.color) { try { await found.update({ color }); } catch (e) {} }   // colore les dossiers déjà créés
        return found;
    }
    return await Folder.create({ name, type: pack.documentName, folder: parentId ?? null, ...(color ? { color } : {}) }, { pack: pack.collection });
}
// Quand une créature est importée dans le compendium des créatures, la ranger
// dans un sous-dossier par type puis par CR (si l'option est active et le pack
// déverrouillé).
async function rangerCreatureCompendium(actor, userId) {
    if (!game.user.isGM || userId !== game.user.id) return;
    if (actor.type !== "npc" || !actor.pack) return;                 // document de compendium uniquement
    try { if (!game.settings.get(MOD, "autoFileCreaturesByType")) return; } catch { return; }
    const packId = (game.settings.get(MOD, "commonPackCreatures") ?? "").trim();
    if (!packId || actor.pack !== packId) return;                    // seulement le compendium des créatures
    const pack = game.packs.get(packId);
    if (!pack || pack.locked) return;                                // pack verrouillé : on ne touche à rien
    try {
        const typeF = await _ensurePackFolder(pack, _labelTypeCreature(actor), null, COULEURS_TYPE[_typeValue(actor)] ?? null);
        const crF = await _ensurePackFolder(pack, "CR " + _formatCR(actor.system?.details?.cr), typeF.id);
        if ((actor.folder?.id ?? null) !== crF.id) await actor.update({ folder: crF.id });
    } catch (e) { journal.avert(tl("[{0}] Rangement créature (compendium) :", MOD), e); }
}

// Si l'acteur est rangé dans un sous-dossier « au nom d'un joueur » situé dans
// l'arbre du Dossier des PJ, retourne l'utilisateur correspondant (sinon null).
function findPlayerForActorFolder(actor) {
    const folder = actor?.folder;
    if (!folder) return null;
    const pj = resolvePJFolder();
    if (!pj) return null;
    // Le dossier de l'acteur doit appartenir à l'arbre du Dossier des PJ.
    let inTree = false;
    for (let cur = folder; cur; cur = cur.folder) { if (cur.id === pj.id) { inTree = true; break; } }
    if (!inTree) return null;
    // Le dossier immédiat doit porter le nom d'un joueur (non-GM).
    return (game.users ?? []).find(u => !u.isGM && u.name === folder.name) ?? null;
}

// ---- Actions GM (appelées depuis le Casier) ----
export async function approveCreation(userId) {
    if (!game.user.isGM) return;
    const user = game.users.get(userId);
    if (!user) return;
    const req = user.getFlag(MOD, "charRequest") ?? {};
    const folder = await ensurePlayerFolder(user);   // Joueurs / <nom du joueur>
    const L = CONST.DOCUMENT_OWNERSHIP_LEVELS;
    // Si le joueur a déjà atteint sa limite de persos actifs, le nouveau est
    // créé « en stock » (Observateur) ; sinon actif (Propriétaire).
    const asStock = activeCountForUser(userId) >= maxActive();
    const actor = await Actor.create({
        name: req.name || tl("{0} — personnage", user.name),
        type: "character",
        folder: folder.id,
        ownership: { default: L.NONE, [userId]: asStock ? L.OBSERVER : L.OWNER },
        flags: { [MOD]: { createdFor: userId, concept: req.concept || "", validated: false, locked: false, stock: asStock } }
    });
    await user.unsetFlag(MOD, "charRequest");
    ChatMessage.create({
        whisper: [userId],
        speaker: { alias: tl("Validation") },
        content: `${tl("✅ Votre demande de personnage est acceptée. La fiche <strong>{0}</strong> est dans vos acteurs — construisez-la (imports Plutonium compris) puis soumettez-la pour validation.", actor?.name)}`
    });
    ui.notifications?.info(tl("Personnage créé pour {0}.", user.name));
}
export async function rejectCreation(userId) {
    if (!game.user.isGM) return;
    const user = game.users.get(userId);
    if (!user) return;
    await user.unsetFlag(MOD, "charRequest");
    ChatMessage.create({ whisper: [userId], speaker: { alias: tl("Validation") }, content: tl("❌ Votre demande de personnage a été refusée. Rapprochez-vous du MJ.") });
}
export async function validateActor(actorId) {
    if (!game.user.isGM) return;
    const actor = game.actors.get(actorId);
    if (!actor || estHorsPrincipale(actor)) return;
    await actor.update({
        [`flags.${MOD}.locked`]: true,
        [`flags.${MOD}.validated`]: true,
        [`flags.${MOD}.pendingValidation`]: false,
        [`flags.${MOD}.pendingLevelUp`]: false,
        [`flags.${MOD}.levelUpGranted`]: false,
        // Qui a validé, et quand (affiché dans le registre du Casier).
        [`flags.${MOD}.validatedBy`]: { id: game.user.id, name: game.user.name, date: new Date().toISOString() },
        [`flags.${MOD}.-=levelUpSnapshot`]: null,   // nettoie l'instantané de level-up
        [`flags.${MOD}.-=levelUpChanges`]: null     // nettoie la liste des modifs
    });
    const uid = actor.getFlag(MOD, "createdFor");
    if (uid) ChatMessage.create({ whisper: [uid], speaker: { alias: tl("Validation") }, content: `${tl("🔒 <strong>{0}</strong> est validé et verrouillé. Vous pouvez jouer normalement ; les changements de construction passeront par le MJ.", actor.name)}` });
    ui.notifications?.info(tl("{0} validé et verrouillé.", actor.name));
}

// ---- Suivi des modifications de montée de niveau ----------------------------
// Instantané de la CONSTRUCTION d'une fiche, pour comparer avant/après level-up.
function buildSnapshot(actor) {
    const items = actor.items ?? [];
    const abilities = {}, skills = {};
    for (const [k, v] of Object.entries(actor.system?.abilities ?? {})) abilities[k] = v.value;
    for (const [k, v] of Object.entries(actor.system?.skills ?? {})) skills[k] = v.value;
    return {
        level: actor.system?.details?.level ?? null,
        hp: actor.system?.attributes?.hp?.max ?? null,
        classes: items.filter(i => i.type === "class").map(i => `${i.name} ${i.system?.levels ?? "?"}`),
        subclasses: items.filter(i => i.type === "subclass").map(i => i.name),
        feats: items.filter(i => i.type === "feat").map(i => i.name),
        spells: items.filter(i => i.type === "spell").map(i => i.name),
        abilities, skills
    };
}
const _abilLabel  = (k) => game.i18n?.localize(CONFIG.DND5E?.abilities?.[k]?.label ?? "") || k.toUpperCase();
const _skillLabel = (k) => game.i18n?.localize(CONFIG.DND5E?.skills?.[k]?.label ?? "") || k;

// Liste lisible des différences entre deux instantanés (before → after).
function buildDiff(b, a) {
    const out = [];
    if (b.level !== a.level) out.push(`Niveau : ${b.level} → ${a.level}`);
    if (b.hp !== a.hp) out.push(`PV max : ${b.hp} → ${a.hp}`);
    a.classes.filter(x => !b.classes.includes(x)).forEach(x => out.push(`Classe : ${x}`));
    a.subclasses.filter(x => !b.subclasses.includes(x)).forEach(x => out.push(`Sous-classe : ${x}`));
    for (const k of Object.keys(a.abilities)) {
        if ((b.abilities[k] ?? null) !== a.abilities[k]) out.push(`${_abilLabel(k)} : ${b.abilities[k]} → ${a.abilities[k]}`);
    }
    const nf = a.feats.filter(x => !b.feats.includes(x));
    if (nf.length) out.push(tl("Aptitudes ajoutées : {0}", nf.join(", ")));
    const rf = b.feats.filter(x => !a.feats.includes(x));
    if (rf.length) out.push(tl("Aptitudes retirées : {0}", rf.join(", ")));
    const ns = a.spells.filter(x => !b.spells.includes(x));
    if (ns.length) out.push(tl("Sorts ajoutés : {0}", ns.join(", ")));
    const sk = Object.keys(a.skills).filter(k => (b.skills[k] ?? 0) !== a.skills[k]).map(_skillLabel);
    if (sk.length) out.push(tl("Maîtrises modifiées : {0}", sk.join(", ")));
    return out;
}

// Poste au MJ la liste des modifications d'une montée de niveau.
function postLevelUpDiff(actor, changes) {
    const body = changes.length
        ? `<ul style="margin:4px 0 0;padding-left:18px;">${changes.map(c => `<li>${esc(c)}</li>`).join("")}</ul>`
        : `${tl("<em>Aucune modification de construction détectée.</em>")}`;
    ChatMessage.create({
        whisper: gmIds(),
        speaker: { alias: tl("Montée de niveau") },
        content: `${tl("⬆️ <strong>{0}</strong> — modifications apportées à la fiche :{1}", esc(actor.name), body)}`
    });
}

// ---- Notification des montées de niveau LIBRES (mode confiance) -------------
// Quand le verrou est désactivé (charFreeLevelUp) et la notif activée, on agrège
// les changements de construction et on poste un récap au MJ, sans rien bloquer.
const _luPending = new Map();   // actorId -> { actor, lines:Set, timer }
function _luActive(actor, userId) {
    return enabled() && freeLevelUp() && notifyLevelUp()
        && !game.user.isGM && userId === game.user.id
        && actor?.type === "character"
        && actor?.getFlag(MOD, "validated") === true
        && actor?.getFlag(MOD, "createdFor") === game.user.id;
}
function _queueLuNote(actor, line) {
    if (!actor || !line) return;
    let e = _luPending.get(actor.id);
    if (!e) { e = { actor, lines: new Set(), timer: null }; _luPending.set(actor.id, e); }
    e.lines.add(line);
    if (e.timer) clearTimeout(e.timer);
    e.timer = setTimeout(() => {
        _luPending.delete(actor.id);
        const lines = [...e.lines];
        if (!lines.length) return;
        const body = `<ul style="margin:4px 0 0;padding-left:18px;">${lines.map(l => `<li>${esc(l)}</li>`).join("")}</ul>`;
        ChatMessage.create({
            whisper: gmIds(),
            speaker: { alias: tl("Montée de niveau (libre)") },
            content: `${tl("⬆️ <strong>{0}</strong> a modifié sa construction :{1}", esc(e.actor.name), body)}`
        });
        notifierDiscord([tl("⬆️ **{0}** a modifié sa construction :", md(e.actor.name)), ...listeDiscord(lines)]);
    }, 2500);
}

// Demandes de montée de niveau en attente (badge « Level up »).
export function getLevelUpRequests() {
    return (game.actors ?? [])
        .filter(a => a.type === "character" && a.getFlag(MOD, "pendingLevelUp") === true)
        .map(a => ({ id: a.id, name: a.name, ownerName: game.users.get(a.getFlag(MOD, "createdFor"))?.name ?? "—" }));
}

// GM : autorise une montée de niveau — déverrouille la fiche pour l'édition et
// signale à xp.js d'autoriser le changement de niveau (levelUpGranted). Le joueur
// re-soumet ensuite la fiche pour re-validation (qui re-verrouille).
export async function grantLevelUp(actorId) {
    if (!game.user.isGM) return;
    const actor = game.actors.get(actorId);
    if (!actor) return;
    await actor.update({
        [`flags.${MOD}.levelUpGranted`]: true,
        [`flags.${MOD}.locked`]: false,
        [`flags.${MOD}.pendingLevelUp`]: false,
        // Instantané AVANT montée de niveau → sert à lister les modifications.
        [`flags.${MOD}.levelUpSnapshot`]: buildSnapshot(actor)
    });
    const uid = actor.getFlag(MOD, "createdFor");
    if (uid) ChatMessage.create({ whisper: [uid], speaker: { alias: tl("Validation") }, content: `${tl("⬆️ Montée de niveau autorisée pour <strong>{0}</strong>. Effectuez-la (assistant / Plutonium), puis re-soumettez la fiche pour re-validation.", actor.name)}` });
    ui.notifications?.info(tl("Montée de niveau autorisée pour {0}.", actor.name));
}
export async function returnActor(actorId) {
    if (!game.user.isGM) return;
    const actor = game.actors.get(actorId);
    if (!actor) return;
    await actor.setFlag(MOD, "pendingValidation", false);
    const uid = actor.getFlag(MOD, "createdFor");
    if (uid) ChatMessage.create({ whisper: [uid], speaker: { alias: tl("Validation") }, content: `${tl("↩️ <strong>{0}</strong> vous est renvoyé pour ajustements avant re-soumission.", actor.name)}` });
}
// ============================================================
// UI JOUEUR — hub « Mon personnage »
// ============================================================
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const gmIds = () => game.users.filter(u => u.isGM).map(u => u.id);

// Tous les personnages du joueur courant (créés par le MJ ou via demande).
export function myCharActors() {
    return actorsForUser(game.user.id);
}

// Sous-fenêtre : formulaire de demande d'un NOUVEAU personnage.
function promptNewCharRequest() {
    new Dialog({
        title: tl("Demander un nouveau personnage"),
        content: `<div class="scwm-cv-hub">
            <div class="form-group"><label>${tl("Nom")}</label><input type="text" name="cv-name" placeholder="${tl("Nom du personnage")}"/></div>
        </div>`,
        buttons: {
            send: {
                icon: '<i class="fa-solid fa-paper-plane"></i>', label: tl("Envoyer la demande"),
                callback: async (html) => {
                    const root = html[0] ?? html;
                    const name = root.querySelector("[name=cv-name]")?.value.trim();
                    if (!name) { ui.notifications?.warn(tl("Indiquez un nom.")); return; }
                    await game.user.setFlag(MOD, "charRequest", { name, dateISO: new Date().toISOString() });
                    ChatMessage.create({ whisper: gmIds(), speaker: { alias: tl("Validation") }, content: `${tl("📝 <strong>{0}</strong> demande la création d'un personnage : « {1} ».", esc(game.user.name), esc(name))}` });
                    notifierDiscord(tl("📝 **{0}** demande la création d'un personnage : « {1} ».", md(game.user.name), md(name)));
                    ui.notifications?.info(tl("Demande envoyée."));
                }
            },
            cancel: { icon: '<i class="fa-solid fa-times"></i>', label: tl("Annuler") }
        },
        default: "send"
    }).render(true);
}

export function openPlayerHub() {
    const req = game.user.getFlag(MOD, "charRequest");
    const actors = myCharActors();

    const nbActive = activeCountForUser(game.user.id);
    const limActive = maxActive();
    const limTotal = maxTotal();
    const atActiveLimit = nbActive >= limActive;
    const atTotalLimit = limTotal > 0 && actors.length >= limTotal;

    // Bouton d'action (icône + texte).
    const bouton = (act, id, icone, texte, extra = "", cls = "") =>
        `<button type="button" class="scwm-cv-act ${cls}" data-act="${act}" data-id="${id ?? ""}" ${extra}><i class="fa-solid ${icone}"></i> ${texte}</button>`;

    // Richesse totale convertie en po (pp, po, pe, pa, pc), avec le détail.
    // Taux pris dans CONFIG.DND5E.currencies (conversion = combien de cette
    // pièce font 1 po), repli sur les taux standard.
    const richesse = (cur) => {
        const taux = { pp: 0.1, gp: 1, ep: 2, sp: 10, cp: 100 };
        const cfg = CONFIG?.DND5E?.currencies ?? {};
        let total = 0; const detail = [];
        for (const k of ["pp", "gp", "ep", "sp", "cp"]) {
            const n = Number(cur?.[k]) || 0;
            if (!n) continue;
            const conv = Number(cfg[k]?.conversion) || taux[k];
            total += n / conv;
            detail.push(`${n} ${cfg[k]?.abbreviation ? game.i18n.localize(cfg[k].abbreviation) : k}`);
        }
        return { po: cur ? Math.round(total * 100) / 100 : null, poDetail: detail.join(", ") };
    };

    // Infos de jeu lues sur la fiche dnd5e (tout est facultatif : une fiche
    // vide en début de construction ne doit rien casser).
    const infos = (a) => {
        const sys = a.system ?? {};
        const num = (v) => Number.isFinite(Number(v)) ? Number(v) : null;
        let classes = [];
        try {
            classes = Object.values(a.classes ?? {}).sort((x, y) => (y.system?.levels ?? 0) - (x.system?.levels ?? 0))
                .map(c => `${c.name} ${c.system?.levels ?? ""}`.trim() + (c.subclass?.name ? ` (${c.subclass.name})` : ""));
        } catch { /* */ }
        const espece = sys.details?.race?.name ?? (typeof sys.details?.race === "string" ? sys.details.race : "");
        const histo = sys.details?.background?.name ?? (typeof sys.details?.background === "string" ? sys.details.background : "");
        const xp = sys.details?.xp ?? {};
        const xpMax = num(xp.max), xpVal = num(xp.value) ?? 0, xpMin = num(xp.min) ?? 0;
        const pct = num(xp.pct) ?? (xpMax ? Math.round(((xpVal - xpMin) / Math.max(1, xpMax - xpMin)) * 100) : null);
        return {
            niveau: num(sys.details?.level) ?? 0,
            classes, espece, histo,
            pv: num(sys.attributes?.hp?.value), pvMax: num(sys.attributes?.hp?.max),
            ca: num(sys.attributes?.ac?.value),
            ...richesse(sys.currency),
            xpVal, xpMax, pct: pct == null ? null : Math.max(0, Math.min(100, pct))
        };
    };

    // Statut → pastille colorée + boutons d'action principaux.
    const statutDe = (a) => {
        const id = a.id;
        const stock      = isStock(a);
        const locked     = a.getFlag(MOD, "locked");
        const pending    = a.getFlag(MOD, "pendingValidation");
        const lvlPending = a.getFlag(MOD, "pendingLevelUp");
        const inFlow     = a.getFlag(MOD, "createdFor") === game.user.id;
        const validated  = a.getFlag(MOD, "validated");
        const btnStock = bouton("stock", id, "fa-box-archive", tl("Stock"), `data-tooltip="${tl("Mettre en stock : le personnage n'est plus jouable mais libère une place active.")}"`, "scwm-cvh-discret");
        if (stock) {
            const dis = atActiveLimit ? `disabled data-tooltip="${tl("Limite de personnages actifs atteinte — mettez-en un en stock d'abord")}"` : "";
            return { cle: "stock", icone: "fa-box-archive", texte: tl("En stock"), aide: tl("Rangé : pas jouable pour l'instant."),
                     btns: bouton("activate", id, "fa-lock-open", tl("Activer"), dis) };
        }
        if (validated && freeLevelUp()) {
            if (a.getFlag(MOD, "levelUpGranted") === true)
                return { cle: "construction", icone: "fa-hammer", texte: tl("Montée de niveau en cours"), aide: tl("Faites votre avancement, puis cliquez « Terminer »."),
                         btns: bouton("finishFree", id, "fa-lock", tl("Terminer")) + btnStock };
            return { cle: "jouable", icone: "fa-dice-d20", texte: tl("Jouable"), aide: tl("Montées de niveau libres."),
                     btns: bouton("levelup", id, "fa-circle-up", tl("Monter de niveau")) + btnStock };
        }
        if (locked && lvlPending)
            return { cle: "attente", icone: "fa-hourglass-half", texte: tl("Montée en attente"), aide: tl("Le MJ doit autoriser la montée de niveau."), btns: btnStock };
        if (locked)
            return { cle: "valide", icone: "fa-shield-halved", texte: tl("Validé"), aide: tl("Fiche validée par un MJ : prête à jouer."),
                     btns: (canLevelUp(a) ? bouton("levelup", id, "fa-circle-up", tl("Monter de niveau"), "", "scwm-cvh-brille") : "") + btnStock };
        if (pending)
            return { cle: "attente", icone: "fa-hourglass-half", texte: tl("En attente de validation"), aide: tl("Un MJ va relire votre fiche."), btns: btnStock };
        if (inFlow || validated)
            return { cle: "construction", icone: "fa-hammer", texte: tl("En construction"), aide: tl("Construisez votre fiche, puis soumettez-la à un MJ."),
                     btns: bouton("submit", id, "fa-paper-plane", tl("Soumettre")) + btnStock };
        return { cle: "jouable", icone: "fa-dice-d20", texte: tl("Jouable"), aide: tl("Pas encore passé en validation."),
                 btns: bouton("submit", id, "fa-paper-plane", tl("Soumettre"), `data-tooltip="${tl("Soumettre pour validation & verrouillage")}"`) + btnStock };
    };

    const rows = actors.map(a => {
        const st = statutDe(a);
        const i = infos(a);
        const ligne2 = [i.niveau ? tl("Niveau {0}", i.niveau) : "", i.espece, i.classes.join(" / ")].filter(Boolean).map(esc).join(" · ");
        const puces = [
            i.pvMax ? `<span class="scwm-cvh-puce" data-tooltip="${tl("Points de vie (actuels / maximum)")}"><i class="fa-solid fa-heart"></i> ${tl("PV")} <b>${i.pv ?? "?"}/${i.pvMax}</b></span>` : "",
            i.ca ? `<span class="scwm-cvh-puce" data-tooltip="${tl("Classe d'armure")}"><i class="fa-solid fa-shield"></i> ${tl("CA")} <b>${i.ca}</b></span>` : "",
            i.po != null ? `<span class="scwm-cvh-puce" data-tooltip="${esc(tl("Fortune totale convertie en pièces d'or{0}", i.poDetail ? ` (${i.poDetail})` : ""))}"><i class="fa-solid fa-coins"></i> <b>${i.po.toLocaleString(game.i18n?.lang || "fr")}</b> ${tl("po")}</span>` : ""
        ].join("");
        let xp = "";
        if (starXpEnabled()) {
            // Système d'étoiles : l'XP dnd5e ne sert qu'à piloter le bouton de
            // montée de niveau (0 ou max) ; on affiche donc les ÉTOILES.
            const p = progressFor(a);
            if (p.max) {
                xp = `<div class="scwm-cvh-xp scwm-cvh-etoiles"><small><i class="fa-solid fa-crown"></i> ${tl("Niveau maximum atteint")}</small></div>`;
            } else {
                const pct = Math.round(100 * Math.min(p.stars, p.threshold) / Math.max(1, p.threshold));
                xp = `<div class="scwm-cvh-xp scwm-cvh-etoiles${p.ready ? " scwm-cvh-xp-pret" : ""}" data-tooltip="${tl("Étoiles vers le niveau {0} : {1} / {2}", p.level + 1, p.stars, p.threshold)}">
                    <div class="scwm-cvh-xp-barre"><span style="width:${pct}%"></span></div>
                    <small><i class="fa-solid fa-star"></i> ${p.ready ? tl("✨ Prêt à monter au niveau {0} !", p.level + 1) : tl("{0} / {1} étoiles vers le niveau {2}", p.stars, p.threshold, p.level + 1)}</small>
                </div>`;
            }
        } else if (i.xpMax && i.pct != null) {
            const pret = canLevelUp(a);
            xp = `<div class="scwm-cvh-xp${pret ? " scwm-cvh-xp-pret" : ""}" data-tooltip="${tl("Expérience : {0} / {1}", i.xpVal, i.xpMax)}">
                <div class="scwm-cvh-xp-barre"><span style="width:${i.pct}%"></span></div>
                <small>${pret ? tl("✨ Niveau supérieur disponible !") : tl("XP {0} / {1}", i.xpVal, i.xpMax)}</small>
            </div>`;
        }
        return `<article class="scwm-cvh-carte scwm-cvh-${st.cle}">
            <button type="button" class="scwm-cv-act scwm-cvh-portrait" data-act="open" data-id="${a.id}" data-tooltip="${tl("Ouvrir la fiche")}">
                <img src="${esc(a.img)}" alt="">
            </button>
            <div class="scwm-cvh-corps">
                <div class="scwm-cvh-tete">
                    <h4>${esc(a.name)}</h4>
                    <span class="scwm-cvh-statut" data-tooltip="${esc(st.aide)}"><i class="fa-solid ${st.icone}"></i> ${st.texte}</span>
                </div>
                ${ligne2 ? `<p class="scwm-cvh-sous">${ligne2}</p>` : ""}
                ${i.histo ? `<p class="scwm-cvh-histo"><i class="fa-solid fa-scroll"></i> ${esc(i.histo)}</p>` : ""}
                ${puces ? `<div class="scwm-cvh-puces">${puces}</div>` : ""}
                ${xp}
                <div class="scwm-cvh-actions">
                    ${bouton("open", a.id, "fa-id-card", tl("Fiche"), "", "scwm-cvh-discret")}
                    ${st.btns}
                </div>
            </div>
        </article>`;
    }).join("") || `<div class="scwm-cvh-vide"><i class="fa-solid fa-feather-pointed"></i><p>${tl("Vous n'avez pas encore de personnage. Demandez-en un pour commencer l'aventure !")}</p></div>`;

    const jauge = (n, max) => Array.from({ length: max }, (_, k) => `<span class="${k < n ? "plein" : ""}"></span>`).join("");
    const counters = `<div class="scwm-cvh-compteurs">
        <span class="scwm-cvh-compteur" data-tooltip="${tl("Personnages jouables en même temps")}">${tl("Actifs")} <b>${nbActive}/${limActive}</b> <span class="scwm-cvh-jauge">${limActive <= 10 ? jauge(nbActive, limActive) : ""}</span></span>
        ${limTotal > 0 ? `<span class="scwm-cvh-compteur" data-tooltip="${tl("Personnages au total (actifs + en stock)")}">${tl("Total")} <b>${actors.length}/${limTotal}</b> <span class="scwm-cvh-jauge">${limTotal <= 10 ? jauge(actors.length, limTotal) : ""}</span></span>` : ""}
    </div>`;

    let createBlock;
    if (req) {
        createBlock = `<div class="scwm-cvh-demande">
            <i class="fa-solid fa-envelope-open-text"></i>
            <div><b>${tl("Demande en attente")}</b><br><small>${tl("« {0} » attend l'accord d'un MJ.", esc(req.name))}</small></div>
            ${bouton("cancel", "", "fa-times", tl("Annuler"), "", "scwm-cvh-discret")}
        </div>`;
    } else if (atTotalLimit) {
        createBlock = `<p class="scwm-cvh-limite"><i class="fa-solid fa-circle-info"></i> ${tl("Nombre maximum de personnages atteint ({0}).", limTotal)}</p>`;
    } else {
        createBlock = `<button type="button" class="scwm-cv-act scwm-cvh-nouveau" data-act="newreq"><i class="fa-solid fa-plus"></i> ${tl("Demander un nouveau personnage")}</button>`;
    }

    const content = `<div class="scwm-cv-hub scwm-cvh">
        <header class="scwm-cvh-entete">
            <span class="scwm-cvh-embleme" aria-hidden="true"><i class="fa-solid fa-boxes-stacked"></i></span>
            <div>
                <h3>${tl("Mes personnages")}</h3>
                <small>${tl("Le casier de {0}", esc(game.user.name))}</small>
            </div>
        </header>
        ${counters}
        <div class="scwm-cvh-liste">${rows}</div>
        ${createBlock}
    </div>`;

    const dlg = new Dialog({
        title: tl("Mon casier"),
        icon: "fa-solid fa-id-card",
        content,
        buttons: { close: { icon: '<i class="fa-solid fa-times"></i>', label: tl("Fermer") } },
        render: (html) => {
            const root = html[0] ?? html;
            const run = async (a, id) => {
                const ac = id ? game.actors.get(id) : null;
                if (a === "newreq") { dlg.close(); promptNewCharRequest(); return; }
                if (a === "cancel") { await game.user.unsetFlag(MOD, "charRequest"); }
                else if (a === "open") { ac?.sheet.render(true); return; }   // garder le hub ouvert
                else if (a === "activate") {
                    if (activeCountForUser(game.user.id) >= maxActive()) {
                        ui.notifications?.warn(tl("Vous avez déjà {0} personnage(s) actif(s). Mettez-en un en stock d'abord.", maxActive()));
                        return;
                    }
                    await requestCharStock(id, false);
                    ui.notifications?.info(tl("{0} activé.", ac?.name ?? tl("Personnage")));
                }
                else if (a === "stock") {
                    await requestCharStock(id, true);
                    ui.notifications?.info(tl("{0} mis en stock.", ac?.name ?? tl("Personnage")));
                }
                else if (a === "submit" && ac) {
                    await ac.setFlag(MOD, "pendingValidation", true);
                    ChatMessage.create({ whisper: gmIds(), speaker: { alias: tl("Validation") }, content: `${tl("📩 <strong>{0}</strong> soumet <strong>{1}</strong> pour validation.", esc(game.user.name), esc(ac.name))}` });
                    if (!ac.getFlag(MOD, "levelUpSnapshot"))
                        notifierDiscord(tl("📩 **{0}** soumet **{1}** pour validation.", md(game.user.name), md(ac.name)));
                    // Si c'est une re-soumission après montée de niveau : liste des modifs
                    // (chuchotée au MJ + stockée pour le dépliant du Casier).
                    const snap = ac.getFlag(MOD, "levelUpSnapshot");
                    if (snap) {
                        const changes = buildDiff(snap, buildSnapshot(ac));
                        postLevelUpDiff(ac, changes);
                        notifierDiscord([
                            tl("📩 **{0}** re-soumet **{1}** après une montée de niveau :", md(game.user.name), md(ac.name)),
                            ...(changes.length ? listeDiscord(changes) : [tl("_Aucune modification de construction détectée._")])
                        ]);
                        await ac.setFlag(MOD, "levelUpChanges", changes);
                    }
                    ui.notifications?.info(tl("Fiche soumise pour validation."));
                } else if (a === "levelup" && ac) {
                    // Auto-déverrouillage : le joueur monte de niveau lui-même. Les
                    // modifications sont tracées (liste au MJ), donc plus besoin
                    // d'un accord préalable du MJ.
                    await ac.update({
                        [`flags.${MOD}.levelUpGranted`]: true,
                        [`flags.${MOD}.locked`]: false,
                        [`flags.${MOD}.pendingLevelUp`]: false,
                        [`flags.${MOD}.levelUpSnapshot`]: buildSnapshot(ac)
                    });
                    if (freeLevelUp()) {
                        ui.notifications?.info(tl("Fiche déverrouillée : faites votre avancement (bouton de montée de niveau dnd5e/Plutonium), puis cliquez « Terminer »."));
                    } else {
                        ChatMessage.create({ whisper: gmIds(), speaker: { alias: tl("Validation") }, content: `${tl("⬆️ <strong>{0}</strong> effectue une <strong>montée de niveau</strong> pour <strong>{1}</strong> (déverrouillage auto ; les modifications seront listées à la re-soumission).", esc(game.user.name), esc(ac.name))}` });
                        notifierDiscord(tl("⬆️ **{0}** commence une montée de niveau pour **{1}** (les modifications seront listées à la re-soumission).", md(game.user.name), md(ac.name)));
                        ui.notifications?.info(tl("Fiche déverrouillée pour la montée de niveau. Effectuez-la, puis re-soumettez-la pour re-verrouiller."));
                    }
                } else if (a === "finishFree" && ac) {
                    // MODE CONFIANCE : fin de montée de niveau → re-verrouille SANS
                    // validation MJ. Notifie le MJ (avec le récap) si l'option est active.
                    const snap = ac.getFlag(MOD, "levelUpSnapshot");
                    await ac.update({
                        [`flags.${MOD}.locked`]: true,
                        [`flags.${MOD}.levelUpGranted`]: false,
                        [`flags.${MOD}.pendingLevelUp`]: false,
                        [`flags.${MOD}.-=levelUpSnapshot`]: null,
                        [`flags.${MOD}.-=levelUpChanges`]: null
                    });
                    if (snap && notifyLevelUp()) {
                        try {
                            const changes = buildDiff(snap, buildSnapshot(ac));
                            postLevelUpDiff(ac, changes);
                            notifierDiscord([
                                tl("⬆️ **{0}** a terminé une montée de niveau libre pour **{1}** :", md(game.user.name), md(ac.name)),
                                ...(changes.length ? listeDiscord(changes) : [tl("_Aucune modification de construction détectée._")])
                            ]);
                        } catch (e) {}
                    }
                    ui.notifications?.info(tl("Montée de niveau terminée — fiche re-verrouillée."));
                }
                dlg.close();
            };
            root.querySelectorAll(".scwm-cv-act").forEach(b => b.addEventListener("click", () => run(b.dataset.act, b.dataset.id)));
        }
    }, { width: 560, classes: ["scwm-cvh-fenetre"] });
    dlg.render(true);
}

// ============================================================
// HOOKS
// ============================================================
// MJ « primaire » : le seul client autorisé à muter le monde (création de
// dossiers) pour éviter les doublons quand plusieurs MJ sont connectés.
const isPrimaryGM = () => !!game.user?.isGM && game.users?.activeGM?.id === game.user.id;

// Nettoyage : fusionne les dossiers en double (même type + même nom + même
// parent). Le contenu (acteurs, sous-dossiers) est déplacé dans le plus ancien,
// puis les doublons vides sont supprimés. À lancer une fois par un MJ :
//   game.modules.get("soruta-completed-westmarch").api.dedupeFolders()
export async function dedupeAutoFolders() {
    if (!game.user.isGM) { ui.notifications?.warn(tl("Réservé au MJ.")); return; }
    const groups = new Map();
    for (const f of (game.folders ?? [])) {
        const key = `${f.type}|${f.name}|${f.folder?.id ?? ""}`;
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key).push(f);
    }
    let removed = 0;
    for (const arr of groups.values()) {
        if (arr.length < 2) continue;
        arr.sort((a, b) => (a._stats?.createdTime ?? 0) - (b._stats?.createdTime ?? 0) || a.id.localeCompare(b.id));
        const keep = arr[0];
        for (const dup of arr.slice(1)) {
            try {
                for (const doc of (dup.contents ?? [])) { try { await doc.update({ folder: keep.id }); } catch (e) {} }
                for (const sub of (game.folders?.filter(x => (x.folder?.id ?? null) === dup.id) ?? [])) {
                    try { await sub.update({ folder: keep.id }); } catch (e) {}
                }
                await dup.delete();
                removed++;
            } catch (e) { journal.avert(tl("[{0}] dédoublonnage « {1} » :", MOD, dup.name), e); }
        }
    }
    ui.notifications?.info(tl("[{0}] Dédoublonnage terminé : {1} dossier(s) en double fusionné(s).", MOD, removed));
    return removed;
}

export function CharValidationHooks() {
    // Requête d'(dés)activation d'un personnage — traitée par le GM.
    CONFIG.queries["westmarch.charStock"] = async ({ actorId, stock }) => { await applyCharStock(actorId, stock); return true; };

    // ---- Sous-dossier auto au nom du joueur (Dossier des PJ) ----
    // IMPORTANT : la création de dossiers est réservée au MJ PRIMAIRE
    // (game.users.activeGM). Sinon, chaque client MJ connecté crée les mêmes
    // dossiers en parallèle → doublons. Un seul client fait autorité.
    Hooks.on("userConnected", (user, connected) => {
        if (!connected || !isPrimaryGM()) return;
        if (user.isGM) ensureGmFolders(user);
        else ensurePlayerPJFolder(user);
    });
    // Passe initiale : couvre les joueurs/MJ déjà connectés. Toujours un seul
    // client (le MJ primaire) pour éviter les doublons.
    Hooks.once("ready", () => {
        // Expose le dédoublonnage manuel : game.modules.get("…").api.dedupeFolders()
        const mod = game.modules.get(MOD);
        if (mod) mod.api = { ...(mod.api ?? {}), dedupeFolders: dedupeAutoFolders };

        if (!isPrimaryGM()) return;
        ensureGmFolders(game.user);
        for (const u of (game.users ?? [])) {
            if (!u.active) continue;
            if (u.isGM) ensureGmFolders(u);
            else ensurePlayerPJFolder(u);
        }
    });

    // Bouton dans la barre WestMarch pour les JOUEURS.
    Hooks.on("getSceneControlButtons", (controls) => {
        if (!enabled()) return;
        if (game.user.isGM) return;
        if (!controls.westmarch) {
            controls.westmarch = { name: "westmarch", title: "WestMarch", icon: "fa-solid fa-hammer", layer: "tokens", tools: {} };
        }
        controls.westmarch.tools.charValidation = {
            name: "charValidation",
            title: tl("Mon personnage — demande / validation"),
            icon: "fa-solid fa-id-card",
            button: true,
            onChange: () => openPlayerHub(),
            visible: true
        };
    });

    // ---- Verrou sélectif (non-GM, fiche verrouillée) ----
    Hooks.on("preUpdateActor", (actor, changes, options, userId) => {
        if (game.user.isGM || userId !== game.user.id) return;
        if (!enabled() || !isLocked(actor)) return;
        if (freeLevelUp()) return;   // mode confiance : construction libre après validation
        // On ne bloque que si une valeur de CONSTRUCTION change RÉELLEMENT. Comparer
        // à la valeur actuelle évite de rejeter une soumission qui renvoie des champs
        // inchangés (ex. l'enregistrement de la BIOGRAPHIE peut inclure caracs/maîtrises
        // inchangées) → la bio et tout le reste du jeu restent éditables.
        const flat = foundry.utils.flattenObject(changes);
        const constructionChanged = Object.keys(flat).some(k =>
            BLOCKED_ACTOR_PATHS.some(p => k === p || k.startsWith(p + ".")) &&
            !foundry.utils.objectsEqual(flat[k], foundry.utils.getProperty(actor, k)));
        if (constructionChanged) {
            ui.notifications?.warn(tl("Fiche validée : caractéristiques et maîtrises verrouillées. Demandez une modification au MJ."));
            setTimeout(() => actor.sheet?.render(false), 30);   // reverte l'affichage optimiste
            return false;
        }
    });

    // Message d'avertissement quand on tente de forcer une montée de niveau
    // (ajout de classe / sous-classe / features / sorts) sur une fiche VERROUILLÉE,
    // au lieu de passer par le bouton dédié. S'applique AUSSI en mode confiance :
    // le mode confiance retire la validation MJ, PAS la bonne méthode de montée.
    const levelUpWarn = (actor) => {
        const via = freeLevelUp()
            ? tl("Cliquez sur « Monter de niveau » dans « Mon personnage » (barre d'outils WestMarch) : la fiche se déverrouille, faites votre avancement, puis « Terminer ».")
            : tl("Cliquez sur « Monter de niveau » dans « Mon personnage » et suivez la procédure (le MJ valide ensuite).");
        ui.notifications?.warn(tl("⚠️ Ce n'est pas ainsi qu'on monte de niveau ! {0}", via), { permanent: false });
        setTimeout(() => actor.sheet?.render(false), 30);   // reverte l'affichage optimiste
    };

    Hooks.on("preUpdateItem", (item, changes, options, userId) => {
        if (game.user.isGM || userId !== game.user.id) return;
        if (!enabled()) return;
        const actor = item.parent;
        if (!actor || !isLocked(actor)) return;   // fiche déverrouillée (montée en cours) = autorisé
        if (!BUILD_ITEM_TYPES.has(item.type)) return;   // inventaire / butin = jeu
        const sys = changes.system;
        if (!sys) return;                                // changement non mécanique
        const allowed = ITEM_PLAY_KEYS[item.type] ?? [];
        if (Object.keys(sys).every(k => allowed.includes(k))) return;   // uniquement du jeu
        levelUpWarn(actor);
        return false;
    });

    const blockBuildItemCD = (item, _d, _o, userId) => {
        if (game.user.isGM || userId !== game.user.id) return;
        if (!enabled()) return;
        const actor = item.parent;
        if (!actor || !isLocked(actor)) return;   // fiche déverrouillée = autorisé
        if (BUILD_ITEM_TYPES.has(item.type)) {
            levelUpWarn(actor);
            return false;
        }
    };
    Hooks.on("preCreateItem", blockBuildItemCD);
    Hooks.on("preDeleteItem", blockBuildItemCD);

    // Bloque les imports PLUTONIUM sur une fiche verrouillée (les items importés
    // via Plutonium portent un flag "plutonium"). Autorisé pendant les fenêtres
    // de création / montée de niveau (fiche déverrouillée). GM jamais bloqué.
    Hooks.on("preCreateItem", (item, data, options, userId) => {
        if (game.user.isGM || userId !== game.user.id) return;
        if (!enabled() || !game.settings.get(MOD, "blockPlayerPlutonium")) return;
        const actor = item.parent;
        if (!actor || !isLocked(actor)) return;   // création / level-up autorisés
        const flags = data?.flags ?? item?.flags ?? {};
        const isPluto = Object.keys(flags).some(k => k.toLowerCase().includes("plutonium"));
        if (isPluto) {
            ui.notifications?.warn(tl("Import Plutonium bloqué : cette fiche est verrouillée. Demandez au MJ d'autoriser une création ou une montée de niveau."));
            return false;
        }
    });

    // ---- Notification des montées de niveau libres (mode confiance) ----
    Hooks.on("createItem", (item, _o, userId) => {
        const a = item.parent; if (!_luActive(a, userId)) return;
        if (BUILD_ITEM_TYPES.has(item.type)) _queueLuNote(a, `Ajout : ${item.name} (${item.type})`);
    });
    Hooks.on("deleteItem", (item, _o, userId) => {
        const a = item.parent; if (!_luActive(a, userId)) return;
        if (BUILD_ITEM_TYPES.has(item.type)) _queueLuNote(a, `Retrait : ${item.name}`);
    });
    Hooks.on("updateItem", (item, changes, _o, userId) => {
        const a = item.parent; if (!_luActive(a, userId)) return;
        if (item.type === "class") {
            const lv = foundry.utils.getProperty(changes, "system.levels");
            if (lv != null) _queueLuNote(a, `${item.name} → niveau ${lv}`);
        }
    });
    Hooks.on("updateActor", (actor, changes, _o, userId) => {
        if (!_luActive(actor, userId)) return;
        const lvl = foundry.utils.getProperty(changes, "system.details.level");
        if (lvl != null) _queueLuNote(actor, `Niveau : ${lvl}`);
        const ab = foundry.utils.getProperty(changes, "system.abilities");
        if (ab && typeof ab === "object") {
            for (const k of Object.keys(ab)) {
                if (ab[k]?.value != null) _queueLuNote(actor, `${_abilLabel(k)} : ${ab[k].value}`);
            }
        }
    });

    // ---- Badge d'état dans le répertoire des Acteurs (entre le nom et le
    //      statut d'expédition) : « À valider » / « Level up ». ----
    Hooks.on("renderActorDirectory", (app, html) => {
        const root = html instanceof HTMLElement ? html : html?.[0];
        if (root) injectValidationBadges(root);
    });
    Hooks.on("updateActor", (actor, changes) => {
        const f = changes?.flags?.[MOD];
        if (f && ("pendingValidation" in f || "pendingLevelUp" in f || "locked" in f || "validated" in f || "createdFor" in f || "stock" in f || "levelUpGranted" in f)) ui.actors?.render();
    });
    // Nouvelle fiche créée.
    Hooks.on("createActor", async (actor, options, userId) => {
        // Rangement des créatures importées de compendium (indépendant du reste).
        placeImportedCreature(actor, userId);
        // Rangement dans le compendium des créatures : Type → CR (option).
        rangerCreatureCompendium(actor, userId);
        // Déjà rattachée à un joueur (ex. validation d'une demande) → juste rafraîchir.
        if (actor?.getFlag?.(MOD, "createdFor")) { ui.actors?.render(); return; }
        // PJ créé DIRECTEMENT par le GM dans le sous-dossier d'un joueur :
        // on saute la demande / validation → fiche d'emblée VALIDÉE et VERROUILLÉE.
        if (!enabled()) return;
        if (userId !== game.user.id || !game.user.isGM) return;   // seul le GM créateur agit
        if (actor.type !== "character") return;
        const user = findPlayerForActorFolder(actor);
        if (!user) return;
        const L = CONST.DOCUMENT_OWNERSHIP_LEVELS;
        await actor.update({
            ownership: { ...actor.ownership, [user.id]: L.OWNER },
            [`flags.${MOD}.createdFor`]:       user.id,
            [`flags.${MOD}.validated`]:        true,
            [`flags.${MOD}.locked`]:           true,
            [`flags.${MOD}.pendingValidation`]: false,
            [`flags.${MOD}.stock`]:            false
        });
        ChatMessage.create({
            whisper: [user.id],
            speaker: { alias: tl("Validation") },
            content: `${tl("<strong>{0}</strong> a été créé et validé par le MJ. La fiche est verrouillée : tu peux jouer, mais les modifications de construction passent par le MJ.", actor.name)}`
        });
        ui.actors?.render();
    });
}

function injectValidationBadges(root) {
    if (!enabled()) return;
    const items = root.querySelectorAll("li.directory-item[data-entry-id], li.directory-item[data-document-id]");
    for (const li of items) {
        const id = li.dataset.entryId ?? li.dataset.documentId;
        const actor = game.actors?.get(id);
        if (!actor || actor.type !== "character") continue;

        li.querySelector(":scope .scwm-cv-badge")?.remove();

        const validated  = actor.getFlag(MOD, "validated") === true;
        const pending    = actor.getFlag(MOD, "pendingValidation") === true;
        const createdFor = actor.getFlag(MOD, "createdFor");
        const levelup    = actor.getFlag(MOD, "pendingLevelUp") === true;

        let b = null;
        if (actor.getFlag(MOD, "stock") === true) b = { cls: "stock", label: "Stock", icon: "fa-lock" };
        else if (pending)                     b = { cls: "pending",  label: tl("À valider"),     icon: "fa-hourglass-half" };
        else if (createdFor && !validated)    b = { cls: "creating", label: tl("En création"),   icon: "fa-user-pen" };
        else if (actor.getFlag(MOD, "levelUpGranted") === true) b = { cls: "building", label: tl("En construction"), icon: "fa-hammer" };
        else if (levelup)                     b = { cls: "levelup",  label: "Level up",      icon: "fa-arrow-up-1-9" };
        if (!b) continue;

        const span = document.createElement("span");
        span.className = `scwm-cv-badge scwm-cv-badge-${b.cls}`;
        span.title = b.label;
        span.innerHTML = `<i class="fa-solid ${b.icon}"></i><span class="scwm-cv-badge-label">${b.label}</span>`;

        const nameEl = li.querySelector(".entry-name, .document-name");
        if (nameEl) nameEl.insertAdjacentElement("afterend", span);
        else li.appendChild(span);
    }
}
