// ============================================================
// map.js — Carte des expéditions : BROUILLARD MAISON par personnage
//
// Contrairement au brouillard natif de Foundry (une seule fog par compte,
// impossible à isoler par perso), on gère tout nous-mêmes :
//   - les zones révélées sont stockées PAR PERSONNAGE (flag exploredHexes,
//     un ensemble de clés de case hex "i.j") ;
//   - chaque client dessine son propre calque noir par-dessus la carte, avec
//     des trous aux cases explorées du PERSO qu'il joue → isolation parfaite ;
//   - le MJ révèle en déplaçant un token de GROUPE : les cases parcourues
//     (+ un rayon réglable) s'ajoutent aux persos MEMBRES du groupe.
//
// La vision/brouillard natifs de la scène sont désactivés (on les remplace).
// © 2026 Soruta.
// ============================================================

import { MOD } from "./const.js";

import { journal } from "./log.js";
import { tl, memeNom } from "./i18n.js";
import { verifierAdmin } from "./adminpass.js";
const FLAG_EXPLORED = "exploredHexes";           // sur l'acteur personnage
const TEMPLATE_GROUP_NAME = tl("Token à copier et rennomer");

const enabled  = () => game.settings.get(MOD, "enableExpeditionMap");

// ── Scènes de carte d'expédition (multi-cartes, ex. archipel) ────────────────
const legacySceneId = () => game.settings.get(MOD, "expeditionMapSceneId");
const extraSceneIds = () => {
    const v = game.settings.get(MOD, "expeditionMapSceneIds");
    return Array.isArray(v) ? v.filter(Boolean) : [];
};
// Ensemble des scènes traitées comme carte : scène principale + supplémentaires.
export const expeditionSceneIds = () => {
    const s = new Set(extraSceneIds());
    const leg = legacySceneId();
    if (leg) s.add(leg);
    return [...s];
};
const isExpeditionScene = (id) => !!id && expeditionSceneIds().includes(id);
const currentSceneId = () => canvas?.scene?.id ?? null;
const onExpeditionCanvas = () => enabled() && isExpeditionScene(currentSceneId());

// ── Brouillard exploré, stocké PAR SCÈNE sur l'acteur : { [sceneId]: [clés] }.
//    Compat : un ancien tableau plat est rattaché à la scène principale héritée.
export function exploredMap(actor) {
    const raw = actor?.getFlag(MOD, FLAG_EXPLORED);
    if (Array.isArray(raw)) { const leg = legacySceneId(); return leg ? { [leg]: raw } : {}; }
    return (raw && typeof raw === "object") ? raw : {};
}
export function getExplored(actor, sid) {
    if (!sid) return [];
    const m = exploredMap(actor);
    return Array.isArray(m[sid]) ? m[sid] : [];
}
async function setExplored(actor, sid, keysArr) {
    if (!sid) return;
    const m = exploredMap(actor);
    m[sid] = keysArr;
    await actor.setFlag(MOD, FLAG_EXPLORED, m);
}

// ── Zones toujours éclairées (villes), PAR SCÈNE : { [sceneId]: [clés] }.
export function zonesMap() {
    const raw = game.settings.get(MOD, "expeditionRevealedZones");
    if (Array.isArray(raw)) { const leg = legacySceneId(); return leg ? { [leg]: raw } : {}; }
    return (raw && typeof raw === "object") ? raw : {};
}
async function setZonesForScene(sid, keysArr) {
    if (!sid) return;
    const m = zonesMap();
    m[sid] = keysArr;
    await game.settings.set(MOD, "expeditionRevealedZones", m);
}

// Case (offset hex) précédente des tokens (pour tracer le trajet au déplacement).
const _prevHex = new Map();

export function MapHooks() {

    Hooks.once("ready", async () => {
        // Expose la réinitialisation pour la console : game.modules.get("…").api.resetExpeditionFog()
        const mod = game.modules.get(MOD);
        if (mod) mod.api = { ...(mod.api ?? {}), resetExpeditionFog };
        if (!enabled() || !game.user.isGM) return;
        await ensureTemplateGroupActor();
        await removeLegacyAnchor();
        await disableNativeSceneFog();
    });

    // Mémorise la position AVANT déplacement (pour tracer le trajet).
    Hooks.on("preUpdateToken", (tokenDoc, changes) => {
        if (!game.user.isGM || !enabled()) return;
        if (!("x" in changes || "y" in changes)) return;
        if (!isExpeditionScene(tokenDoc.parent?.id) || tokenDoc.actor?.type !== "group") return;
        _prevHex.set(tokenDoc.id, tokenHex(tokenDoc));
    });

    // Déplacement d'un token de GROUPE → révèle les cases du trajet pour ses membres.
    Hooks.on("updateToken", async (tokenDoc, changes) => {
        if (!game.user.isGM || !enabled()) return;
        if (!("x" in changes || "y" in changes)) return;
        if (!isExpeditionScene(tokenDoc.parent?.id) || tokenDoc.actor?.type !== "group") return;
        await revealForGroupMove(tokenDoc, changes);
    });

    // ---- Rendu du calque (tous les clients) ----
    Hooks.on("canvasReady", () => drawFog());
    Hooks.on("updateActor", (actor, changes) => {
        if (!foundry.utils.hasProperty(changes, `flags.${MOD}.${FLAG_EXPLORED}`)) return;
        if (actor.id === game.user.character?.id) drawFog();
    });
    Hooks.on("updateUser", (user, changes) => {
        if (user.id === game.user.id && "character" in changes) drawFog();
    });
    // Zones toujours éclairées modifiées → tous les clients redessinent.
    Hooks.on("updateSetting", (setting) => {
        if (setting?.key === `${MOD}.expeditionRevealedZones`) drawFog();
    });

    // ---- Duplication d'un token/acteur de groupe modèle → fenêtre de renommage ----
    // Le modèle porte le flag templateGroupToken. Sa COPIE le porte aussi : on la
    // détecte (il existe alors 2+ acteurs avec ce flag), on propose un renommage,
    // et on retire le flag de la copie (elle devient un vrai groupe d'expédition).
    Hooks.on("createActor", async (actor, options, userId) => {
        if (!game.user.isGM || userId !== game.user.id) return;
        if (actor.type !== "group") return;
        if (actor.getFlag(MOD, "templateGroupToken") !== true) return;
        const templates = game.actors.filter(a => a.type === "group" && a.getFlag(MOD, "templateGroupToken") === true);
        if (templates.length <= 1) return;   // c'est le modèle unique (créé par le module)
        await promptRenameGroup(actor);       // c'est une copie du modèle
    });

    // ---- Permissions du token/acteur de GROUPE ----
    // Quand on ajoute (ou retire) un PJ aux membres d'un groupe, on met à jour
    // l'OWNERSHIP du groupe : chaque joueur propriétaire d'un PJ membre passe
    // Observateur sur le groupe → il voit le token de groupe et son brouillard.
    Hooks.on("updateActor", async (actor, changes) => {
        if (!game.user.isGM) return;
        if (actor.type !== "group") return;
        if (!foundry.utils.hasProperty(changes, "system.members")) return;
        await syncGroupOwnership(actor);
    });

    // ---- Bouton MJ : réinitialiser le brouillard (onglet WestMarch) ----
    Hooks.on("getSceneControlButtons", (controls) => {
        if (!game.user.isGM || !enabled()) return;
        if (!controls.westmarch) {
            controls.westmarch = { name: "westmarch", title: "WestMarch", icon: "fa-solid fa-hammer", layer: "tokens", tools: {} };
        }
        controls.westmarch.tools.scwmFogReset = {
            name: "scwmFogReset",
            title: tl("Carte d'expédition — Réinitialiser le brouillard"),
            icon: "fa-solid fa-eraser",
            button: true,
            visible: true,
            onChange: () => openFogResetDialog()
        };
        controls.westmarch.tools.scwmLightZone = {
            name: "scwmLightZone",
            title: tl("Carte d'expédition — Éclairer une zone (villes) : clic gauche = éclairer, clic droit = masquer"),
            icon: "fa-solid fa-city",
            toggle: true,
            active: _paintMode,
            visible: true,
            onChange: (event, active) => setPaintMode(active)
        };
    });

    // Écouteur de peinture (une fois par canvas prêt).
    Hooks.on("canvasReady", () => {
        const view = canvas?.app?.view;
        if (!view) return;
        view.removeEventListener("pointerdown", onPaintPointerDown, true);
        view.addEventListener("pointerdown", onPaintPointerDown, true);
    });
}

// ============================================================
// Zones toujours éclairées (villes) — peinture MJ
// ============================================================
let _paintMode = false;

function setPaintMode(on) {
    _paintMode = !!on;
    ui.notifications?.info(_paintMode
        ? tl("Éclairage permanent : clic GAUCHE = éclairer une case, clic DROIT = masquer.")
        : tl("Éclairage permanent désactivé."));
    drawFog();   // (ré)affiche le repère des zones éclairées côté MJ
}

// Zones toujours éclairées de la SCÈNE COURANTE.
function globalZones() {
    const sid = currentSceneId();
    const m = zonesMap();
    return sid && Array.isArray(m[sid]) ? m[sid] : [];
}

async function onPaintPointerDown(ev) {
    if (!_paintMode || !game.user.isGM) return;
    if (!onExpeditionCanvas()) return;
    if (ev.button !== 0 && ev.button !== 2) return;
    ev.preventDefault();
    ev.stopPropagation();

    const rect = canvas.app.view.getBoundingClientRect();
    const world = canvas.stage.toLocal(new PIXI.Point(ev.clientX - rect.left, ev.clientY - rect.top));
    const key = hexKey(canvas.grid.getOffset(world));

    const set = new Set(globalZones());
    if (ev.button === 0) set.add(key); else set.delete(key);   // gauche éclaire, droit masque
    await setZonesForScene(currentSceneId(), [...set]);
    // Le hook updateSetting n'existe pas partout → on redessine directement + broadcast implicite
    drawFog();
}

// ============================================================
// Géométrie hex
// ============================================================
// Case (offset hex) OCCUPÉE par le token : on part du centre de sa boîte englobante
// (toujours à l'intérieur de la case) puis on demande à la grille la case exacte.
function tokenHex(tokenDoc, x = tokenDoc.x, y = tokenDoc.y) {
    const sx = canvas.grid.sizeX ?? canvas.grid.size;
    const sy = canvas.grid.sizeY ?? canvas.grid.size;
    const bc = { x: x + (tokenDoc.width ?? 1) * sx / 2, y: y + (tokenDoc.height ?? 1) * sy / 2 };
    return canvas.grid.getOffset(bc);
}
// Centre EXACT (aligné grille) d'une case, pour l'échantillonnage du trajet.
function hexCenter(offset) { return canvas.grid.getCenterPoint(offset); }

function hexKey(offset) { return `${offset.i}.${offset.j}`; }

// Voisins immédiats d'une case (échantillonne 6 directions autour du centre).
function neighborOffsets(offset) {
    const c = canvas.grid.getCenterPoint(offset);
    const r = canvas.grid.size;
    const out = [];
    for (let a = 0; a < 360; a += 30) {
        const rad = (a * Math.PI) / 180;
        const off = canvas.grid.getOffset({ x: c.x + r * Math.cos(rad), y: c.y + r * Math.sin(rad) });
        out.push(off);
    }
    return out;
}

// Toutes les cases dans un rayon de `radius` anneaux autour d'une case (BFS).
function hexesWithinRadius(centerOffset, radius) {
    const seen = new Set([hexKey(centerOffset)]);
    const result = [centerOffset];
    let frontier = [centerOffset];
    for (let ring = 0; ring < radius; ring++) {
        const next = [];
        for (const o of frontier) {
            for (const n of neighborOffsets(o)) {
                const k = hexKey(n);
                if (!seen.has(k)) { seen.add(k); result.push(n); next.push(n); }
            }
        }
        frontier = next;
    }
    return result;
}

// Cases traversées par le déplacement (échantillonnage de la ligne) + rayon.
function revealedHexKeys(fromCenter, toCenter, radius) {
    const keys = new Set();
    const step = canvas.grid.size / 2;
    const dx = toCenter.x - fromCenter.x, dy = toCenter.y - fromCenter.y;
    const dist = Math.hypot(dx, dy);
    const n = Math.max(1, Math.ceil(dist / step));
    for (let s = 0; s <= n; s++) {
        const p = { x: fromCenter.x + (dx * s) / n, y: fromCenter.y + (dy * s) / n };
        const off = canvas.grid.getOffset(p);
        for (const h of hexesWithinRadius(off, radius)) keys.add(hexKey(h));
    }
    return [...keys];
}

// ============================================================
// Révélation (MJ)
// ============================================================
async function revealForGroupMove(tokenDoc, changes = {}) {
    // IMPORTANT : au moment de updateToken, tokenDoc.x/y peut encore refléter
    // l'ANCIENNE position (animation) → on prend la position d'arrivée dans `changes`.
    const nx = Number.isFinite(changes.x) ? changes.x : tokenDoc.x;
    const ny = Number.isFinite(changes.y) ? changes.y : tokenDoc.y;
    const toOff = tokenHex(tokenDoc, nx, ny);                  // case d'arrivée (où il VA)
    const fromOff = _prevHex.get(tokenDoc.id) ?? toOff;        // case de départ
    _prevHex.delete(tokenDoc.id);

    const radius = Math.max(0, Number(game.settings.get(MOD, "expeditionRevealRadius")) || 0);
    // Trajet (centres de case alignés grille) + garantie explicite de la case d'arrivée.
    const keys = new Set(revealedHexKeys(hexCenter(fromOff), hexCenter(toOff), radius));
    for (const h of hexesWithinRadius(toOff, radius)) keys.add(hexKey(h));
    if (!keys.size) return;

    const sid = tokenDoc.parent?.id;                         // scène de CE token
    const memberIds = Array.from(tokenDoc.actor?.system?.members?.ids ?? []);
    for (const charId of memberIds) {
        const actor = game.actors.get(charId);
        if (!actor) continue;
        const prev = new Set(getExplored(actor, sid));
        let changed = false;
        for (const k of keys) if (!prev.has(k)) { prev.add(k); changed = true; }
        if (changed) await setExplored(actor, sid, [...prev]);
    }
    journal.debug(tl("[CE] révélation : {0} cases (arrivée {1}) pour {2} membre(s)", keys.size, hexKey(toOff), memberIds.length));
}

// ============================================================
// Rendu du calque de brouillard (par client)
// ============================================================
let _fogLayer = null;

function clearFogLayer() {
    if (_fogLayer) { try { _fogLayer.destroy({ children: true }); } catch (e) {} _fogLayer = null; }
}

function drawHexInto(g, key) {
    const [i, j] = key.split(".").map(Number);
    const verts = canvas.grid.getVertices({ i, j });
    if (verts?.length) g.drawPolygon(verts.flatMap(p => [p.x, p.y]));
}

// Hauteur du calque de brouillard : au-dessus du reste de l'interface, mais
// SOUS les notes de journal, pour que le nom d'un lieu découvert (affiché au
// survol de son épingle) ne soit pas coupé par le noir des cases voisines.
// Les joueurs ne voient de toute façon que les notes des lieux qu'ils ont le
// droit de voir.
function fogZIndex() {
    const parent = canvas.interface ?? canvas.stage;
    const notes = canvas.notes;
    if (!notes || notes.parent !== parent || !Number.isFinite(notes.zIndex) || notes.zIndex > 900) return 900;
    const z = notes.zIndex - 0.5;
    // Sécurité : si un autre calque (dessins, gabarits…) est rangé au-dessus
    // des notes, le brouillard doit le couvrir → on garde la hauteur d'origine.
    const auDessus = (parent.children ?? []).some(c =>
        c !== notes && c !== _fogLayer && c !== canvas.controls && Number.isFinite(c?.zIndex) && c.zIndex >= z && c.zIndex <= 900);
    return auDessus ? 900 : z;
}

function drawFog() {
    clearFogLayer();
    if (!onExpeditionCanvas()) return;
    const zones = globalZones();

    // Le MJ voit toute la carte : on lui montre juste un repère (jaune pâle) des
    // zones éclairées en permanence (villes), pour savoir ce qui est marqué.
    if (game.user.isGM) {
        if (!zones.length) return;
        const g = new PIXI.Graphics();
        g.eventMode = "none";
        g.beginFill(0xffcc00, 0.15);
        for (const key of zones) drawHexInto(g, key);
        g.endFill();
        g.zIndex = fogZIndex();
        _fogLayer = g;
        (canvas.interface ?? canvas.stage).addChild(g);
        return;
    }

    // Joueur : noir partout, trous aux cases explorées de son perso + villes globales.
    const char = game.user.character;
    const explored = new Set(getExplored(char, currentSceneId()));
    for (const z of zones) explored.add(z);   // zones toujours éclairées, visibles par tous

    const d = canvas.dimensions;
    const g = new PIXI.Graphics();
    g.eventMode = "none";
    g.beginFill(0x000000, 1);
    g.drawRect(d.sceneX, d.sceneY, d.sceneWidth, d.sceneHeight);
    if (explored.size) {
        g.beginHole();
        for (const key of explored) drawHexInto(g, key);
        g.endHole();
    }
    g.endFill();
    g.zIndex = fogZIndex();
    _fogLayer = g;
    (canvas.interface ?? canvas.stage).addChild(g);
}

// ============================================================
// Acteur Groupe « modèle » (à copier / renommer) — inchangé côté usage,
// sert juste à donner un token de groupe prêt (Members = PJ assignés).
// ============================================================
// Dossier d'acteurs du token modèle : celui choisi dans les réglages, sinon
// « Tokens de groupe » (couleur or orangé), créé automatiquement à la racine.
export const DOSSIER_GROUPES = tl("Tokens de groupe");
export const COULEUR_GROUPES = "#d9a13b";
async function resolveTemplateFolderId() {
    const val = game.settings.get(MOD, "expeditionMapTemplateFolder");
    const looksLikeId = (s) => /^[A-Za-z0-9]{16}$/.test(s ?? "");
    if (val) {
        const byId = game.folders?.get(val);
        if (byId?.type === "Actor") return byId.id;
        if (!looksLikeId(val)) {
            const byName = game.folders?.find(f => f.type === "Actor" && f.name === val);
            if (byName) return byName.id;
            const created = await Folder.create({ name: val, type: "Actor", color: COULEUR_GROUPES });
            return created?.id ?? null;
        }
        // id d'un dossier supprimé : on retombe sur le dossier par défaut.
    }
    let dossier = game.folders?.find(f => f.type === "Actor" && memeNom(f.name, tl("Tokens de groupe")) && !f.folder);
    if (!dossier) dossier = await Folder.create({ name: DOSSIER_GROUPES, type: "Actor", color: COULEUR_GROUPES });
    else if (!dossier.color) await dossier.update({ color: COULEUR_GROUPES });
    return dossier?.id ?? null;
}

async function ensureTemplateGroupActor() {
    let actor = game.actors.find(a => a.type === "group" && a.getFlag(MOD, "templateGroupToken") === true);
    if (!actor) {
        if (game.actors.find(a => a.type === "group" && memeNom(a.name, tl("Token à copier et rennomer")))) return null;
        try {
            const folderId = await resolveTemplateFolderId();
            actor = await Actor.create({
                name: TEMPLATE_GROUP_NAME,
                type: "group",
                folder: folderId ?? null,
                flags: { [MOD]: { templateGroupToken: true } },
                prototypeToken: {
                    name: TEMPLATE_GROUP_NAME,
                    actorLink: false,
                    sight: { enabled: false },
                    disposition: CONST.TOKEN_DISPOSITIONS.FRIENDLY,
                    displayName: CONST.TOKEN_DISPLAY_MODES.HOVER
                }
            });
            journal.debug(tl("[{0}] Acteur Groupe modèle « {1} » créé.", MOD, TEMPLATE_GROUP_NAME));
        } catch (e) {
            journal.avert(tl("[{0}] Création de l'acteur Groupe modèle échouée :", MOD), e);
            return null;
        }
    }
    if (!actor) return null;
    // Range le modèle dans son dossier (s'il est ailleurs, ex. à la racine).
    try {
        const fid = await resolveTemplateFolderId();
        if (fid && actor.folder?.id !== fid) await actor.update({ folder: fid });
    } catch (e) { journal.avert(tl("[{0}] Rangement du token modèle échoué :", MOD), e); }

    // NOTE : on ne dépose PLUS automatiquement le token modèle sur les scènes de
    // carte. L'acteur « modèle » reste disponible dans la barre latérale ; le MJ
    // le glisse lui-même sur la carte quand il veut créer un groupe d'expédition.
    // (Auparavant, un token se replaçait tout seul au centre de chaque scène et
    // réapparaissait après suppression — comportement jugé indésirable.)
    return actor;
}

// Supprime l'ancien acteur « Ancre de vision » (plus nécessaire avec le fog maison).
async function removeLegacyAnchor() {
    const anchors = game.actors.filter(a => a.getFlag(MOD, "visionAnchor") === true);
    for (const a of anchors) {
        try { await a.delete(); journal.debug(tl("[{0}] Ancre de vision obsolète supprimée.", MOD)); }
        catch (e) { journal.avert(tl("[{0}] Suppression ancre échouée :", MOD), e); }
    }
}

// Désactive la vision/brouillard NATIFS sur la scène (on gère nous-mêmes).
async function disableNativeSceneFog() {
    for (const sid of expeditionSceneIds()) {
        const scene = game.scenes.get(sid);
        if (!scene) continue;
        const upd = {};
        if (scene.tokenVision) upd.tokenVision = false;
        if (scene.fog?.exploration) upd["fog.exploration"] = false;
        if (Object.keys(upd).length) {
            try { await scene.update(upd); journal.debug(tl("[{0}] Vision/brouillard natifs désactivés (scène {1}).", MOD, scene.name)); }
            catch (e) { journal.avert(tl("[{0}] Désactivation vision native échouée (scène {1}) :", MOD, sid), e); }
        }
    }
}

// ============================================================
// Réinitialisation du brouillard
// ============================================================
const _esc = (s) => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

async function resetOneCharFog(actorId) {
    if (!game.user.isGM) return;
    const actor = game.actors.get(actorId);
    if (actor?.getFlag(MOD, FLAG_EXPLORED)) await actor.unsetFlag(MOD, FLAG_EXPLORED);
    drawFog();
}

// API console : game.modules.get("soruta-completed-westmarch").api.resetExpeditionFog()
export async function resetExpeditionFog() {
    if (!game.user.isGM) return;
    for (const a of game.actors.filter(a => a.type === "character")) {
        if (a.getFlag(MOD, FLAG_EXPLORED)) await a.unsetFlag(MOD, FLAG_EXPLORED);
    }
    drawFog();
}

// Synchronise, sur l'acteur de GROUPE, la permission des joueurs selon les
// membres du groupe :
//  • ajout d'un membre   → le(s) joueur(s) propriétaire(s) du PJ passent Observateur ;
//  • retrait d'un membre → ces joueurs reviennent à la permission « défaut »
//                           (suppression de l'entrée → héritage de ownership.default),
// sans jamais toucher un Propriétaire ni une permission posée à la main (> Observateur).
// Idempotent.
async function syncGroupOwnership(groupActor) {
    try {
        const L = CONST.DOCUMENT_OWNERSHIP_LEVELS;
        const memberIds = Array.from(groupActor.system?.members?.ids ?? []);
        const ownership = groupActor.ownership ?? {};

        // Ensemble des joueurs qui DOIVENT être Observateurs (propriétaires d'un
        // PJ encore membre du groupe).
        const shouldObserve = new Set();
        for (const mid of memberIds) {
            const member = game.actors.get(mid);
            if (!member) continue;
            for (const user of game.users) {
                if (user.isGM) continue;
                const owns = member.ownership?.[user.id] === L.OWNER
                    || user.character?.id === mid
                    || member.getFlag(MOD, "createdFor") === user.id;
                if (owns) shouldObserve.add(user.id);
            }
        }

        const updates = {};
        // Octroi : membre présent, joueur pas encore Observateur.
        for (const uid of shouldObserve) {
            if ((ownership[uid] ?? L.NONE) < L.OBSERVER) updates[`ownership.${uid}`] = L.OBSERVER;
        }
        // Révocation : joueur actuellement à EXACTEMENT Observateur mais dont le PJ
        // n'est plus membre → retour au défaut via le niveau INHERIT (-1), qui fait
        // hériter de ownership.default. (La suppression de clé « ownership.-=id » est
        // refusée par la validation du SchemaField.) On ne descend jamais un
        // Propriétaire ni une permission supérieure posée manuellement.
        const INHERIT = L.INHERIT ?? -1;
        for (const user of game.users) {
            if (user.isGM) continue;
            if (shouldObserve.has(user.id)) continue;
            if (ownership[user.id] === L.OBSERVER) updates[`ownership.${user.id}`] = INHERIT;
        }

        if (Object.keys(updates).length) await groupActor.update(updates);
    } catch (e) { journal.avert(tl("[{0}] Sync permissions du groupe échoué :", MOD), e); }
}

// Renomme un groupe fraîchement dupliqué : applique le nom à la fiche (acteur)
// ET au prototype token, puis retire le flag « modèle » de la copie.
async function promptRenameGroup(actor) {
    const DialogV2 = foundry.applications.api.DialogV2;
    const suggested = actor.name?.replace(/\s*\(Copy\)\s*$/i, "").replace(/\s*\(copie\)\s*$/i, "") ?? "";

    const name = await DialogV2.wait({
        window: { title: tl("Nommer le groupe d'expédition"), icon: "fa-solid fa-flag" },
        position: { width: 420 },
        content: `<p style="margin:0 0 6px;">${tl("Nom du nouveau groupe (appliqué à la fiche et au prototype token) :")}</p>
                  <input type="text" name="scwm-gname" style="width:100%;" value="${_esc(suggested)}" placeholder="${tl("Nom du groupe")}" autofocus>`,
        rejectClose: false,
        buttons: [
            { action: "ok", label: tl("Renommer"), icon: "fa-solid fa-check", default: true,
              callback: (ev, btn) => (btn.form.elements["scwm-gname"]?.value ?? "").trim() },
            { action: "skip", label: tl("Garder tel quel"), icon: "fa-solid fa-xmark", callback: () => null }
        ]
    }).catch(() => null);

    const update = { [`flags.${MOD}.-=templateGroupToken`]: null };   // la copie n'est plus un « modèle »
    if (name) { update.name = name; update["prototypeToken.name"] = name; }
    try { await actor.update(update); }
    catch (e) { journal.avert(tl("[{0}] Renommage du groupe échoué :", MOD), e); }
}

// Effacement de la carte d'expédition, depuis les réglages (Administration).
export async function ouvrirEffacementCarte() { return openFogResetDialog(); }

async function openFogResetDialog() {
    if (!game.user.isGM) return;
    if (!(await verifierAdmin(tl("Effacer la carte d'expédition")))) return;
    const DialogV2 = foundry.applications.api.DialogV2;

    const chars = game.actors.filter(a => a.type === "character" && a.hasPlayerOwner)
        .sort((a, b) => a.name.localeCompare(b.name));
    const options = chars.length
        ? chars.map(a => `<option value="${a.id}">${_esc(a.name)}</option>`).join("")
        : `<option value="">${tl("(aucun personnage joueur)")}</option>`;

    const content = `
    <div style="display:flex;flex-direction:column;gap:10px;">
        <p style="margin:0;">${tl("Réinitialise le brouillard d'exploration de la carte des expéditions.")}</p>
        <div>
            <label style="font-weight:600;">${tl("Personnage :")}</label>
            <select name="scwm-fog-char" style="width:100%;">${options}</select>
        </div>
        <p style="margin:0;font-size:.85em;color:#c0392b;">
            ${tl("<i class=\"fa-solid fa-triangle-exclamation\"></i> Action <strong>irréversible</strong> : les zones explorées effacées ne peuvent pas être récupérées.")}
        </p>
    </div>`;

    const action = await DialogV2.wait({
        window: { title: tl("Réinitialiser le brouillard d'expédition"), icon: "fa-solid fa-eraser" },
        position: { width: 460 },
        content,
        rejectClose: false,
        buttons: [
            { action: "one", label: tl("Réinitialiser CE personnage"), icon: "fa-solid fa-user",
              callback: (ev, btn) => ({ type: "one", id: btn.form.elements["scwm-fog-char"]?.value }) },
            { action: "all", label: tl("Réinitialiser TOUT LE MONDE"), icon: "fa-solid fa-triangle-exclamation",
              callback: () => ({ type: "all" }) },
            { action: "cancel", label: tl("Annuler"), icon: "fa-solid fa-xmark", callback: () => null }
        ]
    }).catch(() => null);
    if (!action) return;

    // ---- Un seul personnage ----
    if (action.type === "one") {
        const actor = game.actors.get(action.id);
        if (!actor) { ui.notifications?.warn(tl("Aucun personnage sélectionné.")); return; }
        const ok = await DialogV2.confirm({
            window: { title: tl("Confirmer") },
            content: `<p>${tl("Effacer toutes les zones explorées de <strong>{0}</strong> ?", _esc(actor.name))}</p>
                      <p style="color:#c0392b;">${tl("Ce joueur reverra sa carte entièrement noire jusqu'à ré-exploration. Irréversible.")}</p>`,
            rejectClose: false
        }).catch(() => false);
        if (ok) { await resetOneCharFog(action.id); ui.notifications?.info(tl("Brouillard réinitialisé pour {0}.", actor.name)); }
        return;
    }

    // ---- Tout le monde : plusieurs avertissements + confirmation à taper ----
    const w1 = await DialogV2.confirm({
        window: { title: tl("⚠️ Réinitialiser TOUT LE MONDE") },
        content: `<p>${tl("Tu es sur le point d'effacer le brouillard exploré de <strong>TOUS les personnages</strong> du serveur.")}</p>
                  <p style="color:#c0392b;">${tl("Chaque joueur reverra la carte <strong>entièrement noire</strong> jusqu'à ce qu'elle soit ré-explorée.")}</p>`,
        rejectClose: false
    }).catch(() => false);
    if (!w1) return;

    const w2 = await DialogV2.confirm({
        window: { title: tl("⚠️ Action DÉFINITIVE") },
        content: `<p style="color:#c0392b;font-weight:700;">${tl("Cette action est irréversible et NON annulable.")}</p>
                  <p>${tl("Toute la progression d'exploration de la campagne sera perdue pour l'ensemble des personnages.")}</p>
                  <p>${tl("Veux-tu vraiment continuer ?")}</p>`,
        rejectClose: false
    }).catch(() => false);
    if (!w2) return;

    const typed = await DialogV2.wait({
        window: { title: tl("Confirmation finale") },
        content: `<p>${tl("Pour confirmer la réinitialisation <strong>totale</strong>, tape <code>RESET</code> ci-dessous :")}</p>
                  <input type="text" name="scwm-confirm" style="width:100%;" placeholder="RESET" autofocus>`,
        rejectClose: false,
        buttons: [
            { action: "ok", label: tl("Réinitialiser TOUT"), icon: "fa-solid fa-eraser", default: true,
              callback: (ev, btn) => (btn.form.elements["scwm-confirm"]?.value ?? "").trim() },
            { action: "cancel", label: tl("Annuler"), icon: "fa-solid fa-xmark", callback: () => null }
        ]
    }).catch(() => null);

    if (typed !== "RESET") { ui.notifications?.warn(tl("Réinitialisation annulée (confirmation incorrecte).")); return; }

    await resetExpeditionFog();
    ui.notifications?.info(tl("Brouillard d'expédition réinitialisé pour tout le monde."));
}
