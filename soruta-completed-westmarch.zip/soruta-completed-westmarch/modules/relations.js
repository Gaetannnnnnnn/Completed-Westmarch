// ============================================================
// relations.js — Système de relations entre acteurs
//
// Stockage  : flag scope MOD → "list" sur chaque acteur
//             [ { id, targetId, targetName, targetImg,
//                 type, level(-3→+3), note, lastPosition, secret } ]
// Interface : onglet "Relations" injecté dans la fiche acteur
// Auto-det. : côté joueur, pour le personnage sur lequel il est connecté
//             (game.user.character), seulement les jetons que son jeton
//             voit (murs, portes, lumière : voir perception.js)
// © 2026 Soruta — Tous droits réservés. Usage personnel autorisé. Redistribution et modification interdites.
// ============================================================

import { MOD } from "./const.js";
import { commonFolderPJ, commonFolderPNJ, commonPackPNJ, commonPackCemetery } from "./settings.js";
import { jetonDuPersonnage, voit, surCarteExpedition, ouvrirImage, dateDeRencontre, memeRencontre, texteRencontre } from "./perception.js";
import { tl } from "./i18n.js";
export const MODULE = MOD;

// ---- État de session ---------------------------------------

const _expanded   = new Set();  // IDs de relations dont les notes sont ouvertes
const _activeActs = new Set();  // IDs d'acteurs avec le tab Relations actif
let   _noteTimer  = null;       // Debounce auto-save notes
let   _scanning   = false;      // Guard anti-doublon scan
let   _sightTimer = null;       // Debounce sightRefresh

// ---- Icônes de niveau (-3 → +3) ----------------------------

const LEVEL_CFG = {
    "-3": { icon: "fa-skull",       color: "#8b0000", label: tl("Haine totale") },
    "-2": { icon: "fa-fire",        color: "#e74c3c", label: tl("Hostilité")    },
    "-1": { icon: "fa-thumbs-down", color: "#e67e22", label: tl("Méfiance")     },
     "0": { icon: "fa-minus",       color: "#888888", label: tl("Neutre")       },
     "1": { icon: "fa-thumbs-up",   color: "#a8d5a2", label: tl("Sympathie")    },
     "2": { icon: "fa-star",        color: "#27ae60", label: tl("Amitié")       },
     "3": { icon: "fa-heart",       color: "#e91e8c", label: tl("Loyauté")      },
};

function levelIcon(level) {
    const cfg = LEVEL_CFG[String(level ?? 0)] ?? LEVEL_CFG["0"];
    return `<i class="fas ${cfg.icon} rel-level-icon" style="color:${cfg.color};" title="${cfg.label} (${level > 0 ? "+" : ""}${level ?? 0})"></i>`;
}

function levelSelector(currentLevel, canEdit) {
    const cur = LEVEL_CFG[String(currentLevel ?? 0)] ?? LEVEL_CFG["0"];
    if (!canEdit) return `<div class="rel-level">${levelIcon(currentLevel)}</div>`;
    // Trier explicitement -3→+3 (Object.entries met les clés entières positives en premier en JS)
    const btns = Object.entries(LEVEL_CFG).sort(([a],[b]) => parseInt(a) - parseInt(b)).map(([lvl, cfg]) => {
        const active  = parseInt(lvl) === (currentLevel ?? 0);
        const color   = active ? `style="color:${cfg.color};"` : "";
        const classes = `rel-level-btn${active ? " active" : ""}`;
        return `<a class="${classes}" data-level="${lvl}" title="${cfg.label}">
            <i class="fas ${cfg.icon}" ${color}></i>
        </a>`;
    }).join("");
    return `<div class="rel-level-selector">
        <span class="rel-level-label" style="color:${cur.color};">${cur.label}</span>
        ${btns}
    </div>`;
}

// ---- CRUD --------------------------------------------------

function relList(actor) {
    return actor.getFlag(MOD, "relationsList") ?? [];
}

// {render: false} → jamais de re-render depuis l'onglet (DOM géré manuellement)
async function relSave(actor, list) {
    await actor.update({ [`flags.${MOD}.relationsList`]: list }, { render: false });
}

// Retourne le nouvel objet relation (ou null si doublon)
async function relAdd(actor, data) {
    const list = relList(actor);
    if (list.some(r => r.targetId === data.targetId)) return null;
    const targetActor = game.actors.get(data.targetId);
    const rel = {
        id: foundry.utils.randomID(12),
        revealed: !(targetActor?.getFlag(MOD, "anonymous") ?? false),
        note: "", lastPosition: game.scenes.current?.name ?? "",
        secret: false, ...data
    };
    list.push(rel);
    await relSave(actor, list);
    return rel;
}

async function relUpdate(actor, id, patch) {
    await relSave(actor, relList(actor).map(r => r.id === id ? { ...r, ...patch } : r));
}

async function relDelete(actor, id) {
    await relSave(actor, relList(actor).filter(r => r.id !== id));
}

// ---- Helpers acteurs ---------------------------------------

// Remonte l'arbre de dossiers pour savoir si actor est sous folderId
function isInFolder(actor, folderId) {
    if (!folderId) return false;
    let f = actor.folder;
    while (f) {
        if (f.id === folderId) return true;
        f = f.folder;
    }
    return false;
}

function isInPJFolder(actor)        { return isInFolder(actor, commonFolderPJ()); }
function isInPNJFolder(actor)       { return isInFolder(actor, commonFolderPNJ()); }

// Acteurs disponibles pour une nouvelle relation
// (dossiers "PJ" et "PNJ", excluant soi-même et les déjà-liés)
function availableActors(actor) {
    const existing = new Set(relList(actor).map(r => r.targetId));
    return game.actors
        .filter(a => ((isInPJFolder(a) && a.type === "character") || isInPNJFolder(a))
                  && a.id !== actor.id
                  && !existing.has(a.id))
        .sort((a, b) => a.name.localeCompare(b.name));
}

// ---- HTML onglet -------------------------------------------

const dateRencontreActive = () => { try { return game.settings.get(MOD, "relationsLastSeen") !== false; } catch { return true; } };

export function buildRowHtml(r, actor, canEdit) {
    const target   = game.actors.get(r.targetId);
    const revealed = r.revealed ?? true;
    const img      = target?.img  ?? r.targetImg  ?? "icons/svg/mystery-man.svg";
    const name     = revealed ? (target?.name ?? r.targetName ?? tl("Inconnu")) : tl("Inconnu");
    const open   = _expanded.has(r.id);
    return `
    <div class="rel-row" data-rel-id="${r.id}">
        <div class="rel-header">
            <img class="rel-avatar" src="${escA(img)}" alt="${escA(name)}">
            <span class="rel-name">${escA(name)}</span>
            ${levelSelector(r.level ?? 0, canEdit)}
            <div class="rel-btns">
                ${game.user.isGM && target ? `<a class="rel-open-sheet" data-target-id="${r.targetId}" title="Ouvrir la fiche"><i class="fa-solid fa-external-link-alt"></i></a>` : ""}
                <a class="rel-toggle" title="Notes"><i class="fa-solid fa-chevron-${open ? "up" : "down"}"></i></a>
                ${canEdit ? `<a class="rel-delete" title="Supprimer"><i class="fa-solid fa-trash"></i></a>` : ""}
            </div>
        </div>
        <div class="rel-notes"${open ? "" : ' style="display:none;"'}>
            ${dateRencontreActive() ? (() => { const { texte, titre } = texteRencontre(r.lastSeen); return `
            <div class="rel-lastpos-row rel-readonly" title="${escA(titre)}">
                <i class="fa-solid fa-calendar-day"></i>
                <span>${tl("Dernière rencontre :")} <span class="rel-seen-value" data-rel-id="${r.id}">${texte ? escA(texte) : `${tl("<em>inconnue</em>")}`}</span></span>
            </div>`; })() : ""}
            ${canEdit ? `
            <div class="rel-lastpos-row">
                <label class="rel-field-label">${tl("<i class=\"fa-solid fa-map-marker-alt\"></i> Dernière position")}</label>
                <input class="rel-lastpos-input" type="text" data-rel-id="${r.id}"
                    value="${escA(r.lastPosition)}" placeholder="${tl("Scène, lieu…")}">
            </div>
            <textarea class="rel-note-input" data-rel-id="${r.id}"
                placeholder="${tl("Notes sur cette relation…")}">${escA(r.note)}</textarea>
            ` : `
            <div class="rel-lastpos-row rel-readonly">
                <i class="fa-solid fa-map-marker-alt"></i>
                <span>${r.lastPosition ? escA(r.lastPosition) : `${tl("<em>Position inconnue</em>")}`}</span>
            </div>
            <p class="rel-note-ro" style="white-space:pre-wrap;">${r.note ? escA(r.note) : `${tl("<em>Aucune note.</em>")}`}</p>
            `}
        </div>
    </div>`;
}

export function emptyStateHtml() {
    return `<div class="rel-empty">
        <i class="fa-solid fa-heart-broken"></i>
        <span>${tl("Aucune relation enregistrée.")}</span>
    </div>`;
}

export function buildTabHtml(actor) {
    const isGM    = game.user.isGM;
    const canEdit = isGM || actor.isOwner;
    const rels    = relList(actor);

    // Grouper : Joueurs (dossier "PJ" + cimetière/compendium tagué source:"pj"),
    // PNJ (dossier "PNJ" + compendium tagué source:"pnj").
    const isPjRel  = r => r.source === "pj"
        || (() => { const a = game.actors.get(r.targetId); return !!(a && isInPJFolder(a) && a.type === "character"); })();
    const isPnjRel = r => r.source === "pnj"
        || (() => { const a = game.actors.get(r.targetId); return !!(a && isInPNJFolder(a)); })();
    const pjRels  = rels.filter(isPjRel);
    const pnjRels = rels.filter(r => !isPjRel(r) && isPnjRel(r));

    // ---- Styles inline (contournement cache CSS Foundry) ----
    // Thème "fantasy" doré, aligné sur l'onglet Bestiaire.
    const S = {
        titleBar:  `display:flex;align-items:center;justify-content:space-between;padding:9px 12px 7px;flex-shrink:0;background:linear-gradient(180deg,rgba(201,162,39,0.06),transparent);border-bottom:2px solid transparent;border-image:linear-gradient(90deg,transparent,rgba(201,162,39,0.55) 15%,rgba(201,162,39,0.55) 85%,transparent) 1;`,
        title:     `display:flex;align-items:center;gap:8px;font-size:17px;font-weight:700;text-transform:uppercase;letter-spacing:0.14em;color:#c9a227;font-family:'Modesto Condensed','Enchanted Land','Signika',serif;text-shadow:0 1px 2px rgba(0,0,0,0.6);`,
        addBtn:    `display:flex;align-items:center;gap:5px;padding:3px 9px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);border-radius:4px;color:#aaa;font-size:11px;cursor:pointer;white-space:nowrap;transition:background 0.12s,color 0.12s;`,
        searchBar: `display:flex;align-items:center;gap:6px;padding:6px 10px;flex-shrink:0;border-bottom:1px solid rgba(201,162,39,0.15);`,
        wrap:      `flex:1;display:flex;align-items:center;gap:6px;background:rgba(0,0,0,0.28);border:1px solid rgba(201,162,39,0.28);border-radius:4px;padding:5px 9px;`,
        srchIcon:  `color:#a8863a;font-size:12px;flex-shrink:0;`,
        srchInput: `flex:1;background:transparent;border:none;box-shadow:none;outline:none;color:#cbb98f;font-size:12px;padding:0;min-width:0;font-family:'Bookinsanity',Georgia,serif;`,
        clear:     `display:none;color:#444;font-size:10px;cursor:pointer;padding:2px 3px;`,
        // En-tête de section (Joueurs / PNJ) — filet doré
        secHdr:    `display:flex;align-items:center;gap:6px;padding:4px 12px;flex-shrink:0;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.09em;color:#b89a52;background:linear-gradient(180deg,rgba(201,162,39,0.06),transparent);border-top:1px solid rgba(201,162,39,0.15);border-bottom:1px solid rgba(201,162,39,0.15);`,
        secCount:  `color:#8a7038;font-weight:400;font-size:10px;`,
    };

    function sectionHdr(label, count) {
        return `<div style="${S.secHdr}">${label}<span style="${S.secCount}">${count}</span></div>`;
    }

    // Relations non rattachées à un dossier PJ/PNJ (cible non catégorisée,
    // supprimée, ou entrée auto-suffisante) → groupe "Autres".
    const grouped   = new Set([...pjRels, ...pnjRels].map(r => r.id));
    const otherRels = rels.filter(r => !grouped.has(r.id));

    let listContent;
    if (!rels.length) {
        listContent = emptyStateHtml(isGM);
    } else {
        listContent =
            (pjRels.length    ? sectionHdr(tl("Joueurs"), pjRels.length)  + pjRels.map( r => buildRowHtml(r, actor, canEdit)).join("") : "") +
            (pnjRels.length   ? sectionHdr(tl("PNJ"),     pnjRels.length) + pnjRels.map(r => buildRowHtml(r, actor, canEdit)).join("") : "") +
            (otherRels.length ? sectionHdr(tl("Autres"),  otherRels.length) + otherRels.map(r => buildRowHtml(r, actor, canEdit)).join("") : "");
    }

    return `
    <div class="rel-tab" data-actor-id="${actor.id}">

        <div style="${S.titleBar}">
            <span style="${S.title}">
                ${tl("<i class=\"fa-solid fa-heart\" style=\"color:#e0a13a;font-size:15px;filter:drop-shadow(0 1px 1px rgba(0,0,0,0.5));\"></i>\n                Relations")}
            </span>
            ${isGM ? `${tl("<a class=\"rel-add-btn\">\n                <i class=\"fa-solid fa-plus\" style=\"font-size:10px;\"></i> Ajouter\n            </a>")}` : ""}
        </div>

        <div style="${S.searchBar}">
            <div class="rel-search-wrap" style="${S.wrap}">
                <i class="fa-solid fa-search" style="${S.srchIcon}"></i>
                <input class="rel-search-input" type="text"
                    placeholder="${tl("Rechercher une relation…")}" style="${S.srchInput}">
                <a class="rel-search-clear" style="${S.clear}" title="${tl("Effacer")}">
                    <i class="fa-solid fa-times"></i>
                </a>
            </div>
        </div>

        <div class="rel-list">
            ${listContent}
        </div>
    </div>`;
}

// ---- Picker acteur (dialog ajout) --------------------------

function escA(s) {
    return String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

// Entrées d'un compendium d'acteurs (référence simple : nom + image + uuid).
function packEntries(collection, source, existing) {
    const pack = game.packs.get(collection);
    if (!pack || pack.documentName !== "Actor") return [];
    const out = [];
    for (const e of pack.index) {
        const uuid = e.uuid ?? `${pack.collection}.${e._id}`;
        if (existing.has(uuid)) continue;
        out.push({ key: uuid, name: e.name, img: e.img || "icons/svg/mystery-man.svg", source, isPack: true });
    }
    return out;
}

function buildPickerHtml(pj, uid) {
    const existing = new Set(relList(pj).map(r => r.targetId));

    // Acteurs du monde (dossiers PJ / PNJ).
    const joueurs = [], pnjs = [];
    for (const a of game.actors) {
        if (a.id === pj.id || existing.has(a.id)) continue;
        if (isInPJFolder(a) && a.type === "character") joueurs.push({ key: a.id, name: a.name, img: a.img, source: "pj",  isPack: false });
        else if (isInPNJFolder(a))                     pnjs.push(   { key: a.id, name: a.name, img: a.img, source: "pnj", isPack: false });
    }
    // Compendiums (référence simple) : cimetière → Joueurs, PNJ → PNJ.
    joueurs.push(...packEntries(commonPackCemetery(), "pj",  existing));
    pnjs.push(   ...packEntries(commonPackPNJ(),      "pnj", existing));

    const byName = (a, b) => a.name.localeCompare(b.name);
    joueurs.sort(byName); pnjs.sort(byName);

    function actorRow(e) {
        return `<div class="rel-picker-actor" data-actor-id="${escA(e.key)}" data-name="${escA(e.name.toLowerCase())}"
                     data-source="${e.source}" data-pack="${e.isPack ? "1" : "0"}"
                     data-img="${escA(e.img)}" data-actor-name="${escA(e.name)}">
            <img src="${escA(e.img)}" alt="${escA(e.name)}">
            <span>${escA(e.name)}</span>
        </div>`;
    }

    function section(title, list, key) {
        if (!list.length) return "";
        return `
        <div class="rel-picker-section">
            <div class="rel-picker-section-hdr" data-key="${key}">
                <i class="fa-solid fa-chevron-down"></i>
                <span>${title}</span>
                <small>(${list.length})</small>
            </div>
            <div class="rel-picker-section-body" data-key="${key}">
                ${list.map(actorRow).join("")}
            </div>
        </div>`;
    }

    return `
    <div id="${uid}" style="display:flex;flex-direction:column;gap:10px;padding:4px 0;">
        <input class="rel-picker-search" type="text" placeholder="${tl("🔍 Rechercher un personnage…")}"
            style="width:100%;box-sizing:border-box;padding:5px 8px;
                   border:1px solid #555;border-radius:4px;background:#111;color:#ddd;font-size:12px;">
        <div class="rel-picker-list">
            ${section(tl("Joueurs"), joueurs, "pj")}
            ${section(tl("PNJ"),     pnjs,    "pnj")}
            ${!joueurs.length && !pnjs.length
                ? `<p style="color:#666;font-style:italic;font-size:12px;text-align:center;padding:12px 0;">${tl("Aucun personnage disponible.")}</p>`
                : ""}
        </div>
        <hr style="border-color:#333;margin:0;">
        <label style="font-size:12px;color:#aaa;">${tl("Niveau d'affinité")}
            <div style="display:flex;align-items:center;gap:10px;margin-top:6px;">
                <span style="font-size:11px;color:#e74c3c;flex-shrink:0;">Hostile</span>
                <input id="${uid}-level" type="range" min="-3" max="3" step="1" value="0" style="flex:1;">
                <span style="font-size:11px;color:#4caf50;flex-shrink:0;">${tl("Allié")}</span>
                <span id="${uid}-lvlval" style="min-width:28px;text-align:center;
                    font-size:14px;font-weight:bold;color:#ddd;">0</span>
            </div>
        </label>
    </div>`;
}

async function openAddDialog(actor) {
    const uid = `rel-add-${Date.now()}`;
    let selectedActorId = null;
    let result = null;

    // Précharge l'index des compendiums configurés (accès synchrone ensuite).
    for (const col of [commonPackCemetery(), commonPackPNJ()]) {
        const p = col ? game.packs.get(col) : null;
        if (p) { try { await p.getIndex(); } catch (e) {} }
    }

    await foundry.applications.api.DialogV2.wait({
        window: { title: tl("Nouvelle relation") },
        position: { width: 400 },
        rejectClose: false,
        content: buildPickerHtml(actor, uid),
        render: () => {
            const d = document.getElementById(uid);
            if (!d) return;

            // Sélection d'un acteur
            d.querySelectorAll(".rel-picker-actor").forEach(el => {
                el.addEventListener("click", () => {
                    d.querySelectorAll(".rel-picker-actor").forEach(e => e.classList.remove("selected"));
                    el.classList.add("selected");
                    selectedActorId = el.dataset.actorId;
                });
            });

            // Déplier / replier sections
            d.querySelectorAll(".rel-picker-section-hdr").forEach(hdr => {
                hdr.addEventListener("click", () => {
                    const key  = hdr.dataset.key;
                    const body = d.querySelector(`.rel-picker-section-body[data-key="${key}"]`);
                    const icon = hdr.querySelector("i");
                    const open = body.style.display !== "none";
                    body.style.display = open ? "none" : "";
                    icon.classList.toggle("fa-chevron-down", open);
                    icon.classList.toggle("fa-chevron-up",  !open);
                });
            });

            // Recherche
            d.querySelector(".rel-picker-search").addEventListener("input", function () {
                const q = this.value.trim().toLowerCase();
                d.querySelectorAll(".rel-picker-actor").forEach(el => {
                    const match = !q || el.dataset.name.includes(q);
                    el.style.display = match ? "" : "none";
                });
                // Afficher les sections qui ont encore des résultats visibles
                d.querySelectorAll(".rel-picker-section").forEach(sec => {
                    const anyVisible = [...sec.querySelectorAll(".rel-picker-actor")]
                        .some(e => e.style.display !== "none");
                    sec.style.display = anyVisible ? "" : "none";
                });
            });

            // Slider niveau
            const slider = d.querySelector(`#${uid}-level`);
            const lvlVal = d.querySelector(`#${uid}-lvlval`);
            slider.addEventListener("input", () => {
                const v = parseInt(slider.value);
                lvlVal.textContent = (v > 0 ? "+" : "") + v;
            });

            setTimeout(() => d.querySelector(".rel-picker-search")?.focus(), 60);
        },
        buttons: [
            {
                action: "confirm", default: true,
                label: tl("Ajouter"), icon: '<i class="fa-solid fa-check"></i>',
                callback: () => {
                    const d  = document.getElementById(uid);
                    const el = d?.querySelector(".rel-picker-actor.selected");
                    if (!el) return;
                    const isPack     = el.dataset.pack === "1";
                    const worldActor = isPack ? null : game.actors.get(el.dataset.actorId);
                    result = {
                        targetId:   el.dataset.actorId,
                        targetName: worldActor?.name ?? el.dataset.actorName ?? tl("Inconnu"),
                        targetImg:  worldActor?.img  ?? el.dataset.img ?? "",
                        source:     el.dataset.source || undefined,
                        level:  parseInt(d.querySelector(`#${uid}-level`).value) || 0,
                        lastPosition: game.scenes.current?.name ?? "",
                    };
                }
            },
            { action: "cancel", label: tl("Annuler"), icon: '<i class="fa-solid fa-times"></i>', callback: () => {} }
        ]
    });

    return result;
}

// ---- Dialog modification -----------------------------------

async function openEditDialog(actor, rel) {
    const uid = `rel-edit-${Date.now()}`;
    let result = null;

    await foundry.applications.api.DialogV2.wait({
        window: { title: `Modifier — ${rel.targetName ?? ""}` },
        position: { width: 360 },
        rejectClose: false,
        content: `
        <div id="${uid}" style="display:flex;flex-direction:column;gap:12px;padding:4px 0;">
            <div style="display:flex;align-items:center;gap:10px;padding:6px 8px;
                background:#1a1a1a;border-radius:6px;border:1px solid #333;">
                <img src="${rel.targetImg || "icons/svg/mystery-man.svg"}"
                    style="width:32px;height:32px;border-radius:50%;object-fit:cover;border:1px solid #444;">
                <strong style="font-size:13px;">${escA(rel.targetName)}</strong>
            </div>
            <label style="font-size:12px;color:#aaa;">${tl("Type de relation")}
                <input id="${uid}-type" type="text" value="${rel.type ?? ""}"
                    placeholder="${tl("Allié, Ennemi, Famille…")}"
                    style="margin-top:4px;display:block;width:100%;box-sizing:border-box;
                        background:#1a1a1a;color:#ddd;border:1px solid #555;
                        border-radius:4px;padding:5px 8px;font-size:12px;">
            </label>
            <label style="font-size:12px;color:#aaa;">${tl("Niveau d'affinité")}
                <div style="display:flex;align-items:center;gap:10px;margin-top:6px;">
                    <span style="font-size:11px;color:#e74c3c;flex-shrink:0;">Hostile</span>
                    <input id="${uid}-level" type="range" min="-3" max="3" step="1"
                        value="${rel.level ?? 0}" style="flex:1;">
                    <span style="font-size:11px;color:#4caf50;flex-shrink:0;">${tl("Allié")}</span>
                    <span id="${uid}-lvlval" style="min-width:28px;text-align:center;
                        font-size:14px;font-weight:bold;color:#ddd;">
                        ${(rel.level ?? 0) > 0 ? "+" : ""}${rel.level ?? 0}
                    </span>
                </div>
            </label>
            <label style="font-size:12px;color:#aaa;display:flex;align-items:center;gap:8px;cursor:pointer;">
                <input id="${uid}-secret" type="checkbox"${rel.secret ? " checked" : ""}> ${tl("Secret (GM uniquement)")}
            </label>
        </div>`,
        render: () => {
            const d = document.getElementById(uid);
            if (!d) return;
            d.querySelector(`#${uid}-level`).addEventListener("input", function () {
                const v = parseInt(this.value);
                d.querySelector(`#${uid}-lvlval`).textContent = (v > 0 ? "+" : "") + v;
            });
        },
        buttons: [
            {
                action: "confirm", default: true,
                label: tl("Modifier"), icon: '<i class="fa-solid fa-check"></i>',
                callback: () => {
                    const d = document.getElementById(uid);
                    if (!d) return;
                    result = {
                        type:   d.querySelector(`#${uid}-type`).value.trim(),
                        level:  parseInt(d.querySelector(`#${uid}-level`).value) || 0,
                        secret: d.querySelector(`#${uid}-secret`).checked,
                    };
                }
            },
            { action: "cancel", label: tl("Annuler"), icon: '<i class="fa-solid fa-times"></i>', callback: () => {} }
        ]
    });

    return result;
}

// ---- Helpers -----------------------------------------------

function _autoResize(el) {
    el.style.height = "auto";
    el.style.height = el.scrollHeight + "px";
}

// ---- Événements de l'onglet --------------------------------

export function wireTab(actor, $html) {
    const $tab = $html.find(".rel-tab");
    if (!$tab.length) return;

    // Resize textareas déjà visibles (sections ouvertes depuis _expanded)
    $tab.find(".rel-note-input").each((_, el) => _autoResize(el));

    const canEdit = game.user.isGM || actor.isOwner;

    // Clic sur la ligne → ouvrir le portrait
    $tab.on("click", ".rel-header", function (e) {
        if ($(e.target).closest("a, input, .rel-level-btn, .rel-btns").length) return;
        const relId  = String($(this).closest(".rel-row").data("rel-id"));
        const rel    = relList(actor).find(r => r.id === relId);
        if (!rel) return;
        const target = game.actors.get(rel.targetId);
        const img    = target?.img  ?? rel.targetImg  ?? "icons/svg/mystery-man.svg";
        const name   = target?.name ?? rel.targetName ?? tl("Inconnu");
        ouvrirImage(img, name);
    });

    // Ajouter — DOM uniquement, pas de re-render
    $tab.on("click", ".rel-add-btn", async () => {
        const data = await openAddDialog(actor);
        if (!data) return;
        const rel = await relAdd(actor, data);
        if (!rel) return;
        $tab.find(".rel-empty").remove();
        $tab.find(".rel-list").append(buildRowHtml(rel, actor, canEdit));
    });

    // Déplier / replier notes
    $tab.on("click", ".rel-toggle", function () {
        const $row   = $(this).closest(".rel-row");
        const relId  = String($row.data("rel-id"));
        const $notes = $row.find(".rel-notes");
        const $icon  = $(this).find("i");
        if ($notes.is(":visible")) {
            _expanded.delete(relId);
            $notes.slideUp(150);
            $icon.removeClass("fa-chevron-up").addClass("fa-chevron-down");
        } else {
            _expanded.add(relId);
            $notes.slideDown(150, function () {
                $(this).find(".rel-note-input").each((_, el) => _autoResize(el));
            });
            $icon.removeClass("fa-chevron-down").addClass("fa-chevron-up");
        }
    });

    // Changer le niveau directement depuis les icônes inline
    $tab.on("click", ".rel-level-btn", async function () {
        const $btn  = $(this);
        const relId = String($btn.closest(".rel-row").data("rel-id"));
        const level = parseInt($btn.data("level"));
        const cfg   = LEVEL_CFG[String(level)];
        // Mise à jour optimiste du DOM (évite le flash avant re-render)
        const $sel  = $btn.closest(".rel-level-selector");
        $sel.find(".rel-level-btn").removeClass("active").find("i").css("color", "");
        $btn.addClass("active").find("i").css("color", cfg.color);
        $sel.find(".rel-level-label").text(cfg.label).css("color", cfg.color);
        await relUpdate(actor, relId, { level });
    });

    // Ouvrir la fiche de l'acteur cible (GM uniquement)
    $tab.on("click", ".rel-open-sheet", function (e) {
        e.stopPropagation();
        const targetId = $(this).data("target-id");
        game.actors.get(String(targetId))?.sheet?.render(true);
    });

    // Supprimer — DOM uniquement, pas de re-render
    $tab.on("click", ".rel-delete", async function () {
        const $row  = $(this).closest(".rel-row");
        const relId = String($row.data("rel-id"));
        const rel   = relList(actor).find(r => r.id === relId);
        if (!rel) return;
        const ok = await foundry.applications.api.DialogV2.confirm({
            window: { title: tl("Supprimer la relation") },
            content: `<p>${tl("Supprimer la relation avec <strong>{0}</strong> ?<br>\n                      <small style=\"color:#999;\">Cette action est irréversible.</small>", escA(rel.targetName))}</p>`,
        });
        if (!ok) return;
        _expanded.delete(relId);
        $row.remove();
        await relDelete(actor, relId);
        // Afficher l'état vide si plus aucune ligne
        if (!$tab.find(".rel-row").length) {
            $tab.find(".rel-list").html(emptyStateHtml(game.user.isGM));
        }
    });

    // Auto-save dernière position
    $tab.on("blur", ".rel-lastpos-input", async function () {
        const relId = String($(this).data("rel-id"));
        await relUpdate(actor, relId, { lastPosition: this.value.trim() });
    });

    // Auto-save note (debounce + blur immédiat)
    $tab.on("input", ".rel-note-input", function () {
        _autoResize(this);
        clearTimeout(_noteTimer);
        const relId = String($(this).data("rel-id"));
        const val   = this.value;
        _noteTimer  = setTimeout(() => relUpdate(actor, relId, { note: val }), 1200);
    });

    $tab.on("blur", ".rel-note-input", async function () {
        clearTimeout(_noteTimer);
        const relId = String($(this).data("rel-id"));
        await relUpdate(actor, relId, { note: this.value });
    });

    // Recherche en temps réel
    $tab.on("input", ".rel-search-input", function () {
        const q = this.value.trim().toLowerCase();
        $tab.find(".rel-search-clear").toggle(!!q);
        let visible = 0;
        $tab.find(".rel-row").each(function () {
            const match = !q || $(this).find(".rel-name").text().toLowerCase().includes(q);
            $(this).toggle(match);
            if (match) visible++;
        });
        // Message "aucun résultat" si des lignes existent mais aucune ne correspond
        $tab.find(".rel-no-results").remove();
        if (q && $tab.find(".rel-row").length && !visible) {
            $tab.find(".rel-list").append(
                `<div class="rel-no-results rel-empty">
                    <i class="fa-solid fa-search"></i>
                    <span>${tl("Aucune relation trouvée.")}</span>
                </div>`
            );
        }
    });

    $tab.on("click", ".rel-search-clear", function (e) {
        e.stopPropagation();
        $tab.find(".rel-search-input").val("").trigger("input");
    });
}

// ---- Détection automatique (GM only) -----------------------

async function scanVisibleTokens() {
    if (!game.settings.get(MOD, "relationsEnabled")) return;
    if (game.user.isGM) return;  // scan côté joueur uniquement
    if (_scanning) return;
    _scanning = true;

    try {
        const tokens    = canvas.tokens?.placeables ?? [];
        const sceneName = canvas.scene?.name ?? game.scenes.current?.name ?? "";

        // Seul le personnage sur lequel le joueur est CONNECTÉ détecte
        // (Configuration du joueur → personnage). Sans personnage choisi, ou
        // s'il n'a pas de jeton sur cette scène : aucune détection.
        if (surCarteExpedition()) return;   // jamais sur les cartes des expéditions
        const myToken = jetonDuPersonnage();
        if (!myToken || !isInPJFolder(myToken.actor) || myToken.actor.type !== "character") return;
        const myActor = myToken.actor;

        const existing = new Set(relList(myActor).map(r => r.targetId));
        const quand = dateDeRencontre();

        // Relations déjà connues que le personnage revoit : date de dernière
        // rencontre (une écriture au plus par jour).
        if (dateRencontreActive()) {
            const revus = new Set(tokens.filter(t => t.actor?.id && existing.has(t.actor.id) && voit(myToken, t)).map(t => t.actor.id));
            const liste = relList(myActor);
            const nouvelle = liste.map(r => revus.has(r.targetId) && !memeRencontre(r.lastSeen, quand) ? { ...r, lastSeen: quand } : r);
            if (nouvelle.some((r, i) => r !== liste[i])) {
                await myActor.update({ [`flags.${MOD}.relationsList`]: nouvelle }, { render: false });
                const { texte, titre } = texteRencontre(quand);
                for (const r of nouvelle) if (revus.has(r.targetId))
                    document.querySelectorAll(`.rel-seen-value[data-rel-id="${r.id}"]`).forEach(el => { el.textContent = texte; el.closest(".rel-lastpos-row")?.setAttribute("title", titre); });
            }
        }

        // Jetons PJ (dossier des PJ) / PNJ (dossier des PNJ) que SON jeton voit :
        // pas derrière un mur ou une porte fermée, pas caché par le MJ, et
        // visible à l'écran si la scène utilise la vision des jetons.
        const vus = new Set();
        const toAdd = tokens.filter(t => {
            const a = t.actor;
            if (!a?.id || a.id === myActor.id || existing.has(a.id) || vus.has(a.id)) return false;
            if (!((isInPJFolder(a) && a.type === "character") || isInPNJFolder(a))) return false;
            if (a.getFlag(MOD, "excludedFromRelations") ?? false) return false;
            if (!voit(myToken, t)) return false;
            vus.add(a.id);
            return true;
        });

        if (!toAdd.length) return;

        const newRels = toAdd.map(t => ({
            id:           foundry.utils.randomID(12),
            targetId:     t.actor.id,
            targetName:   t.actor.name,
            targetImg:    t.actor.img ?? "",
            type:         "",
            level:        0,
            note:         "",
            lastPosition: sceneName,
            lastSeen:     quand,
            secret:       false,
            revealed:     !(t.actor.getFlag(MOD, "anonymous") ?? false),
        }));

        await myActor.setFlag(MOD, "relationsList", [...relList(myActor), ...newRels]);
    } finally {
        _scanning = false;
    }
}

// ---- Anonymisation (GM only) --------------------------------

// PJs présents sur la scène active (party courante)
function currentScenePJs() {
    return (canvas.tokens?.placeables ?? [])
        .filter(t => t.actor?.type === "character" && t.actor.id)
        .map(t => t.actor)
        .filter((a, i, arr) => arr.findIndex(b => b.id === a.id) === i);
}

// Révèle nom + portrait aux PJs de la scène qui ont déjà cet acteur dans leurs relations
async function revealRelationsToParty(actorId) {
    if (!game.user.isGM) return;
    for (const pj of currentScenePJs()) {
        const list = relList(pj);
        if (!list.some(r => r.targetId === actorId)) continue;
        await pj.update({ [`flags.${MOD}.relationsList`]: list.map(r =>
            r.targetId === actorId ? { ...r, revealed: true } : r
        )});
    }
}

// Masque nom + portrait pour les PJs de la scène qui ont cet acteur dans leurs relations
async function anonymizeRelations(actorId) {
    if (!game.user.isGM) return;
    for (const pj of currentScenePJs()) {
        const list = relList(pj);
        if (!list.some(r => r.targetId === actorId)) continue;
        await pj.update({ [`flags.${MOD}.relationsList`]: list.map(r =>
            r.targetId === actorId ? { ...r, revealed: false } : r
        )});
    }
}

// Retire définitivement cet acteur de TOUTES les listes de relations (tous les acteurs du monde)
async function removeFromAllRelations(actorId) {
    if (!game.user.isGM) return;
    for (const actor of game.actors ?? []) {
        const list = relList(actor);
        if (!list.some(r => r.targetId === actorId)) continue;
        await actor.setFlag(MOD, "relationsList", list.filter(r => r.targetId !== actorId));
    }
}

// ---- Export ------------------------------------------------

export function RelationsHooks() {
    // Scan initial — sight déjà calculé au moment de canvasReady
    Hooks.on("canvasReady", () => scanVisibleTokens());
    // sightRefresh couvre les scènes avec vision active
    Hooks.on("sightRefresh", () => {
        clearTimeout(_sightTimer);
        _sightTimer = setTimeout(() => scanVisibleTokens(), 500);
    });
    // createToken couvre les scènes sans vision (sightRefresh ne tire pas)
    Hooks.on("createToken", () => {
        clearTimeout(_sightTimer);
        _sightTimer = setTimeout(() => scanVisibleTokens(), 300);
    });
    // Un jeton qui bouge, apparaît (caché → visible) ou une porte qui s'ouvre
    // peut rendre une cible visible : nouveau contrôle.
    const relancer = () => { clearTimeout(_sightTimer); _sightTimer = setTimeout(() => scanVisibleTokens(), 400); };
    Hooks.on("updateToken", (doc, ch) => { if ("x" in ch || "y" in ch || "hidden" in ch) relancer(); });
    Hooks.on("updateWall", (doc, ch) => { if ("ds" in ch) relancer(); });
    Hooks.on("controlToken", relancer);
    Hooks.on("updateUser", (u, ch) => { if (u.id === game.user?.id && "character" in ch) relancer(); });

    // Boutons en-tête : Anonyme, Révéler, Retirer (Relations + Bestiaire) — GM uniquement
    Hooks.on("renderApplicationV2", (app, element) => {
        if (!game.user.isGM) return;
        if (!app.document || !(app.document instanceof Actor)) return;
        const actor = app.document;
        const header = element.querySelector(".window-header");
        if (!header || header.querySelector(".scwm-exclude-btn")) return;
        const id = actor.id;

        // ── Toggle "Anonyme" ──────────────────────────────────────
        const isAnon = () => !!(actor.getFlag(MOD, "anonymous") ?? false);
        const btnAnon = document.createElement("button");
        btnAnon.type = "button";
        btnAnon.classList.add("header-control", "icon", "fa-solid", "fa-eye-slash", "scwm-anon-btn");
        const refreshAnon = () => {
            btnAnon.style.color     = isAnon() ? "#e74c3c" : "";
            btnAnon.dataset.tooltip = isAnon() ? tl("Anonyme — cliquer pour désactiver") : tl("Rendre anonyme");
        };
        refreshAnon();
        btnAnon.addEventListener("click", async () => {
            await actor.setFlag(MOD, "anonymous", !isAnon());
            refreshAnon();
        });

        // ── Bouton "Révéler à la party" ───────────────────────────
        const btnReveal = document.createElement("button");
        btnReveal.type = "button";
        btnReveal.classList.add("header-control", "icon", "fa-solid", "fa-eye", "scwm-reveal-btn");
        btnReveal.dataset.tooltip = tl("Révéler à la party");
        btnReveal.addEventListener("click", () => Hooks.callAll("scwm:revealToParty", id));

        // ── Toggle "Bloquer l'ajout automatique" (Relations + Bestiaire) ──
        // N'agit que sur les flags : empêche les futurs ajouts auto, sans
        // toucher aux listes existantes. (Garde la classe scwm-exclude-btn
        // pour le garde-fou anti-doublon d'injection.)
        const isExcluded = () =>
            !!(actor.getFlag(MOD, "excludedFromRelations") ?? false) ||
            !!(actor.getFlag(MOD,  "excludedFromBestiary")  ?? false);
        const btnBlock = document.createElement("button");
        btnBlock.type = "button";
        btnBlock.classList.add("header-control", "icon", "fa-solid", "fa-ban", "scwm-exclude-btn");
        const refreshBlock = () => {
            btnBlock.style.color     = isExcluded() ? "#e74c3c" : "";
            btnBlock.dataset.tooltip = isExcluded()
                ? tl("Ajout automatique bloqué — cliquer pour réactiver")
                : "Bloquer l'ajout automatique (Relations & Bestiaire)";
        };
        refreshBlock();
        btnBlock.addEventListener("click", async () => {
            const nowExcluded = !isExcluded();
            await actor.setFlag(MOD, "excludedFromRelations", nowExcluded);
            await actor.setFlag(MOD,  "excludedFromBestiary",  nowExcluded);
            refreshBlock();
        });

        // ── Bouton "Retirer de chez tous les joueurs" ─────────────
        // Action ponctuelle : retire ce personnage des listes existantes de
        // TOUS les joueurs (Relations + Bestiaire), sans modifier le blocage.
        const btnRemove = document.createElement("button");
        btnRemove.type = "button";
        btnRemove.classList.add("header-control", "icon", "fa-solid", "fa-users-slash", "scwm-removeall-btn");
        btnRemove.dataset.tooltip = tl("Retirer de chez tous les joueurs (Relations & Bestiaire)");
        btnRemove.addEventListener("click", async () => {
            const ok = await foundry.applications.api.DialogV2.confirm({
                window:  { title: tl("Retirer de chez tous les joueurs") },
                content: `<p>${tl("Retirer <strong>{0}</strong> des Relations et du Bestiaire de <strong>tous les joueurs</strong> ?", escA(actor.name))}</p>
                          <p style="opacity:0.7;font-size:0.9em;">${tl("Les listes existantes sont nettoyées. Sans blocage, ce personnage pourra être ré-ajouté automatiquement s'il est recroisé.")}</p>`
            });
            if (!ok) return;
            Hooks.callAll("scwm:removeFromRelations", id);
            Hooks.callAll("scwm:removeFromBestiary",  id);
            ui.notifications.info(tl("{0} retiré des listes de tous les joueurs.", actor.name));
        });

        // Position : ordre visuel Bloquer | Retirer | Révéler | Anonyme
        const title = header.querySelector(".window-title");
        if (title) {
            title.insertAdjacentElement("afterend", btnAnon);
            title.insertAdjacentElement("afterend", btnReveal);
            title.insertAdjacentElement("afterend", btnRemove);
            title.insertAdjacentElement("afterend", btnBlock);
        } else {
            const close = header.querySelector(".close");
            header.insertBefore(btnAnon,   close);
            header.insertBefore(btnReveal, btnAnon);
            header.insertBefore(btnRemove, btnReveal);
            header.insertBefore(btnBlock,  btnRemove);
        }
    });

    // Répondre aux hooks inter-modules
    Hooks.on("scwm:revealToParty",       actorId => revealRelationsToParty(actorId));
    Hooks.on("scwm:anonymize",           actorId => anonymizeRelations(actorId));
    Hooks.on("scwm:removeFromRelations", actorId => removeFromAllRelations(actorId));
}
