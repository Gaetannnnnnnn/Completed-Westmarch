// ============================================================
// settings.js — Paramètres unifiés du module Soruta — Completed Westmarch
// Tous les settings des 9 anciens modules, sous le namespace unique MOD.
// Les clés en collision ont été préfixées par domaine (relations*, bestiary*,
// carnet*, rangeFix*, tuto*). Voir migration.js pour la reprise des valeurs.
// © 2026 Soruta.
// ============================================================

import { MOD, TUTO_TOGGLES, TM_DEFAULT_SCROLL, TM_DEFAULT_MAGIC, TM_DEFAULT_ROLL, DEACTIVATION_CODE } from "./const.js";
import { journal } from "./log.js";
import { registerDiagnosticMenu } from "./diagnostic.js";
import { registerLicenceSettings, licenceValide, etatLicence, activerLicence, messageLicence } from "./licence.js";
import { registerSiteSettings, URL_PAGE_MODULE } from "./site.js";
import { applyPartyPause } from "./partypause.js";
import { openProfilesEditor } from "./companions.js";
import { openUiHideDialog, applyUiHiding } from "./uihide.js";
import { applyChatCardPrefs } from "./chat.js";
import { blocGuideReglagesHtml, genererEtOuvrirGuide } from "./rangement.js";
import { registerXpProgressSettings, XP_PROG_KEYS, xpProgControlHtml, wireXpProg, readXpProg } from "./xpprogress.js";
import { registerMondeSettings, MONDE_KEYS, mondeControlHtml, cablerMonde, lireMonde, afficherBanniere } from "./monde.js";
import { tl } from "./i18n.js";

// ============================================================
// Ressources communes — accès centralisé (avec repli sur les anciennes clés
// par feature, pour ne rien casser tant que la migration n'a pas tourné).
// ============================================================
export const commonFolderPJ       = () => game.settings.get(MOD, "commonFolderPJ")       || game.settings.get(MOD, "relationsFolderPJ")    || game.settings.get(MOD, "bestiaryFolderPJ") || "";
export const commonFolderPNJ      = () => game.settings.get(MOD, "commonFolderPNJ")      || game.settings.get(MOD, "relationsFolderPNJ")   || "";
export const commonFolderNewChars = () => game.settings.get(MOD, "commonFolderNewChars") || game.settings.get(MOD, "charValidationFolder") || "";
export const commonPackPNJ        = () => game.settings.get(MOD, "commonPackPNJ")        || game.settings.get(MOD, "relationsPackPNJ")     || "";
export const commonPackCemetery   = () => game.settings.get(MOD, "commonPackCemetery")   || game.settings.get(MOD, "relationsPackCemetery")|| "";
export const commonPackCreatures  = () => game.settings.get(MOD, "commonPackCreatures")  || game.settings.get(MOD, "bestiaryPackCreatures")|| "";
export const commonPackCraft      = () => game.settings.get(MOD, "commonPackCraft")      || game.settings.get(MOD, "tmCraftPack")          || "";

// Recopie une seule fois les anciennes valeurs par feature vers les clés
// communes, pour qu'elles s'affichent dans la nouvelle section centrale.
export async function migrateCommonResources() {
    if (!game.user.isGM) return;
    try { if (game.settings.get(MOD, "enableLegacyMigration") === false) return; } catch {}
    if (game.settings.get(MOD, "commonResourcesMigrated")) return;
    const map = {
        commonFolderPJ:       ["relationsFolderPJ", "bestiaryFolderPJ"],
        commonFolderPNJ:      ["relationsFolderPNJ"],
        commonFolderNewChars: ["charValidationFolder"],
        commonPackPNJ:        ["relationsPackPNJ"],
        commonPackCemetery:   ["relationsPackCemetery"],
        commonPackCreatures:  ["bestiaryPackCreatures"],
        commonPackCraft:      ["tmCraftPack"]
    };
    for (const [dest, srcs] of Object.entries(map)) {
        if (game.settings.get(MOD, dest)) continue;
        for (const s of srcs) {
            const v = game.settings.get(MOD, s);
            if (v) { await game.settings.set(MOD, dest, v); break; }
        }
    }
    await game.settings.set(MOD, "commonResourcesMigrated", true);
}

// Settings dont l'utilité dépend entièrement du système de party.
export const PARTY_DEPENDENT_SETTINGS = [
    "enableJoinScene",
    "enableShowParty",
    "enableChatFilter",
    "enablePlayerGrouping",
    "enableGoWithPartyScenes",
    "enableGoWithPartyJournal",
    "enableSessionLog",
    "enableCombatParty",
    "enableCombatTurnLock",
    "enablePartyPause"
];

// Section « Horloge de party » : options grisées quand l'interrupteur
// principal (enablePartyTime) est coupé ; les 3 réglages de l'obscurité
// sont en plus grisés quand l'obscurité est coupée.
const PARTYTIME_SUB_SETTINGS = [
    "partyTimeRealTime", "partyTimeCombatRounds", "partyTimeShowClock",
    "partyTimeRations", "partyTimeHungerWarning", "partyTimeWaterReminder",
    "partyTimeChatSummary", "partyTimeCatchUp", "enablePartyDarkness",
    "partyDarknessNight", "partyDarknessSunrise", "partyDarknessSunset"
];
const PARTYDARK_SUB_SETTINGS = ["partyDarknessNight", "partyDarknessSunrise", "partyDarknessSunset"];

// Vérifie qu'un setting dépendant de la party est actif ET que la party l'est.
export function partyFeatureEnabled(key) {
    if (!game.settings.get(MOD, "enableParty")) return false;
    return game.settings.get(MOD, key);
}

// config: false → les réglages ne s'affichent plus en liste dans la config du
// module ; ils sont édités via les fenêtres de catégorie (registerMenu).
const B = (name, hint, def = true, extra = {}) => ({
    name, hint, scope: "world", config: false, type: Boolean, default: def, requiresReload: false, ...extra
});
const N = (name, hint, def) => ({
    name, hint, scope: "world", config: false, type: Number, default: def, requiresReload: false
});
const S = (name, hint, def = "") => ({
    name, hint, scope: "world", config: false, type: String, default: def, requiresReload: false
});

export function registerSettings() {

    // ============================================================
    // DOSSIERS & COMPENDIUMS COMMUNS
    // Renseignés une seule fois ici ; lus par toutes les fonctions
    // (Relations, Bestiaire, Création de perso, Temps morts).
    // ============================================================
    game.settings.register(MOD, "commonFolderPJ", S(
        tl("Dossier des PJ"),
        tl("Dossier d'acteurs contenant les personnages joueurs. Utilisé par Relations et Bestiaire pour reconnaître les PJ.")));
    game.settings.register(MOD, "autoPlayerFolder", B(
        tl("Sous-dossier auto au nom du joueur"),
        tl("À la première connexion d'un joueur, crée automatiquement dans le « Dossier des PJ » un sous-dossier portant son nom."), true));
    game.settings.register(MOD, "gmAutoFolderParent", S(
        tl("Sous-dossier auto au nom du MJ — dossier parent"),
        tl("Nom du dossier parent (identique dans Acteurs, Journaux et Scènes) dans lequel, à la connexion d'un MJ, un sous-dossier à son nom est créé automatiquement dans ces trois arbres. Laisser vide pour désactiver.")));
    game.settings.register(MOD, "commonFolderPNJ", S(
        tl("Dossier des PNJ"),
        tl("Dossier d'acteurs des PNJ récurrents (alliés, marchands, figures importantes). Utilisé par Relations.")));
    game.settings.register(MOD, "commonFolderNewChars", S(
        tl("Dossier des nouveaux personnages"),
        tl("Dossier où sont créés les personnages validés (Création de personnages).")));
    game.settings.register(MOD, "commonPackPNJ", S(
        tl("Compendium des PNJ"),
        tl("Compendium d'acteurs PNJ. Ses personnages sont proposés dans le sélecteur de relations (groupe PNJ).")));
    game.settings.register(MOD, "commonPackCemetery", S(
        tl("Compendium du cimetière"),
        tl("Compendium d'acteurs (anciens PJ / cimetière). Proposé dans le sélecteur de relations (groupe Joueurs).")));
    game.settings.register(MOD, "commonPackCreatures", S(
        tl("Compendium des créatures"),
        tl("Compendium d'acteurs créatures. Utilisé par le Bestiaire (ajout et reconnaissance des créatures).")));
    game.settings.register(MOD, "commonPackCraft", S(
        tl("Compendium des objets craftables"),
        tl("Compendium d'OBJETS (ex. importé via Plutonium). Utilisé par l'artisanat des temps morts pour attribuer l'objet fabriqué.")));
    game.settings.register(MOD, "commonResourcesMigrated", {
        scope: "world", config: false, type: Boolean, default: false, requiresReload: false
    });

    // ============================================================
    // À PROPOS & PROTECTION
    // Le module ne fonctionne qu'avec une licence valide pour ce monde, délivrée
    // par le serveur licence.altheia.eu (voir licence.js). Il n'y a volontairement
    // AUCUN interrupteur pour désactiver la protection.
    // ============================================================
    registerLicenceSettings();
    registerSiteSettings();

    // ============================================================
    // WESTMARCH — Système de party (core)
    // ============================================================
    game.settings.register(MOD, "enableParty", B(
        tl("Système de Party"),
        tl("Active le système de party (Create/Join/Leave/Kick/Invite Party). Si désactivé, toutes les options qui en dépendent sont automatiquement désactivées.")));
    game.settings.register(MOD, "enableJoinScene", B(
        tl("Join Scene"),
        tl("Ajoute une option 'Join Scene' dans le menu contextuel de la liste des joueurs (téléportation vers la scène d'un autre membre).")));
    game.settings.register(MOD, "enableShowParty", B(
        tl("Show Party (partage d'image)"),
        tl("Ajoute un bouton 'Show Party' dans la barre de titre des fenêtres d'image (partage à tous les membres de la party).")));
    game.settings.register(MOD, "enablePlayerGrouping", B(
        tl("Regroupement visuel des joueurs par party"),
        tl("Réorganise la liste des joueurs pour regrouper visuellement les membres d'une même party.")));
    game.settings.register(MOD, "enableGoWithPartyScenes", B(
        tl("Go With Party (répertoire de scènes)"),
        tl("Ajoute 'Go With Party' dans le menu contextuel du répertoire de scènes (téléporte toute la party).")));
    game.settings.register(MOD, "enableGoWithPartyJournal", B(
        tl("Go With Party (liens de journaux)"),
        tl("Ajoute 'Go Alone' et 'Go With Party' au menu contextuel des liens de scène dans les journaux.")));
    game.settings.register(MOD, "enableChatFilter", B(
        tl("Filtrage du chat par party"),
        tl("Les joueurs ne voient que les messages des membres de leur propre party.")));
    game.settings.register(MOD, "enableChatTabs", B(
        tl("Onglets de chat (IC / Autre / OOC)"),
        tl("Affiche la barre d'onglets qui sépare les messages par type. Désactivé : tous les messages (de la party) sont regroupés au même endroit, sans onglets."),
        false));
    game.settings.register(MOD, "enableNoteLink", B(
        tl("Carnet commun (notes liées)"),
        tl("Le MJ peut lier les notes des joueurs de sa party via un « carnet commun » (un journal partagé, éditable par tous les membres liés). Le lien survit à la dissolution de la party. Un joueur n'appartient qu'à un seul groupe à la fois."),
        false));
    // Groupes de carnets communs : [{ id, journalId, members:[userId] }]. Non affiché.
    game.settings.register(MOD, "noteLinkGroups", {
        scope: "world", config: false, type: Array, default: []
    });
    game.settings.register(MOD, "enableSessionLog", B(
        tl("Rapport de session"),
        tl("Active le suivi de session (dès la création de party) et le bouton 'Clore la session', qui envoie le récap (XP, ennemis, PNJ, objets) sur le webhook Discord ci-dessous.")));
    game.settings.register(MOD, "sessionLogWebhookUrl", S(
        tl("URL du Webhook Discord (rapport de session)"),
        tl("Le bouton 'Clore la session' envoie le rapport (même contenu que les anciens journaux) sur ce webhook. Laisser vide pour désactiver l'envoi.")));
    game.settings.register(MOD, "sessionLogForum", B(
        tl("Salon Discord de type Forum"),
        tl("Si le webhook pointe vers un salon Forum : les rapports sont regroupés dans un post (fil) de forum par meneur, réutilisé à chaque nouveau rapport. Laisser désactivé pour un salon textuel classique."),
        false));
    // Fils de forum créés par meneur (gmId → threadId). Non affiché.
    game.settings.register(MOD, "sessionForumThreads", {
        scope: "world", config: false, type: Object, default: {}
    });
    // Brouillons de rapports de session (Casier du GM). Non affiché.
    game.settings.register(MOD, "sessionDrafts", {
        scope: "world", config: false, type: Array, default: []
    });
    // Journal des sessions clôturées (assiduité) : { id, gmId, gmName, dateISO,
    // players:[{actorId,name}] }. Alimenté à chaque clôture. Non affiché.
    game.settings.register(MOD, "sessionLog", {
        scope: "world", config: false, type: Array, default: []
    });
    // Intrigues (tags) prédéfinies pour relier des rapports d'une même trame.
    game.settings.register(MOD, "sessionTags", {
        scope: "world", config: false, type: Array, default: []
    });
    // Intrigues PERSO de chaque MJ (scope utilisateur) : créées à la volée depuis
    // « Clore la session », gardées en mémoire, séparées de la liste partagée.
    game.settings.register(MOD, "sessionTagsPersonal", {
        scope: "user", config: false, type: Array, default: []
    });

    // ============================================================
    // SYSTÈME D'ÉTOILES (XP par étoiles)
    // enableStarXp : interrupteur général. starXpLevels : tableau de 19
    // entrées (niveau i→i+1) = étoiles requises. Édité en grille avec total.
    // ============================================================
    game.settings.register(MOD, "enableStarXp", B(
        tl("Système d'étoiles (XP par étoiles)"),
        tl("Remplace l'XP chiffrée par des étoiles. À la clôture de session, le MJ attribue des étoiles (le maximum se règle ci-dessous) ; chaque niveau coûte un nombre d'étoiles réglé dans le tableau. Sur la fiche, l'XP est remplacée par un compteur d'étoiles."),
        false));
    // Panneau de configuration : n'afficher que ce qui est actif (préférence
    // de chaque MJ, cochée par défaut ; voir openConfigHub).
    game.settings.register(MOD, "hubActifsSeulement", {
        scope: "user", config: false, type: Boolean, default: true, requiresReload: false
    });
    game.settings.register(MOD, "starXpMaxAward", {
        name: tl("Étoiles maximum par session"),
        hint: tl("Nombre d'étoiles que le MJ peut donner au plus dans « Clore la session » (et dans le Casier pour une attribution en attente). 3 par défaut."),
        scope: "world", config: false, type: Number, default: 3, range: { min: 1, max: 10, step: 1 }, requiresReload: false
    });
    game.settings.register(MOD, "starXpLevels", {
        scope: "world", config: false, type: Array, default: Array.from({ length: 19 }, () => 3)
    });

    // ============================================================
    // PROGRESSION PAR L'XP DE BASE (D&D 5e) — voir xpprogress.js
    // Tableau dynamique, curseurs, XP par défaut, plages de bonus, niveau max.
    // ============================================================
    registerXpProgressSettings();

    // ============================================================
    // REGISTRE DU MONDE (PNJ, lieux, organisations) — voir monde.js
    // ============================================================
    registerMondeSettings();
    // Profils de Casier par GM (présentation du dashboard, etc.). Non affiché.
    game.settings.register(MOD, "casierProfiles", {
        scope: "world", config: false, type: Object, default: {}
    });
    game.settings.register(MOD, "enableCombatParty", B(
        tl("Combat lié à la party (plutôt qu'à la scène)"),
        tl("Les combats créés par un GM sont détachés de la scène et associés à sa party. Chaque joueur ne voit que le combat de sa party.")));
    game.settings.register(MOD, "enableCombatTurnLock", B(
        tl("Blocage de mouvement hors tour (combat)"),
        tl("Pendant le combat de votre party, un joueur ne peut déplacer son token que quand c'est son tour. Le combat d'une autre party n'affecte jamais vos joueurs. Ne nécessite pas Monk's TokenBar.")));
    game.settings.register(MOD, "enablePartyPause", B(
        tl("Pause de party (remplace le pause global)"),
        tl("Remplace le pause natif de Foundry par un pause propre à chaque party : le GM met SA party en pause (bandeau + blocage du déplacement de ses joueurs), sans affecter les autres. Masque l'indicateur de pause natif. Nécessite un rechargement."),
        false, { requiresReload: true }));
    game.settings.register(MOD, "enableCharValidation", B(
        tl("Validation des personnages"),
        tl("Les joueurs demandent la création d'un personnage ; un GM valide depuis le Casier (un acteur est créé dans un dossier dédié, le joueur en devient propriétaire). Le joueur construit sa fiche puis la soumet ; à la validation, la fiche est verrouillée (construction non modifiable côté joueur, jeu libre).")));
    game.settings.register(MOD, "charMaxTotal", N(
        tl("Nombre de personnages max par joueur"),
        tl("Nombre maximum de personnages qu'un joueur peut posséder (actifs + en stock). 0 = illimité."),
        0));
    game.settings.register(MOD, "charMaxActive", N(
        tl("Personnages actifs simultanés"),
        tl("Nombre de personnages jouables en même temps. Les autres passent « en stock » (cadenas, en Observateur, non jouables)."),
        2));
    game.settings.register(MOD, "blockPlayerPlutonium", B(
        tl("Bloquer les imports Plutonium hors autorisation"),
        tl("Empêche les joueurs d'importer du contenu Plutonium sur une fiche VERROUILLÉE. L'import n'est possible que pendant une fenêtre autorisée par le MJ (création du personnage, ou montée de niveau validée). Les GM ne sont jamais bloqués.")));
    game.settings.register(MOD, "charFreeLevelUp", B(
        tl("Montées de niveau libres (sans validation MJ)"),
        tl("Mode confiance : une fois le personnage validé à la création, les modifications de construction (montées de niveau) ne sont PLUS bloquées ni reverrouillées — le joueur monte de niveau librement, sans passer par le MJ. Le verrou ne s'applique donc qu'à la création initiale."),
        false));
    game.settings.register(MOD, "charNotifyLevelUp", B(
        tl("Notifier le MJ des montées de niveau"),
        tl("Quand les montées de niveau sont libres, poste quand même au MJ un récapitulatif des changements (niveau, classe, aptitudes, sorts ajoutés/retirés) — pour information, sans rien bloquer."),
        true));
    game.settings.register(MOD, "charValidationFolder", S(
        tl("Validation — Dossier des personnages"),
        tl("Nom du dossier d'acteurs où sont créés les personnages validés."),
        tl("Personnages")));

    // ---- Contrôle des sources (livres/extensions autorisés) ----
    game.settings.register(MOD, "enableSourceControl", B(
        tl("Contrôle des sources autorisées"),
        tl("Réglemente quels livres/extensions D&D (Xanathar, Tal'Dorei, etc.) peuvent être ajoutés à une fiche PJ, quelle que soit la méthode (import Plutonium/5etools, glisser-déposer, création manuelle). Le contenu d'une source non autorisée est bloqué avec un avertissement."),
        false));
    game.settings.register(MOD, "sourceAllowPlayers", S(
        tl("Sources autorisées — Joueurs"),
        tl("Liste blanche des sources autorisées pour les JOUEURS. Sépare les entrées par « ; ». Une entrée = « Source » (tous types) ou « Source : type1, type2 » pour n'autoriser que certains types de cette source. ")
        + tl("Types : race, classe, sous-classe, don, sort, historique, objet. ")
        + tl("Ex. : « PHB 2024 ; Tal'Dorei : race ; Xanathar : sous-classe, don » = tout de PHB 2024, mais seulement les races de Tal'Dorei et seulement sous-classes/dons de Xanathar. Laisser vide = aucune restriction pour les joueurs.")));
    game.settings.register(MOD, "sourceAllowGm", S(
        tl("Sources autorisées — MJ"),
        tl("Liste blanche des sources autorisées pour le MJ, même syntaxe que pour les joueurs (« Source » ou « Source : type1, type2 », entrées séparées par « ; »). Laisser vide = aucune restriction pour le MJ.")));
    game.settings.register(MOD, "sourceDeny", S(
        tl("Sources / identifiants INTERDITS"),
        `${tl("Liste noire PRIORITAIRE, pour tout le monde (joueurs ET MJ), sur les fiches PJ. Chaque entrée interdit un contenu si elle correspond à sa <strong>source</strong> OU à son <strong>identifiant</strong> — pratique pour bannir un <strong>sort précis</strong> (ex. « conjure-animals ») ou une source entière, même si elle est par ailleurs autorisée. Entrées séparées par « ; ». La correspondance exacte/souple suit le même réglage que les listes blanches.")}`));
    game.settings.register(MOD, "sourceMatchField", {
        name: tl("Champ comparé (Book ou Identifier)"),
        hint: tl("Choisit sur quel champ de la source portent les listes ci-dessus. « Book » = le livre (ex. « PHB 2024 »), plus large. « Identifier » = l'identifiant précis de l'objet (ex. « unarmed-strike »), pour un filtrage fin. « Les deux » accepte une correspondance sur l'un OU l'autre."),
        scope: "world", config: false, type: String, default: "book", requiresReload: false,
        choices: { book: tl("Book (livre)"), identifier: tl("Identifier (identifiant)"), both: tl("Les deux (l'un ou l'autre)") }
    });
    game.settings.register(MOD, "sourceMatchExact", B(
        tl("Correspondance exacte des sources"),
        tl("Activé : une source n'est autorisée que si elle correspond EXACTEMENT à une entrée de la liste (« PHB » n'autorise pas « XPHB », le PHB 2024). Désactivé : correspondance souple (une entrée autorise toute source qui la contient) — plus permissif mais risque d'autoriser des sources proches sans le vouloir."),
        true));
    game.settings.register(MOD, "sourceBlockUnknown", B(
        tl("Bloquer le contenu sans source identifiable"),
        tl("Refuse tout contenu dont la source ne peut pas être déterminée (homebrew, objet créé à la main, source vide). Ne s'applique que si une liste de sources est renseignée pour le rôle concerné."),
        true));
    // --- Monnaie (bourse) ---
    game.settings.register(MOD, "disableElectrum", B(
        tl("Retirer l'électrum (EP)"),
        tl("Masque le slot Électrum sur les fiches et les contenants, et force toute valeur d'EP à 0 (aucune pièce d'électrum ne peut être ajoutée). Astuce : si des personnages ont déjà de l'EP, convertissez-la en PA avant d'activer (1 EP = 5 PA)."),
        false));
    game.settings.register(MOD, "currencyContainerBlock", {
        name: tl("Pièces dans les contenants (sacs, poches…)"),
        hint: tl("Empêche de ranger des pièces dans un contenant : la richesse doit rester sur la bourse de la fiche. ⚠️ Si DÉSACTIVÉ, des pièces peuvent être cachées dans des sacs/poches et ne seront PAS vues par les modules qui lisent la bourse de la fiche — ex. « Temps morts » (coûts/gains de la période), les calculs de richesse, etc. → totaux faussés. Pour un fonctionnement fiable de ces modules, activez « Joueurs uniquement » (ou « Tout le monde »)."),
        scope: "world", config: false, type: String, default: "off", requiresReload: false,
        choices: { off: tl("Désactivé"), players: tl("Joueurs uniquement"), all: tl("Tout le monde") }
    });
    // État de pause par party (mapping partyId -> true), synchronisé sur tous
    // les clients. Non affiché dans la configuration.
    // --- Horloge de party (section dédiée, voir partytime.js) ---
    game.settings.register(MOD, "enablePartyTime", B(
        tl("Horloge de party"),
        tl("Interrupteur principal. Chaque party a sa propre date pendant l'expédition : elle démarre à l'ouverture de l'expédition et le GM l'avance par heures ou par jours (bouton sablier du groupe WestMarch). La date de la party est proposée à la clôture. Nécessite le Système de Party.")));
    game.settings.register(MOD, "partyTimeRealTime", B(
        tl("Écoulement en temps réel"),
        tl("Hors combat, le temps de la party s'écoule tout seul : une seconde réelle = une seconde de jeu. Il s'arrête quand la party est en pause, en combat, ou dissoute (clôture de session).")));
    game.settings.register(MOD, "partyTimeCombatRounds", B(
        tl("+6 secondes par round de combat"),
        tl("Pendant un combat de la party, chaque nouveau round ajoute 6 secondes à son horloge (durée d'un round de D&D).")));
    game.settings.register(MOD, "partyTimeShowClock", B(
        tl("Afficher l'horloge de la party"),
        tl("Hors combat : barre fine en haut de l'écran (heure avec les secondes, date, bouton calendrier ; pour le MJ : jour suivant et curseur pour avancer le temps). En combat : à droite de la liste des joueurs. Chacun voit l'heure de SA party (ou du calendrier du monde hors expédition) et peut la masquer pour lui dans Accessibilité.")));
    game.settings.register(MOD, "partyTimeRations", B(
        tl("Consommation des rations"),
        tl("Chaque jour franchi retire 1 ration par PJ, sauf ceux cochés « Nourri autrement » dans la fenêtre d'avance du temps.")));
    game.settings.register(MOD, "partyTimeHungerWarning", B(
        tl("Alerte de faim et d'épuisement"),
        tl("Quand un PJ n'a plus de rations : message dans le chat avec les jours sans manger, et rappel de la règle d'Épuisement au-delà de 3 + mod. de Constitution jours. Rien n'est appliqué automatiquement. Nécessite la consommation des rations.")));
    game.settings.register(MOD, "partyTimeWaterReminder", B(
        tl("Rappel de l'eau"),
        tl("À chaque nouveau jour de la party, ajoute un rappel dans le chat pour l'eau (outres à remplir). Simple rappel, rien n'est retiré.")));
    game.settings.register(MOD, "partyTimeChatSummary", B(
        tl("Résumé dans le chat"),
        tl("À chaque avance, publie dans le chat de la party la nouvelle date et les rations consommées. Coupé : seules les alertes (faim, eau) sont publiées, et le GM voit la date dans une notification.")));
    game.settings.register(MOD, "partyTimeCatchUp", B(
        tl("Rattrapage du calendrier global"),
        tl("À la clôture de l'expédition, le calendrier global avance jusqu'à la date de la party si elle est plus loin. Coupé : le calendrier global n'est jamais modifié par l'horloge de party.")));
    game.settings.register(MOD, "enablePartyDarkness", B(
        tl("Obscurité des scènes"),
        tl("Les scènes marquées « Suivre l'heure de la party » (clic droit dans le répertoire des scènes) prennent l'obscurité de l'heure de la party qui s'y trouve. Deux parties sur la même scène : la première arrivée garde la main jusqu'à son départ.")));
    game.settings.register(MOD, "partyDarknessNight", N(
        tl("Obscurité : niveau de nuit"),
        tl("Obscurité appliquée la nuit (0 = plein jour, 1 = noir complet)."),
        0.9));
    game.settings.register(MOD, "partyDarknessSunrise", N(
        tl("Obscurité : heure du lever du soleil"),
        tl("Heure où l'aube commence ; il fait plein jour 2 h plus tard."),
        6));
    game.settings.register(MOD, "partyDarknessSunset", N(
        tl("Obscurité : heure du coucher du soleil"),
        tl("Heure où il fait nuit noire ; le crépuscule commence 2 h avant."),
        20));
    game.settings.register(MOD, "partyClockState", {
        scope: "world", config: false, type: Object, default: {}
    });
    game.settings.register(MOD, "partyPauseState", {
        scope: "world", config: false, type: Object, default: {},
        onChange: () => applyPartyPause()
    });
    game.settings.register(MOD, "enableAntiCheat", B(
        tl("Anti-Cheat (combat)"),
        tl("Pendant un combat actif, avertit les GM en privé si un joueur modifie ses sorts préparés, son attunement ou son équipement.")));

    // ============================================================
    // SERVEUR — Personnalisations
    // ============================================================
    game.settings.register(MOD, "enableXpBlock", B(
        tl("Blocage de l'XP et du Level Up"),
        tl("Empêche les joueurs de modifier leur XP et masque le bouton Level Up. Les GM ne sont pas affectés.")));
    game.settings.register(MOD, "enableFakeWarning", B(
        tl("Faux message de maintenance (farce GM)"),
        tl("Ajoute un bouton GM dans la barre WestMarch pour envoyer un faux avertissement jaune (« Mise à jour effectuée… ») à un joueur. Décochez pour retirer complètement le bouton."),
        true));
    game.settings.register(MOD, "enableGmNotes", B(
        tl("Note GM sur les fiches PJ"),
        tl("Ajoute un onglet « Note GM » sur les fiches de personnage, visible et modifiable uniquement par les GM. Les joueurs ne voient pas l'onglet. Nécessite un rechargement."),
        true, { requiresReload: true }));
    game.settings.register(MOD, "enableGmNotesNpc", B(
        tl("Note GM sur les fiches PNJ"),
        tl("Ajoute le même onglet « Note GM » (privé, MJ uniquement) sur les fiches de PNJ. Indépendant de l'option PJ. Nécessite un rechargement."),
        true, { requiresReload: true }));
    game.settings.register(MOD, "createPantheonFolder", B(
        tl("Dossier « Panthéons » (Dieux de Faerûn)"),
        tl("Au premier lancement, crée dans les Journaux un dossier « Panthéons » (couleur #860404) contenant le compendium des dieux de Faerûn fourni avec le module. Décoché : ne crée rien. Une fois créé, il n'est pas recréé si vous le supprimez."),
        true));
    // Garde-fou : création effectuée une seule fois (ne pas recréer après suppression).
    game.settings.register(MOD, "pantheonCreatedOnce", {
        scope: "world", config: false, type: Boolean, default: false
    });
    // Garde-fou : partage (visibilité joueurs) appliqué une seule fois à l'existant.
    game.settings.register(MOD, "pantheonSharedOnce", {
        scope: "world", config: false, type: Boolean, default: false
    });

    // ---- Rappels de combat (assistant contextuel, dépend de Midi-QOL) ----
    game.settings.register(MOD, "enableReactReminder", B(
        tl("Rappel des réactions"),
        tl("Quand un PJ est réellement ciblé par une attaque (via Midi-QOL), lui propose ses réactions dans un pop-up et prévient le MJ de sa party qu'il réfléchit ; le choix du joueur ferme la notif du MJ."),
        false));
    game.settings.register(MOD, "enableBonusReminder", B(
        tl("Rappel des actions bonus utiles"),
        tl("Propose une action bonus pertinente au bon moment (ex. Divine Smite après un coup au corps-à-corps si le PJ a des emplacements de sort)."),
        false));
    game.settings.register(MOD, "enableMasteryReminder", B(
        tl("Rappel des maîtrises d'arme (weapon mastery)"),
        tl("Si l'arme utilisée possède une maîtrise sur la fiche du PJ, rappelle son effet lors de l'attaque."),
        false));
    game.settings.register(MOD, "enableAdvantageReminder", B(
        tl("Rappel avantage / désavantage"),
        tl("Au jet d'attaque, signale les sources d'avantage/désavantage selon l'état de la cible (à terre + CaC…) et les effets de statut du PJ."),
        false));
    // Opt-out PAR JOUEUR (réglage du compte, visible et modifiable par chacun) :
    // coupe les pop-ups/chuchotements de rappels de combat sur SON écran.
    game.settings.register(MOD, "combatRemindersOff", {
        name: tl("Désactiver mes rappels de combat"),
        hint: tl("Coché = tu ne reçois plus les pop-ups et chuchotements de rappels de combat (réactions, châtiments/smite, avantage/désavantage, maîtrises). N'affecte que TON écran, pas les autres joueurs ni le MJ."),
        scope: "user", config: true, type: Boolean, default: false
    });
    game.settings.register(MOD, "hidePlayerStarTab", B(
        tl("Masquer l'onglet « étoile » aux joueurs"),
        tl("Cache l'onglet dont l'icône est une étoile (favoris) sur les fiches de personnage, pour les joueurs uniquement. Les GM le voient toujours.")));
    game.settings.register(MOD, "enableDiscordLog", B(
        tl("Log Discord (modifications)"),
        tl("Envoie un message Discord à chaque ajout/suppression d'objet, changement de quantité/monnaie, gain d'XP/niveau, et création/suppression de personnage."),
        false));
    game.settings.register(MOD, "discordLogWebhookUrl", S(
        tl("URL du Webhook Discord (log modifications)"),
        tl("URL du webhook Discord pour les logs de modifications. Laisser vide pour désactiver.")));
    // --- Contenu loggé (cases à cocher, sous-section « Log Discord ») ---
    game.settings.register(MOD, "logInventory", B(
        tl("Objets d'inventaire"),
        tl("Logge l'ajout, le retrait et les changements de quantité des objets (armes, équipement, consommables, outils, butin)."), true));
    game.settings.register(MOD, "logXp", B(
        "XP",
        tl("Logge les changements de points d'expérience."), true));
    game.settings.register(MOD, "logCurrency", B(
        tl("Pièces / monnaie"),
        tl("Logge les changements de bourse (PO, PA, PE, PC, PP)."), true));
    game.settings.register(MOD, "logLevelsElements", B(
        tl("Niveaux & autres éléments"),
        tl("Logge les montées de niveau ET l'ajout/retrait de tout autre élément d'une fiche : sorts, dons, races, classes, sous-classes, historiques."), true));
    game.settings.register(MOD, "logModuleErrors", B(
        tl("Problèmes du module"),
        tl("Envoie dans ce salon les vrais problèmes du module (fonction cassée, erreur, conflit avec un autre module ou une mise à jour de Foundry), avec l'endroit, les versions, la mention « Contacter le propriétaire du module » et le lien du Discord Althéia pour ouvrir un ticket. Un même problème n'est envoyé qu'une fois toutes les 10 minutes."), true));
    game.settings.register(MOD, "logSheetEdits", B(
        tl("Modifications des fiches"),
        tl("Logge toute modification faite sur une fiche : objets, aptitudes, sorts (nom, description, dégâts, portée, utilisations max…) et la fiche elle-même (caractéristiques, maîtrises, langues, biographie…). Ce qui change en jeu n'est pas loggé : PV, utilisations dépensées, emplacements de sort, équiper / préparer."), true));
    game.settings.register(MOD, "logActors", B(
        tl("Création / suppression de fiche"),
        tl("Logge la création et la suppression de personnages."), true));
    game.settings.register(MOD, "logScenes", B(
        tl("Création / suppression de scène (map)"),
        tl("Logge la création et la suppression de scènes."), false));
    game.settings.register(MOD, "logJournals", B(
        tl("Création / suppression de journal"),
        tl("Logge la création et la suppression de journaux."), false));
    game.settings.register(MOD, "logIncludeNpc", B(
        tl("Inclure les PNJ"),
        tl("Par défaut, seuls les PJ sont loggés. Activez pour tracer aussi les modifications faites sur les fiches PNJ."), false));
    game.settings.register(MOD, "downtimeWebhookUrl", S(
        tl("URL du Webhook Discord (changement de date)"),
        tl("Quand le GM avance la date dans Simple Calendar, envoie un message sur ce webhook. Laisser vide pour désactiver.")));
    game.settings.register(MOD, "tmWebhookUrl", S(
        tl("URL du Webhook Discord (résultats temps morts)"),
        tl("Quand le GM applique les gains de temps morts, envoie le récapitulatif sur ce webhook (salon staff/MJ). Laisser vide pour désactiver.")));

    // ============================================================
    // TEMPS MORTS — règles configurables (valeurs + formules + tables)
    // ============================================================
    game.settings.register(MOD, "tmEnabled", B(
        tl("Temps morts — Activer"),
        tl("Active tout le système de temps morts : bouton sablier sur la fiche PJ (joueur) et onglet « Temps morts » dans le Casier (GM). Nécessite un rechargement."),
        true, { requiresReload: true }));
    // -- Gain de compétence --
    game.settings.register(MOD, "tmSkillBase", N(
        tl("Gain — Base par jour"),
        tl("Valeur de base ajoutée chaque jour avant caractéristique et bonus."), 1));
    game.settings.register(MOD, "tmAddAbilityMod", B(
        tl("Gain — Ajouter le modificateur de caractéristique"),
        tl("Si activé, le modificateur de la caractéristique de la compétence est ajouté au taux journalier.")));
    game.settings.register(MOD, "tmBonusMaitrise", N(
        tl("Gain — Bonus Maîtrise"), tl("Bonus journalier si la compétence est maîtrisée."), 2));
    game.settings.register(MOD, "tmBonusExpertise", N(
        tl("Gain — Bonus Expertise"), tl("Bonus journalier si la compétence est en expertise."), 4));
    game.settings.register(MOD, "tmBonusTools", N(
        tl("Gain — Bonus Outils"), tl("Bonus journalier pour une maîtrise d'outil."), 4));
    game.settings.register(MOD, "tmRollMinDays", N(
        tl("Gain — Jours min. pour le jet d20"), tl("Nombre de jours minimum pour autoriser le jet de compétence optionnel."), 5));
    game.settings.register(MOD, "tmSkillFormula", S(
        tl("Gain — Formule (avancé)"),
        tl("Formule du taux JOURNALIER. Vide = calcul par défaut max(0, base + mod + bonus). Variables : base, mod, bonus, maitrise, expertise, tools. Fonctions : max, min, floor, ceil, round, abs, pow, sqrt.")));

    // -- Artisanat : non-magique --
    game.settings.register(MOD, "tmCraftNonMagicCostDiv", N(
        tl("Craft non-magique — Diviseur de coût"), tl("Coût par défaut = prix / ce diviseur."), 2));
    game.settings.register(MOD, "tmCraftNonMagicDaysPerGp", N(
        tl("Craft non-magique — PO par jour"), tl("Durée par défaut = arrondi sup. de prix / cette valeur."), 10));
    game.settings.register(MOD, "tmCraftNonMagicCostFormula", S(
        tl("Craft non-magique — Formule coût (avancé)"),
        "Vide = prix / div. Variables : price, div, daysPerGp. Fonctions math disponibles."));
    game.settings.register(MOD, "tmCraftNonMagicDaysFormula", S(
        tl("Craft non-magique — Formule durée (avancé)"),
        "Vide = ceil(price / daysPerGp). Variables : price, div, daysPerGp. Fonctions math disponibles."));

    // -- Artisanat : usage unique --
    game.settings.register(MOD, "tmSingleUseFactor", N(
        tl("Craft magique — Facteur usage unique"), tl("Multiplie jours et coût pour un objet magique à usage unique (0.5 = moitié)."), 0.5));

    // -- Tables (éditées via champs structurés dans la fenêtre) --
    game.settings.register(MOD, "tmScrollTable", {
        name: tl("Table des parchemins (par niveau de sort 0→9)"),
        scope: "world", config: false, type: Object, default: TM_DEFAULT_SCROLL
    });
    game.settings.register(MOD, "tmMagicTable", {
        name: tl("Table des objets magiques (par rareté)"),
        scope: "world", config: false, type: Object, default: TM_DEFAULT_MAGIC
    });
    game.settings.register(MOD, "tmRollTable", {
        name: tl("Multiplicateurs du test de compétence (par résultat)"),
        scope: "world", config: false, type: Object, default: TM_DEFAULT_ROLL
    });
    game.settings.register(MOD, "tmReliableTalent", B(
        tl("Prise en charge du Reliable Talent"),
        tl("Un personnage possédant un objet nommé « Reliable Talent » ou « Talent Fiable » ne peut pas descendre en dessous de 10 sur le d20 de son test de compétence (s'il est maîtrisé)."),
        true));
    game.settings.register(MOD, "tmCraftPack", S(
        tl("Artisanat — Compendium des objets craftables"),
        tl("Compendium d'OBJETS (ex. importé via Plutonium). À la fin d'un craft, le module y cherche l'objet par son nom et l'ajoute automatiquement à la fiche du joueur. Vide = ajout manuel comme avant.")));

    // ============================================================
    // TOOLKIT — Features génériques
    // ============================================================
    game.settings.register(MOD, "enableTokenAppearance", B(
        tl("Changement d'apparence des tokens"),
        tl("Le GM configure plusieurs images sur un token ; les joueurs cyclent via un bouton dans le HUD.")));
    game.settings.register(MOD, "enableTokenPortraitButton", B(
        tl("Bouton 'Voir le portrait' (HUD du token)"),
        tl("Ajoute un bouton dans le HUD du token qui affiche en grand l'image de la fiche.")));
    game.settings.register(MOD, "enableCasierGm", B(
        tl("Casier du MJ (barre WestMarch)"),
        tl("Bouton « Casier » de la barre WestMarch (MJ) et bouton « Présentations des MJ » (joueurs). Désactivé : les brouillons de session enregistrés « pour plus tard » restent stockés, mais ne sont plus accessibles tant que le Casier est coupé.")));
    game.settings.register(MOD, "enableExpeditionDate", B(
        tl("Bouton « Date Expédition » (ouvrir / clôturer)"),
        tl("Bouton de la barre WestMarch (MJ) qui ouvre ou clôture une expédition datée. Désactivé : plus d'expédition ouverte depuis la barre, donc l'Horloge de party ne peut plus avancer.")));
    game.settings.register(MOD, "enablePlayerListToggle", B(
        tl("Bouton pour réduire la liste des joueurs"),
        tl("Petit bouton fixe qui replie ou déplie la liste des joueurs (chaque utilisateur garde son choix).")));
    game.settings.register(MOD, "enableExportDialog", B(
        tl("Export d'acteur avec choix"),
        tl("Remplace l'option « Exporter » du clic droit sur un acteur par une fenêtre qui propose d'exporter avec ou sans les données du module. Désactivé : l'export natif de Foundry revient.")));
    game.settings.register(MOD, "enableChatTools", B(
        tl("Outils de chat du MJ"),
        tl("Boutons du MJ sous le chat : effacer les messages de sa party uniquement, importer des messages (JSON / .txt), et export du chat au choix en .txt ou JSON.")));
    game.settings.register(MOD, "enableTokenAccroche", B(
        tl("Accrocher un token à un PJ (porter / mener)"),
        tl("Bouton du HUD du token (MJ) : accroche un PNJ, un objet ou un autre PJ au token d'un PJ. Quand le joueur se déplace, le token accroché suit tout seul, sans droit à donner : posé sur le PJ (porter) ou derrière lui (mener), toujours par le chemin du PJ, donc sans traverser les murs. Nécessite un MJ connecté.")));
    game.settings.register(MOD, "enableRageSize", B(
        tl("Taille Large pendant la Rage (Voie du Géant)"),
        tl("Barbares avec 'Giant's Havoc' : le token passe en 2x2 (Large) pendant la Rage, puis revient à sa taille d'origine.")));
    game.settings.register(MOD, "enableLargeForm", B(
        tl("Taille Large — Goliath (Large Form)"),
        tl("Goliaths avec 'Large Form' : utiliser la feature bascule le token en 2x2 (Large) et inversement.")));
    game.settings.register(MOD, "enableMonkMartialArts", B(
        tl("Moine — Arts martiaux automatiques"),
        tl("Moines sans armure ni bouclier : leurs frappes à mains nues et leurs armes de moine utilisent le dé d'Arts martiaux (s'il est plus grand que celui de l'arme) et la Dextérité si elle est meilleure que la Force. Appliqué en mémoire, sans modifier les armes."),
        true, { onChange: () => import("./monk.js").then(m => m.rafraichirMoines()) }));
    game.settings.register(MOD, "enableUncannyMetabolism", B(
        tl("Moine — Métabolisme surnaturel au jet d'initiative"),
        tl("S'il reste une utilisation et qu'au moins un point de focus est dépensé : récupère tous les points de focus et rend dé d'Arts martiaux + niveau de moine PV. Ignoré si l'objet est déjà automatisé (dnd5e, Midi-QOL, premades).")));
    game.settings.register(MOD, "enablePerfectFocus", B(
        tl("Moine — Focus parfait au jet d'initiative"),
        tl("Si le Métabolisme surnaturel n'a pas servi : points de focus remontés à 4 s'il en reste 3 ou moins (Perfection de l'être 2014 : 4 ki s'il n'en reste aucun).")));
    game.settings.register(MOD, "enablePersistentRage", B(
        tl("Barbare — Rage persistante au jet d'initiative"),
        tl("S'il reste une utilisation et qu'une rage est dépensée : récupère toutes les rages (une fois par repos long).")));
    game.settings.register(MOD, "enableSuperiorInspiration", B(
        tl("Barde — Inspiration supérieure au jet d'initiative"),
        tl("Inspirations bardiques remontées à 2 (2024), ou à 1 s'il n'en reste aucune (2014).")));
    game.settings.register(MOD, "enableEvergreenWildShape", B(
        tl("Druide — Archidruide : Forme sauvage au jet d'initiative"),
        tl("Règles 2024 : s'il ne reste aucune Forme sauvage, en récupère une.")));
    game.settings.register(MOD, "enableResourcefulInspiration", B(
        tl("Humain — Ingénieux : Inspiration héroïque au repos long"),
        tl("À la fin d'un repos long, les humains avec le trait Ingénieux (Resourceful) obtiennent l'Inspiration héroïque.")));
    game.settings.register(MOD, "enableMusicianInspiration", B(
        tl("Musicien — Inspiration héroïque aux alliés après un repos"),
        tl("À la fin d'un repos court ou long, le joueur qui a le don Musicien choisit jusqu'à « bonus de maîtrise » alliés qui reçoivent l'Inspiration héroïque (écriture faite par le MJ connecté).")));
    game.settings.register(MOD, "enableHealerReroll", B(
        tl("Healer (Guérisseur) — relance des 1 sur les soins"),
        tl("Personnages qui ont le don Healer : à chaque jet de soins d'un sort (ou du Battle Medic du don), les dés qui font 1 sont relancés une fois (« r1 » ajouté à la formule). Les PV temporaires ne sont pas concernés.")));
    game.settings.register(MOD, "enableBirthday", B(
        tl("Anniversaires des PJ"),
        tl("Le jour de l'anniversaire d'un PJ, un message de fête apparaît dans le chat (avec son âge si l'année de naissance est connue). La date se règle avec le bouton gâteau de la fiche ou le clic droit sur l'acteur ; le joueur peut régler celle de son PJ. En expédition, c'est la date de la party qui compte, sinon celle du monde.")));
    game.settings.register(MOD, "birthdayNpc", B(
        tl("Anniversaires des PNJ aussi"),
        tl("Fête aussi les PNJ qui ont une date d'anniversaire (réglée par le MJ), selon le calendrier du monde."),
        false));
    game.settings.register(MOD, "enableWeaponEnchantPicker", B(
        tl("Sorts d'enchantement d'arme — choix de l'arme au lancement"),
        tl("True Strike, Magic Weapon, Shillelagh… : au lancement, plus besoin de glisser l'arme dans la carte de chat. Une seule arme équipée : elle est enchantée directement ; plusieurs : une fenêtre propose les armes acceptées (la dernière choisie est présélectionnée). Durée, concentration et fin de l'effet restent gérées par dnd5e ; la zone de dépôt du chat reste disponible.")));
    game.settings.register(MOD, "enableAlertSwap", B(
        tl("Alert (Vigilant) — échange d'initiative"),
        tl("Pour les MJ : bouton « échanger » dans le suivi de combat sur la ligne des personnages qui ont le don Alert. Il échange leur initiative avec celle d'un autre joueur du combat (non neutralisé) et l'annonce dans le chat.")));
    game.settings.register(MOD, "enableFormOfTheBeast", B(
        tl("Armes naturelles — Voie de la Bête (Form of the Beast)"),
        tl("Barbares dont une feature a l'identifiant 'form-of-the-beast' : le module crée 3 armes naturelles (Morsure, Griffes, Queue) avec jets d'attaque/dégâts, et les retire si la feature disparaît."),
        false, { requiresReload: true }));
    game.settings.register(MOD, "enablePolymorph", B(
        tl("Activer la transformation (Wild Shape / Polymorphie)"),
        tl("Deux systèmes distincts basés sur le moteur dnd5e : Wild Shape (druide) et Polymorphie (sort). Formes configurées sur la fiche (onglet Apparence), boutons dans le HUD du token.")));
    game.settings.register(MOD, "transformEnforceCr", B(
        tl("Appliquer les limites de FP"),
        tl("Vérifie le facteur de puissance (FP) de la bête : ≤ niveau/FP de la cible pour la Polymorphie ; selon le niveau de druide pour Wild Shape (1/4 niv.2, 1/2 niv.4, 1 niv.8 ; Cercle de la Lune = niveau/3). Décoché = aucune limite."),
        true));
    game.settings.register(MOD, "transformStrictCr", B(
        tl("Bloquer au-dessus de la limite de FP"),
        tl("Coché : une forme au-dessus de la limite est refusée (un MJ peut confirmer pour passer outre). Décoché : simple avertissement, la transformation est autorisée. Sans effet si « Appliquer les limites de FP » est décoché."),
        true));
    game.settings.register(MOD, "enableTgcm", B(
        tl("Protégé TGCM (token immunisé à la mort)"),
        tl("Bouton bouclier dans le HUD (GM). Un token protégé ne tombe jamais à 0 PV (reste à 1 PV).")));
    game.settings.register(MOD, "enableCompanions", B(
        tl("Compagnons évolutifs"),
        tl("Resynchronise les stats d'une créature liée (compagnon, invocation) sur le niveau de son maître, via des profils de formules. Complète l'activité « Summon » du système (ne la remplace pas)."),
        false, { requiresReload: true }));
    // Surcharges/ajouts de profils par le MJ (les profils par défaut sont livrés
    // dans companions.js ; ce réglage ne stocke que les modifications du MJ).
    game.settings.register(MOD, "companionProfiles", {
        scope: "world", config: false, type: Object, default: {}
    });
    game.settings.register(MOD, "enableFolderMove", B(
        tl("Déplacer/Dupliquer vers… (sidebar)"),
        tl("Ajoute 'Déplacer vers…' et 'Dupliquer vers…' dans le menu contextuel des scènes, acteurs, objets et journaux.")));
    game.settings.register(MOD, "enableToolAbilityFix", B(
        tl("Correction de la stat des outils (tools)"),
        tl("À la création d'un outil sans stat, corrige automatiquement vers la stat canonique dnd5e.")));
    // Le masquage de la barre de macros (joueurs/GM) est désormais géré
    // uniquement par le panneau « Interface — Masquer des éléments » (uihide.js),
    // qui couvre la hotbar avec ses deux colonnes Joueurs/GM. Les anciens
    // réglages dédiés « enableHideHotbar » ont été retirés (doublon).
    game.settings.register(MOD, "enableConnStats", {
        name: tl("Fenêtre d'infos de connexion"),
        hint: tl("Affiche au chargement, en haut au centre de l'écran, le temps de connexion, le nombre de modules actifs et la durée moyenne de connexion. Prend effet au prochain chargement."),
        scope: "world", config: false, type: Boolean, default: true, requiresReload: false
    });
    game.settings.register(MOD, "enablePlayerListCompact", {
        name: tl("Liste des joueurs compacte + recherche"),
        hint: tl("Limite la liste des joueurs à environ 4 lignes (avec défilement) et ajoute une barre de recherche pour filtrer les joueurs par nom."),
        scope: "world", config: false, type: Boolean, default: true, requiresReload: false,
        onChange: () => ui.players?.render()
    });
    // Historique local des temps de connexion (par client) — sert au calcul
    // de la moyenne. Non affiché dans la configuration.
    game.settings.register(MOD, "connStatsHistory", {
        scope: "client", config: false, type: Array, default: []
    });
    // Temps total cumulé passé connecté au serveur (ms), par client.
    game.settings.register(MOD, "connStatsTotalMs", {
        scope: "client", config: false, type: Number, default: 0
    });
    // ---- Échange entre joueurs ----
    game.settings.register(MOD, "enableTrade", B(
        tl("Échange entre joueurs"),
        tl("Ajoute un bouton « Échanger » dans la liste des joueurs : fenêtre d'échange synchronisée (objets + monnaies), arbitrée par le MJ. Interdit en party sans expédition ; en expédition, uniquement entre membres de la même expédition ; libre en ville."),
        true));
    // ---- Cartes de chat ----
    game.settings.register(MOD, "enableChatCards", {
        name: tl("Activer l'habillage des cartes de chat"),
        hint: tl("Interrupteur général. Les options ci-dessous n'ont d'effet que si celui-ci est activé."),
        scope: "world", config: false, type: Boolean, default: true,
        onChange: () => applyChatCardPrefs()
    });
    game.settings.register(MOD, "chatCardsTheme", {
        name: tl("Thème (couleurs & bordures)"),
        hint: tl("Reteinte les cartes (fond crème par défaut, bordures dorées, titres, pastilles). Chaque joueur choisit sa couleur dans « Accessibilité »."),
        scope: "world", config: false, type: Boolean, default: true,
        onChange: () => applyChatCardPrefs()
    });
    game.settings.register(MOD, "chatCardsBigButtons", {
        name: tl("Gros boutons Attaque / Dégâts"),
        hint: tl("Boutons de jet pleine largeur et plus hauts, plus faciles à cliquer."),
        scope: "world", config: false, type: Boolean, default: true,
        onChange: () => applyChatCardPrefs()
    });
    game.settings.register(MOD, "chatCardsExpandDice", {
        name: tl("Déplier les jets de dés par défaut"),
        hint: tl("Affiche d'office le détail du jet (dés individuels, bonus et provenance)."),
        scope: "world", config: false, type: Boolean, default: true
    });
    game.settings.register(MOD, "chatCardsFoldDescription", {
        name: tl("Replier la description par défaut"),
        hint: tl("La description de l'objet/sort est repliée à l'ouverture de la carte ; un clic sur l'en-tête la déplie (mécanisme natif dnd5e). Décoché : la description est affichée d'emblée. Pilote le réglage dnd5e « Auto Collapse Item Cards » de chaque client."),
        scope: "world", config: false, type: Boolean, default: true,
        onChange: () => applyChatCardPrefs()
    });
    // Couleur de fond des cartes de chat — PAR JOUEUR (défaut : blanc crème).
    game.settings.register(MOD, "chatCardColor", {
        scope: "user", config: false, type: String, default: "#f4ecd8",
        onChange: () => applyChatCardPrefs()
    });
    game.settings.register(MOD, "enableTemplateSnap", B(
        tl("Snap des templates AoE au dixième de pied"),
        tl("Pendant le placement d'un template, la taille s'incrémente par paliers de 0,1 ft. Nécessite lib-wrapper pour le snap live.")));
    game.settings.register(MOD, "enableFollowTemplates", B(
        tl("Zones (gabarits / régions) qui suivent le token"),
        tl("Si tu poses une zone AoE en démarrant SUR un token, elle s'y attache et suit ses déplacements (recentrée sur lui ; rotation non suivie). Gère les gabarits de mesure ET les Régions (Foundry v14). La zone est supprimée si le token l'est. Le suivi n'agit que si un MJ est connecté."),
        false));
    game.settings.register(MOD, "enableMejShopFix", B(
        tl("Correctifs boutiques Monk's Enhanced Journal"),
        tl("Bouton 'Groupe uniquement' dans 'Show to Players' de MEJ, et fix des objets cachés visibles côté joueur.")));
    game.settings.register(MOD, "enableMejRestock", B(
        tl("Réapprovisionnement automatique des boutiques"),
        tl("Active/désactive le système de réapprovisionnement des boutiques MEJ.")));
    game.settings.register(MOD, "shopRestockDays", N(
        tl("Réapprovisionnement — Délai par défaut (jours)"),
        tl("Délai utilisé si aucune valeur par rareté n'est définie. 0 = pas de fallback."), 7));
    game.settings.register(MOD, "shopRestockDaysCommon", N(
        tl("Réapprovisionnement — Commun (jours)"), tl("Délai pour la rareté Commun. 0 = désactivé."), 0));
    game.settings.register(MOD, "shopRestockDaysUncommon", N(
        tl("Réapprovisionnement — Peu commun (jours)"), tl("Délai pour la rareté Peu commun. 0 = désactivé."), 0));
    game.settings.register(MOD, "shopRestockDaysRare", N(
        tl("Réapprovisionnement — Rare (jours)"), tl("Délai pour la rareté Rare. 0 = désactivé."), 0));
    game.settings.register(MOD, "shopRestockDaysVeryRare", N(
        tl("Réapprovisionnement — Très rare (jours)"), tl("Délai pour la rareté Très rare. 0 = désactivé."), 0));
    game.settings.register(MOD, "shopRestockDaysLegendary", N(
        tl("Réapprovisionnement — Légendaire (jours)"), tl("Délai pour la rareté Légendaire. 0 = désactivé."), 0));

    // ============================================================
    // RELATIONS (clés préfixées relations*)
    // ============================================================
    game.settings.register(MOD, "relationsEnabled", B(
        tl("Relations — Activer"),
        tl("Ajoute un onglet 'Relations' sur les fiches PJ et détecte automatiquement les rencontres sur les scènes.")));
    game.settings.register(MOD, "relationsAnonymization", B(
        tl("Relations — Anonymisation"),
        tl("Ajoute les boutons 'Révéler'/'Masquer' dans l'en-tête des fiches (GM). Contrôle l'affichage 'Inconnu'.")));
    game.settings.register(MOD, "relationsFolderPJ", S(
        tl("Relations — Dossier des PJ"),
        tl("Dossier acteur des joueurs. Leur présence sur une scène déclenche la détection de rencontres.")));
    game.settings.register(MOD, "relationsFolderPNJ", S(
        tl("Relations — Dossier des PNJ"),
        tl("Dossier acteur des PNJ récurrents (alliés, marchands, figures importantes).")));
    game.settings.register(MOD, "relationsPackPNJ", S(
        tl("Relations — Compendium des PNJ"),
        tl("Compendium d'acteurs PNJ. Ses personnages sont proposés dans le sélecteur de relations (groupe PNJ).")));
    game.settings.register(MOD, "relationsPackCemetery", S(
        tl("Relations — Compendium cimetière des joueurs"),
        tl("Compendium des PJ décédés. Ses personnages sont proposés dans le sélecteur de relations (groupe Joueurs).")));

    // ============================================================
    // BESTIAIRE (clés préfixées bestiary*)
    // ============================================================
    game.settings.register(MOD, "bestiaryEnabled", B(
        tl("Bestiaire — Activer"),
        tl("Active la détection automatique des créatures rencontrées sur les scènes et l'onglet Bestiaire.")));
    game.settings.register(MOD, "relationsLastSeen", B(
        tl("Relations — Date de dernière rencontre"),
        tl("Date (calendrier du monde, sinon date réelle) à laquelle le personnage a vu ce PJ / PNJ pour la dernière fois, mise à jour automatiquement.")));
    game.settings.register(MOD, "bestiaryAnonymization", B(
        tl("Bestiaire — Anonymisation"),
        tl("Boutons 'Révéler'/'Masquer' dans l'en-tête des fiches (GM). Utilisé si Relations est désactivé.")));
    game.settings.register(MOD, "bestiaryLastPosition", B(
        tl("Bestiaire — Dernière position"),
        tl("Champ « Dernière position » sur chaque créature : rempli avec la scène où le personnage l'a vue en dernier, mis à jour automatiquement (non modifiable).")));
    game.settings.register(MOD, "bestiaryLastSeen", B(
        tl("Bestiaire — Date de dernière rencontre"),
        tl("Date (calendrier du monde, sinon date réelle) à laquelle le personnage a vu la créature pour la dernière fois, mise à jour automatiquement.")));
    game.settings.register(MOD, "bestiaryDamageTags", B(
        tl("Bestiaire — Faiblesses, résistances, immunités"),
        tl("Une étiquette par type de dégâts sur chaque créature. Chaque clic change son état : neutre → faiblesse → résistance → immunité → neutre. Le joueur note ce qu'il a découvert.")));
    game.settings.register(MOD, "bestiaryArmorClass", B(
        tl("Bestiaire — Classe d'armure estimée"),
        tl("Liste « CA » sur chaque créature (très faible → extrême) que le joueur remplit selon ce qu'il a constaté en combat.")));
    game.settings.register(MOD, "bestiaryFolderPJ", S(
        tl("Bestiaire — Dossier des PJ"),
        tl("Dossier acteur des joueurs. Chaque joueur voit les créatures rencontrées par son personnage.")));
    game.settings.register(MOD, "bestiaryPackCreatures", S(
        tl("Bestiaire — Compendium des créatures (ID)"),
        tl("ID du compendium des monstres/créatures (ex : world.creatures). La détection automatique et l'ajout manuel lisent uniquement depuis ce compendium."),
        "world.creature"));

    // ============================================================
    // CARNET & EXPÉDITIONS (clés préfixées carnet*)
    // ============================================================
    game.settings.register(MOD, "carnetEnabled", B(
        tl("Carnet & Expéditions — Activer"),
        tl("Ajoute les onglets Carnet et Expéditions sur les fiches PJ. Nécessite un rechargement."),
        true, { requiresReload: true }));
    game.settings.register(MOD, "enablePcStatus", B(
        tl("Statut de disponibilité des PJ"),
        tl("Affiche à droite de chaque personnage, dans le répertoire des Acteurs, un badge « Disponible » ou « En expédition ». Le statut est déduit automatiquement des expéditions : un PJ avec une expédition ouverte (date de début sans date de fin) est « En expédition ». Modifiable sans rechargement."),
        true, { onChange: () => ui.actors?.render() }));

    // ============================================================
    // CARTE DES EXPÉDITIONS (clés inchangées)
    // ============================================================
    game.settings.register(MOD, "enableExpeditionMap", B(
        tl("Carte des expéditions"),
        tl("Synchronise la permission Owner de l'acteur Groupe avec les joueurs membres, pour la vision/brouillard sur la carte du monde.")));
    game.settings.register(MOD, "expeditionMapSceneId", S(
        tl("Carte des expéditions — Scène principale"),
        tl("Scène sur laquelle le brouillard de guerre est suivi par personnage plutôt que par compte joueur.")));
    // Scènes SUPPLÉMENTAIRES de carte (ex. archipel : plusieurs îles). Chaque
    // scène garde son propre brouillard (exploration indépendante par scène).
    game.settings.register(MOD, "expeditionMapSceneIds", {
        scope: "world", config: false, type: Array, default: [],
        name: tl("Carte des expéditions — Scènes supplémentaires"),
        hint: tl("Sélectionnez d'autres scènes à traiter comme cartes d'expédition (Ctrl/Cmd-clic pour en choisir plusieurs). Chacune a son propre brouillard, indépendant des autres et de la scène principale. Idéal pour un archipel (une scène par île).")
    });
    game.settings.register(MOD, "expeditionMapTemplateFolder", S(
        tl("Carte des expéditions — Dossier du token modèle"),
        tl("Dossier d'acteurs où ranger l'acteur Groupe modèle « Token à copier et rennomer ». Vide : dossier « Tokens de groupe » (or orangé) créé automatiquement à la racine.")));
    game.settings.register(MOD, "expeditionRevealRadius", N(
        tl("Carte des expéditions — Rayon de révélation (en cases)"),
        tl("Nombre de cases (hex) révélées autour du token de groupe lors de son déplacement. 0 = seulement la case du token, 1 = la case + ses voisines, etc."),
        1));
    // Zones toujours éclairées (villes, lieux connus de tous) — peintes par le MJ.
    // Liste de clés de case "i.j". Non affiché (édité via l'outil sur la carte).
    game.settings.register(MOD, "expeditionRevealedZones", {
        scope: "world", config: false, type: Object, default: {}
    });

    // ============================================================
    // MISE EN SCÈNE — CUES AUDIO (clés sceneCues*)
    // ============================================================
    game.settings.register(MOD, "enableSceneCues", B(
        tl("Mise en scène — Cues audio"),
        tl("Attache à un token un « cue » audio (fichier, seconde de départ, volume, fondu, boucle) via un bouton dans son HUD. Le son se déclenche pour tous les joueurs quand le token perd son invisibilité GM, ou manuellement. Diffusion en local sur chaque client (faible latence), avec préchargement au chargement de la scène. Outil réservé au MJ.")));
    game.settings.register(MOD, "sceneCuesDefaultVolume", N(
        tl("Cues audio — Volume par défaut"),
        tl("Volume initial (0 à 1) proposé pour un nouveau cue."),
        0.8));
    // Stockage central des cues (au niveau du monde) : survivent à la
    // suppression des tokens auxquels ils sont liés. Édités via le gestionnaire.
    game.settings.register(MOD, "sceneCuesList", {
        scope: "world", config: false, type: Array, default: []
    });

    // ============================================================
    // MIDI RANGE FIX (clés préfixées rangeFix*)
    // ============================================================
    game.settings.register(MOD, "rangeFixEnabled", B(
        tl("Midi Range Fix — Activer"),
        tl("Corrige le calcul de portée midi-qol pour les tokens Large+. Nécessite un rechargement. Sans midi-qol, sans effet."),
        true, { requiresReload: true }));
    game.settings.register(MOD, "rangeAdjust", N(
        tl("Midi Range Fix — Marge depuis le bord (ft)"),
        tl("Marge soustraite à la portée pour le calcul bord→bord. 2.5 = défaut D&D 5e (demi-case). Ne pas dépasser la portée de l'arme."),
        2.5));

    // ============================================================
    // TUTORIEL
    // ============================================================
    game.settings.register(MOD, "tutoEnabled", B(
        tl("Tutoriel — Activer"),
        tl("Active le bouton tutoriel ('?') dans la barre WestMarch et la fenêtre de bienvenue. Nécessite un rechargement."),
        true, { requiresReload: true }));
    // Fenêtre de bienvenue : TOUS les textes sont personnalisables par le MJ.
    // Une fois enregistrés (au 1er chargement par le MJ, voir welcome.js →
    // figerTextesBienvenue), ils ne dépendent plus de la langue du module.
    game.settings.register(MOD, "welcomeWindowTitle", S(
        tl("Bienvenue — Titre de la fenêtre"),
        tl("Texte de la barre de titre de la fenêtre d'accueil. Vide : « Bienvenue »."),
        tl("Bienvenue")));
    game.settings.register(MOD, "serverName", S(
        tl("Bienvenue — Titre principal"),
        tl("Grand titre affiché en haut de la fenêtre d'accueil des joueurs (souvent le nom du serveur)."),
        tl("Bienvenue sur le serveur !")));
    game.settings.register(MOD, "welcomeText", S(
        tl("Bienvenue — Texte"),
        tl("Texte d'accueil. Retour à la ligne : touche Entrée. Mise en gras : **mot**. Vide : pas de texte."),
        tl("Des fonctionnalités spéciales sont disponibles sur ce serveur.\nOn commence par **l'essentiel** (court), puis un **menu** vous laisse explorer le reste à votre rythme.")));
    game.settings.register(MOD, "welcomeWarning", S(
        tl("Bienvenue — Avertissement"),
        tl("Ligne d'avertissement (orange) sous le texte. Mêmes règles : Entrée pour aller à la ligne, **mot** pour le gras. Vide : pas d'avertissement."),
        tl("Fermez toutes les fiches et fenêtres ouvertes avant de commencer, pour le bon déroulement du guide.")));
    game.settings.register(MOD, "welcomeStartLabel", S(
        tl("Bienvenue — Texte du bouton"),
        tl("Libellé du bouton qui lance le guide. Vide : « Commencer »."),
        tl("Commencer (l'essentiel puis le menu)")));
    // Suivi interne : la fiche démo du tutoriel a-t-elle déjà été créée ?
    // (évite de la recréer si le GM la supprime volontairement).
    game.settings.register(MOD, "tutorialActorCreated", {
        scope: "world", config: false, type: Boolean, default: false, requiresReload: false
    });
    // Version de la fiche démo réellement créée avec succès. Ne vaut DEMO_VERSION
    // qu'après une création confirmée : si la création échoue, ce compteur reste
    // en arrière et la création est retentée au prochain chargement. Un bump de
    // DEMO_VERSION force aussi la recréation (nouveau contenu).
    game.settings.register(MOD, "tutorialActorVersion", {
        scope: "world", config: false, type: Number, default: 0, requiresReload: false
    });
    for (const { key, label } of TUTO_TOGGLES) {
        game.settings.register(MOD, key, B(
            `Tutoriel — ${label}`,
            tl("Inclure les étapes de tutoriel pour cette fonctionnalité.")));
    }
    game.settings.register(MOD, "showWelcome", B(
        tl("Tutoriel — Afficher la fenêtre de bienvenue au login"),
        tl("Si activé, la fenêtre d'accueil s'affiche à chaque connexion (sauf « Ne plus afficher »)."),
        false));
    game.settings.register(MOD, "hideWelcome", {
        scope: "user", config: false, type: Boolean, default: false
    });

    // ============================================================
    // RÉCOLTE (HARVEST)
    // ============================================================
    game.settings.register(MOD, "enableHarvest", B(
        tl("Système de récolte"),
        tl("Permet de récolter (dépecer) une créature morte ciblée pour en tirer des matériaux via une RollTable que vous associez à la créature. Le module ne fournit pas de tables : il utilise les vôtres."),
        false, { requiresReload: true }));
    game.settings.register(MOD, "harvestDcBase", N(
        tl("Récolte — DC de base"), tl("Difficulté de base du jet de récolte, avant ajout selon le CR."), 10));
    game.settings.register(MOD, "harvestDcPerCr", N(
        tl("Récolte — DC ajouté par CR"), tl("Ajout à la DC par point de facteur de puissance (CR) de la créature. Ex. 0.5 = +1 tous les 2 CR."), 0.5));
    game.settings.register(MOD, "harvestBaseDraws", N(
        tl("Récolte — Tirages de base"), tl("Nombre de tirages sur la RollTable en cas de réussite normale. +1 par tranche de 5 au-dessus de la DC ; échec = 1 tirage. Une dépouille « abîmée » réduit ce nombre de moitié."), 2));
    game.settings.register(MOD, "harvestBloodImage", S(
        tl("Récolte — Image de la tache de sang"),
        tl("Chemin d'image posée à la place du token quand la dépouille est entièrement récoltée. Laisser vide pour utiliser au hasard une des taches de sang fournies avec le module.")));
    // Associations créature → RollTable. { byType: {beast: id…}, byName: {"Loup": id…} }
    game.settings.register(MOD, "harvestTables", {
        scope: "world", config: false, type: Object, default: { byType: {}, byName: {} }
    });

    // ---- Suivi de la migration des données des anciens modules ----
    // 0 = jamais migré. Incrémenté par migration.js une fois la reprise faite.
    game.settings.register(MOD, "migrationVersion", {
        scope: "world", config: false, type: Number, default: 0
    });

    // ---- Kill-switch de désactivation (piloté depuis la fenêtre « À propos »).
    // true = module désactivé (voir le gate dans index.js). Réglage monde :
    // seul le MJ peut l'écrire, même si le champ code est visible par tous.
    game.settings.register(MOD, "moduleDeactivated", {
        scope: "world", config: false, type: Boolean, default: false, requiresReload: false,
        name: tl("Module désactivé"),
        hint: tl("Coché = toutes les fonctions du module sont désactivées sur ce serveur (le module reste installé, la fenêtre « À propos » reste accessible). Décochez pour réactiver. Se pilote aussi par code depuis « À propos ». Le changement recharge automatiquement les clients."),
        onChange: () => foundry.utils.debouncedReload()
    });

    // ---- Masquage d'éléments d'interface (par rôle). Réglage monde : le MJ
    // décide ce qui est caché pour les Joueurs et pour les GM ; chaque client
    // applique sa colonne. Édité via le panneau « Interface — Masquer ».
    game.settings.register(MOD, "hiddenUi", {
        scope: "world", config: false, type: Object, default: { players: [], gm: [] },
        onChange: () => { try { applyUiHiding(); } catch (e) {} }
    });

    // ============================================================
    // MENUS PAR CATÉGORIE (boutons "Configurer" dans la config du module)
    // Visibles UNIQUEMENT si le module est activé (bon code saisi). Tant que le
    // code n'est pas entré, aucun réglage n'est accessible — la seule entrée est
    // la fenêtre de code au démarrage (voir index.js).
    // ============================================================
    // Fenêtre « À propos » — TOUJOURS enregistrée et visible par TOUS (joueurs
    // inclus), même module non activé/désactivé : c'est la seule entrée publique,
    // et elle contient le champ code (activation manquante → réactivation possible).
    // ÉLÉMENTS DE BASE DU MODULE : chacun a son interrupteur (activés par défaut).
    game.settings.register(MOD, "enableDiagnosticMenu", B(
        tl("Menu « Diagnostic »"),
        tl("Bouton « Diagnostic » des réglages du module (versions, licence, modules nécessaires, problèmes récents). Utile pour ouvrir un ticket de support."),
        true, { requiresReload: true }));
    game.settings.register(MOD, "enableAdminMenu", B(
        tl("Menu « Administration du module »"),
        tl("Fenêtre des réglages pour le mot de passe admin, la préparation de l'ouverture du serveur et la réinitialisation du brouillard. Désactivé : ces actions ne sont plus accessibles."),
        true, { requiresReload: true }));
    game.settings.register(MOD, "enableSiteMessage", B(
        tl("Message du site après une mise à jour"),
        tl("Message privé aux MJ dans le chat, une fois par version, avec le lien de la page du module sur le site d'Althéia.")));
    game.settings.register(MOD, "enableLegacyMigration", B(
        tl("Reprise des anciennes données"),
        tl("Au chargement d'un MJ, recopie une seule fois les données et réglages des anciens modules séparés vers ce module. Inutile sur un monde neuf.")));
    game.settings.register(MOD, "enableOwnershipScroll", B(
        tl("Fenêtre des droits défilante"),
        tl("La fenêtre des droits d'un document (Configurer les droits) défile quand la liste des joueurs est trop longue.")));

    registerAboutMenu();   // toujours : c'est là qu'on saisit le code de licence
    if (game.settings.get(MOD, "enableDiagnosticMenu")) registerDiagnosticMenu();

    // Les menus MJ (restricted:true, dont « À propos & protection ») restent
    // enregistrés dès que le CODE D'ACTIVATION est valide — même si le module est
    // désactivé — pour que le MJ garde l'accès à ses réglages et puisse réactiver.
    // Les joueurs ne voient de toute façon que la fenêtre publique « À propos ».
    const activated = licenceValide();
    if (activated) {
        registerConfigHub();   // TOUT passe par le panneau de configuration regroupé
    }
}

// ============================================================
// Fenêtre « À propos » (publique) + kill-switch par code
// ============================================================
function registerAboutMenu() {
    try {
        game.settings.registerMenu(MOD, "menu-about", {
            name:  tl("À propos"),
            label: tl("Ouvrir"),
            hint:  tl("Informations sur le module, auteur et droits."),
            icon:  "fas fa-circle-info",
            type:  makeLauncher({ firstKey: "about", title: tl("À propos"), icon: "fa-circle-info", open: () => openAboutDialog() }),
            restricted: false   // visible par tout le monde (joueurs inclus)
        });
    } catch (e) {
        journal.critique(tl("[{0}] registerMenu « À propos » échec :", MOD), e);
    }
}

async function openAboutDialog() {
    const mod     = game.modules.get(MOD);
    const version = mod?.version ?? "?";
    const author  = tl("Soruta (Discord : s0ruta)");
    const desc    = mod?.description
        ? mod.description
        : tl("Module unifié West March pour Foundry VTT (dnd5e).");
    const deactivated = game.settings.get(MOD, "moduleDeactivated") === true;

    const content = `
        <div style="display:flex;flex-direction:column;gap:10px;padding:2px 0;">
            <div style="display:flex;align-items:center;gap:10px;">
                <i class="fa-solid fa-hammer" style="font-size:22px;color:#c9a227;"></i>
                <div>
                    <div style="font-weight:700;font-size:15px;">Soruta — Completed Westmarch</div>
                    <div style="font-size:12px;opacity:.75;">${tl("Version {0}", version)}</div>
                </div>
            </div>
            <div style="font-size:12px;line-height:1.5;opacity:.9;">${desc}</div>
            <hr style="border:none;border-top:1px solid rgba(255,255,255,.12);margin:2px 0;">
            <div style="font-size:12px;line-height:1.6;">
                <div>${tl("<strong>Auteur :</strong> {0}", author)}</div>
                <div>${tl("<strong>Droits :</strong> © 2026 Soruta — Tous droits réservés.")}</div>
                <div>${tl("<strong>Site :</strong> <a href=\"{0}\" target=\"_blank\" rel=\"noopener\">altheia.eu — Nos modules</a>", URL_PAGE_MODULE)}
                    <span style="opacity:.75;">${tl("(nouveautés, mises à jour, licence)")}</span></div>
                <div style="opacity:.75;margin-top:4px;">
                    ${tl("Ce module et son contenu (code, textes, ressources) sont une œuvre de\n                    l'esprit protégée par le droit d'auteur. Toute redistribution, revente,\n                    modification ou réutilisation sans autorisation écrite de l'auteur est interdite.")}
                </div>
                <details style="margin-top:6px;">
                    <summary style="cursor:pointer;color:#c9a227;font-weight:600;">
                        ${tl("Cadre légal &amp; sanctions encourues")}
                    </summary>
                    <div style="font-size:11px;line-height:1.55;opacity:.9;margin-top:4px;
                                max-height:180px;overflow-y:auto;padding-right:4px;">
                        <p style="margin:0 0 5px;">
                            ${tl("France — <em>Code de la propriété intellectuelle</em> (CPI) :")}
                        </p>
                        <ul style="margin:0 0 5px;padding-left:16px;">
                            <li>${tl("<strong>Art. L122-4</strong> — Toute reproduction ou représentation,\n                                intégrale ou partielle, faite sans le consentement de l'auteur\n                                (y compris adaptation, traduction ou transformation) est illicite.")}</li>
                            <li>${tl("<strong>Art. L335-3</strong> — La reproduction, la représentation ou\n                                la diffusion d'une œuvre en violation des droits de l'auteur\n                                constitue un délit de contrefaçon ; cela vise aussi la violation\n                                des droits sur un logiciel (art. L122-6).")}</li>
                            <li>${tl("<strong>Art. L335-2</strong> — La contrefaçon est punie de\n                                <strong>3 ans d'emprisonnement et 300 000 € d'amende</strong> ;\n                                portés à <strong>7 ans et 750 000 €</strong> lorsqu'elle est\n                                commise en bande organisée.")}</li>
                            <li>${tl("<strong>Art. L331-1-3</strong> — S'y ajoutent des\n                                <strong>dommages-intérêts</strong> réparant le préjudice subi\n                                (manque à gagner, bénéfices réalisés par le contrefacteur,\n                                préjudice moral).")}</li>
                        </ul>
                        <p style="margin:0;opacity:.7;font-style:italic;">
                            ${tl("Mention informative — le droit applicable peut varier selon le pays\n                            et évoluer dans le temps.")}
                        </p>
                    </div>
                </details>
            </div>
            <hr style="border:none;border-top:1px solid rgba(255,255,255,.12);margin:2px 0;">
            <div style="font-size:12px;opacity:.8;">${etatLicence()}</div>
            <label style="font-size:12px;display:block;">
                <span style="opacity:.7;">${tl("Clé de licence ou code")}</span>
                <input type="password" name="scwm-about-code" autocomplete="off"
                       placeholder="${tl("Code…")}" style="width:100%;box-sizing:border-box;margin-top:3px;">
            </label>
            <div style="font-size:11px;opacity:.6;">
                ${deactivated ? tl("⚠️ Le module est actuellement désactivé.") : ""}
            </div>
        </div>`;

    await foundry.applications.api.DialogV2.wait({
        window:      { title: tl("À propos — Soruta Completed Westmarch"), icon: "fas fa-circle-info" },
        position:    { width: 460 },
        rejectClose: false,
        content,
        buttons: [
            {
                action: "validate", label: tl("Valider"), icon: '<i class="fa-solid fa-check"></i>', default: true,
                callback: async (ev, btn) => {
                    const input = btn.form?.elements?.["scwm-about-code"];
                    const code  = (input?.value ?? "").trim();
                    if (input) input.value = "";   // efface la saisie (aucun point ne subsiste)
                    if (!code) return;

                    // 1) CLÉ DE LICENCE (ALT-…) → active ce monde auprès du serveur de
                    //    licence (et lève toute désactivation). Réservé au MJ.
                    if (/^alt-/i.test(code)) {
                        if (!game.user?.isGM) {
                            ui.notifications?.warn(tl("L'activation est réservée au MJ."));
                            return;
                        }
                        const res = await activerLicence(code);
                        if (!res.ok) {
                            ui.notifications?.error(messageLicence(res.erreur));
                            return;
                        }
                        if (game.settings.get(MOD, "moduleDeactivated") === true) {
                            await game.settings.set(MOD, "moduleDeactivated", false);
                        }
                        ui.notifications?.info(tl("Licence activée."));
                        foundry.utils.debouncedReload();
                        return;
                    }

                    // 2) Code de DÉSACTIVATION → bascule le kill-switch.
                    if (!DEACTIVATION_CODE || code !== DEACTIVATION_CODE) {
                        ui.notifications?.error(tl("Code invalide."));
                        return;
                    }
                    if (game.user?.isGM) {
                        // MJ : écriture directe du réglage monde.
                        const next = !(game.settings.get(MOD, "moduleDeactivated") === true);
                        await game.settings.set(MOD, "moduleDeactivated", next);
                        ui.notifications?.info(next ? tl("Module désactivé.") : tl("Module réactivé."));
                        foundry.utils.debouncedReload();
                        return;
                    }
                    // Joueur : relais vers un MJ connecté (les joueurs ne peuvent pas
                    // écrire un réglage monde). Nécessite qu'un MJ soit en ligne.
                    const gm = game.users.find(u => u.isGM && u.active);
                    if (!gm) {
                        ui.notifications?.warn(tl("Aucun MJ connecté pour appliquer le changement."));
                        return;
                    }
                    try {
                        const res = await gm.query("completed-westmarch.toggleDeactivation", { code });
                        if (res === "off" || res === "on") {
                            ui.notifications?.info(res === "off" ? tl("Module désactivé.") : tl("Module réactivé."));
                            foundry.utils.debouncedReload();
                        } else {
                            ui.notifications?.error(tl("Le MJ n'a pas pu appliquer le changement."));
                        }
                    } catch (e) {
                        ui.notifications?.error(tl("Échec de la demande au MJ."));
                    }
                }
            },
            { action: "close", label: tl("Fermer"), icon: '<i class="fa-solid fa-xmark"></i>', callback: () => {} }
        ]
    });
}

// Cases à cocher "Activé" injectées à côté du nom de chaque catégorie qui
// possède un interrupteur maître (Party, Relations, Bestiaire, Carnet, Carte,
// Midi). Permet d'activer/désactiver la fonctionnalité sans ouvrir la fenêtre.
const CAT_RELOAD = new Set(["relationsEnabled", "bestiaryEnabled", "carnetEnabled", "rangeFixEnabled", "tmEnabled", "tutoEnabled"]);

function registerCategoryToggles() {
    Hooks.on("renderSettingsConfig", (app, html) => {
        const root = html instanceof HTMLElement ? html : html?.[0];
        if (!root) return;

        for (const cat of CATEGORIES) {
            if (!cat.master) continue;

            // Trouver la ligne du menu : par data-key, sinon par titre (robuste v13/v14).
            let group = root.querySelector(`[data-key="${MOD}.menu-${cat.firstKey}"]`)?.closest(".form-group");
            if (!group) {
                for (const g of root.querySelectorAll(".form-group")) {
                    const lbl = g.querySelector("label");
                    if (lbl && lbl.textContent.trim() === cat.title) { group = g; break; }
                }
            }
            if (!group || group.querySelector(".scwm-cat-toggle")) continue;

            const on = !!game.settings.get(MOD, cat.master);
            const wrap = document.createElement("label");
            wrap.className = "scwm-cat-toggle";
            wrap.style.cssText = "display:inline-flex;align-items:center;gap:5px;margin-left:10px;cursor:pointer;font-size:11px;font-weight:600;color:#8fd19e;vertical-align:middle;";
            wrap.innerHTML = `<input type="checkbox" ${on ? "checked" : ""} style="width:15px;height:15px;margin:0;"> ${tl("Activé")}`;

            const cb = wrap.querySelector("input");
            cb.addEventListener("change", async () => {
                await game.settings.set(MOD, cat.master, cb.checked);
                wrap.style.color = cb.checked ? "#8fd19e" : "#e58f8f";
                if (CAT_RELOAD.has(cat.master)) {
                    const ok = await foundry.applications.api.DialogV2.confirm({
                        window:  { title: tl("Rechargement requis") },
                        content: `<p>${tl("Ce changement nécessite un rechargement pour s'appliquer pleinement. Recharger maintenant ?")}</p>`
                    });
                    if (ok) window.location.reload();
                }
            });
            if (!on) wrap.style.color = "#e58f8f";

            const nameLabel = group.querySelector("label");
            (nameLabel ?? group).appendChild(wrap);
        }
    });
}

// ============================================================
// Catégories (ordre = ordre d'enregistrement des settings).
// firstKey = clé devant laquelle insérer l'en-tête de catégorie.
// ============================================================
// ============================================================
// Arborescence des modifications ciblées (par classe / espèce / …).
// Chaque FEUILLE porte une clé de réglage booléen (key). Un nœud SANS key mais
// AVEC children est une branche dépliable. Extensible : ajoute des entrées.
// ============================================================
const TWEAK_TREE = {
    "Classes": { icon: "fa-hat-wizard", children: {
        "Barbare": { children: {
            "Voie du Géant": { children: {
                "Taille Large pendant la Rage": { key: "enableRageSize" }
            } },
            "Voie de la Bête": { children: {
                "Form of the Beast (armes naturelles)": { key: "enableFormOfTheBeast" }
            } },
            "Rage persistante au jet d'initiative": { key: "enablePersistentRage" }
        } },
        "Moine": { children: {
            "Arts martiaux : dé et Dextérité automatiques": { key: "enableMonkMartialArts" },
            "Métabolisme surnaturel au jet d'initiative": { key: "enableUncannyMetabolism" },
            "Focus parfait au jet d'initiative": { key: "enablePerfectFocus" }
        } },
        "Barde": { children: {
            "Inspiration supérieure au jet d'initiative": { key: "enableSuperiorInspiration" }
        } },
        "Druide": { children: {
            "Archidruide : Forme sauvage au jet d'initiative": { key: "enableEvergreenWildShape" }
        } }
    } },
    "Espèces": { icon: "fa-dna", children: {
        "Goliath": { children: {
            "Large Form (taille Large)": { key: "enableLargeForm" }
        } },
        "Humain": { children: {
            "Ingénieux : Inspiration héroïque au repos long": { key: "enableResourcefulInspiration" }
        } }
    } },
    "Sorts":       { icon: "fa-wand-magic-sparkles", children: {
        "Enchantements d'arme (True Strike, Magic Weapon…)": { children: {
            "Choisir l'arme au lancement, sans glisser-déposer": { key: "enableWeaponEnchantPicker" }
        } }
    } },
    "Features":    { icon: "fa-star",                children: {
        "Alert (Vigilant)": { children: {
            "Bouton d'échange d'initiative (suivi de combat, MJ)": { key: "enableAlertSwap" }
        } },
        "Musician (Musicien)": { children: {
            "Inspiration héroïque aux alliés après un repos": { key: "enableMusicianInspiration" }
        } },
        "Healer (Guérisseur)": { children: {
            "Relance des 1 sur les soins (sorts, Battle Medic)": { key: "enableHealerReroll" }
        } }
    } },
    "Backgrounds": { icon: "fa-scroll",              children: {} },
};

// Toutes les clés de réglage (feuilles) de l'arbre, à plat.
function collectTweakKeys(nodes = TWEAK_TREE) {
    const out = [];
    for (const node of Object.values(nodes)) {
        if (node.key) out.push(node.key);
        if (node.children) out.push(...collectTweakKeys(node.children));
    }
    return out;
}

// Rendu HTML récursif de l'arbre (details/summary dépliables, cases pour feuilles).
function renderTweakTree(nodes, depth = 0) {
    return Object.entries(nodes).map(([label, node]) => {
        const pad = depth * 16;
        if (node.key) {
            const on = !!game.settings.get(MOD, node.key);
            return `<label class="scwm-set" data-key="${node.key}" style="display:flex;align-items:center;gap:8px;padding:3px 0 3px ${pad}px;font-weight:400;cursor:pointer;">
                <input type="checkbox" name="${node.key}" ${on ? "checked" : ""} style="width:16px;height:16px;flex-shrink:0;">
                <span>${tl(label)}</span></label>`;
        }
        const inner = renderTweakTree(node.children ?? {}, depth + 1);
        const body = inner.trim() ? inner
            : `<p style="margin:2px 0 4px ${pad + 16}px;color:#777;font-size:.85em;font-style:italic;">${tl("— aucune entrée —")}</p>`;
        return `<details style="margin:2px 0 2px ${pad}px;" ${depth < 1 ? "open" : ""}>
            <summary style="cursor:pointer;font-weight:600;padding:2px 0;">${node.icon ? `<i class="fa-solid ${node.icon}"></i> ` : ""}${tl(label)}</summary>
            ${body}</details>`;
    }).join("");
}

const CATEGORIES = [
    { firstKey: "tweakTree", icon: "fa-sitemap", title: tl("Modifications ciblées"),
      desc: tl("Active/désactive les modifications propres à une classe, sous-classe, espèce, sort, feature ou background. Chaque branche est dépliable."),
      tree: TWEAK_TREE, keys: collectTweakKeys() },
    { firstKey: "companionProfiles", icon: "fa-dna", title: tl("Profils de compagnons"),
      desc: tl("Ajouter ou surcharger les profils de formules des compagnons évolutifs (JSON)."),
      open: () => openProfilesEditor(), keys: [] },
    { firstKey: "uihide", icon: "fa-eye-slash", title: tl("Interface — Masquer des éléments"),
      desc: tl("Masque des icônes de la barre d'outils et de grandes zones de l'interface, avec deux colonnes : Joueurs et GM. Chaque client applique la colonne de son rôle."),
      open: () => openUiHideDialog(), keys: [] },
    { firstKey: "commonFolderPJ", icon: "fa-folder-tree", title: tl("Dossiers & Compendiums"),
      desc: tl("Dossiers et compendiums communs, renseignés une seule fois ici et utilisés par toutes les fonctions (Relations, Bestiaire, Création de personnages, Temps morts)."),
      keys: ["commonFolderPJ","autoPlayerFolder","gmAutoFolderParent","commonFolderPNJ","commonFolderNewChars","commonPackPNJ","commonPackCemetery","commonPackCreatures","commonPackCraft"] },
    { firstKey: "enableParty", master: "enableParty",           icon: "fa-users",           title: tl("Système de Party"),
      desc: tl("Groupes de joueurs : chat filtré, combat par party, téléportation de groupe, journal de session, anti-cheat."),
      keys: ["enableParty","enableJoinScene","enableShowParty","enablePlayerGrouping","enableGoWithPartyScenes","enableGoWithPartyJournal","enableChatFilter","enableChatTabs","enableTrade","enableNoteLink","enableSessionLog","sessionLogWebhookUrl","sessionLogForum","sessionTags","enableCombatParty","enableCombatTurnLock","enablePartyPause","enableAntiCheat"] },
    { firstKey: "enablePartyTime", master: "enablePartyTime", icon: "fa-hourglass-half", title: tl("Horloge de party"),
      desc: tl("Date propre à chaque party pendant l'expédition, avancée par le GM par heures ou par jours. Chaque option se coupe indépendamment : rations, alerte de faim, rappel de l'eau, résumé dans le chat, rattrapage du calendrier global à la clôture, obscurité des scènes. Nécessite le Système de Party."),
      keys: ["enablePartyTime","partyTimeRealTime","partyTimeCombatRounds","partyTimeShowClock","partyTimeRations","partyTimeHungerWarning","partyTimeWaterReminder","partyTimeChatSummary","partyTimeCatchUp","enablePartyDarkness","partyDarknessNight","partyDarknessSunrise","partyDarknessSunset"] },
    { firstKey: "enableStarXp", master: "enableStarXp", icon: "fa-star", title: tl("Système d'étoiles"),
      desc: tl("XP par étoiles : le MJ attribue des étoiles à la clôture de session (de 1 au maximum réglé par le curseur) ; le tableau fixe le coût en étoiles de chaque niveau (avec le total = nombre de sessions). Sur la fiche, l'XP est remplacée par un compteur d'étoiles."),
      keys: ["enableStarXp","starXpMaxAward","starXpLevels"] },
    { firstKey: "xpProgEnabled", master: "xpProgEnabled", icon: "fa-chart-line", title: "Progression XP (D&D 5e)",
      desc: tl("Pour jouer avec l'XP de base : niveau max, XP par session (proposée dans « Clore la session » avec les bonus de plage), sessions par semaine, et paliers de niveau : ceux de D&D par défaut (le module montre le temps qu'il faut) ou mis à l'échelle d'un objectif en mois réels, en gardant la courbe de D&D. Tableau modifiable niveau par niveau. Le niveau max autorisé s'applique toujours, même interrupteur éteint et même avec le système d'étoiles."),
      keys: ["xpProgEnabled","xpLevelCap","xpPerSession","xpThresholdMode","xpMonthsToCap","xpSessionsPerWeek","xpGrowthOverrides","xpBonusRanges"] },
    { firstKey: "mondeEnabled", master: "mondeEnabled", icon: "fa-book-atlas", title: tl("Registre du monde"),
      desc: tl("Fiches de PNJ, lieux et organisations dans Monk's Enhanced Journal, rédigées sur un modèle commun (rubriques ci-dessous), reliées aux acteurs, aux scènes, à la carte du monde et entre elles. PNJ et organisations sont rangés dans des compendiums (chargés à la demande), les lieux dans un dossier du monde (pour leurs épingles). Tout se retrouve dans l'onglet « Monde » du Casier. Nécessite Monk's Enhanced Journal."),
      keys: ["mondeEnabled","mondeDecouverte","mondeDecouverteMessage","mondeBanniere","mondeBanniereSon","mondeEpinglesPartout","mondeTailleEpingle","mondePackPerson","mondePackPersonFolder","mondePackOrg","mondePackOrgFolder","mondeFolderPlace","mondeRubriques"] },
    { firstKey: "enableCharValidation", master: "enableCharValidation", icon: "fa-id-card", title: tl("Création de personnages"),
      desc: tl("Les joueurs demandent la création d'un personnage ; un GM valide depuis le Casier, puis le joueur construit et soumet sa fiche ; à la validation elle est verrouillée. Le dossier de destination se règle dans « Dossiers & Compendiums »."),
      keys: ["enableCharValidation","charMaxTotal","charMaxActive","charFreeLevelUp","charNotifyLevelUp","blockPlayerPlutonium"] },
    { firstKey: "disableElectrum", icon: "fa-coins", title: tl("Monnaie"),
      desc: tl("Règles de bourse. ⚠️ Pour que les modules qui lisent la richesse sur la fiche (ex. Temps morts) fonctionnent correctement, forcez les pièces à rester sur la fiche (option « Pièces dans les contenants »)."),
      keys: ["disableElectrum","currencyContainerBlock"] },
    { firstKey: "enableSourceControl", master: "enableSourceControl", icon: "fa-book-skull", title: tl("Contrôle des sources"),
      desc: tl("Réglemente les livres/extensions D&D (Xanathar, Tal'Dorei, etc.) autorisés sur les fiches PJ, via deux listes blanches (joueurs / MJ). Le contenu d'une source non autorisée est bloqué avec un avertissement, quelle que soit la méthode d'ajout."),
      keys: ["enableSourceControl","sourceAllowPlayers","sourceAllowGm","sourceDeny","sourceMatchField","sourceMatchExact","sourceBlockUnknown"] },
    { firstKey: "enableHarvest", master: "enableHarvest", icon: "fa-hand-holding-droplet", title: tl("Récolte (harvest)"),
      desc: tl("Récolte de matériaux sur les créatures mortes. Le module utilise des RollTables que vous créez et associez aux créatures (bouton « Associations » dans l'onglet WestMarch). Butin partagé sur la dépouille, pourriture avec le temps, tache de sang une fois vidée."),
      keys: ["enableHarvest","harvestDcBase","harvestDcPerCr","harvestBaseDraws","harvestBloodImage"] },
    { firstKey: "enableBirthday", master: "enableBirthday", icon: "fa-cake-candles", title: tl("Anniversaires"),
      desc: tl("Message de fête dans le chat le jour de l'anniversaire d'un PJ, et en option d'un PNJ."),
      keys: ["enableBirthday","birthdayNpc"] },
    { firstKey: "enableXpBlock",         icon: "fa-server",          title: tl("Serveur"),
      desc: tl("Personnalisations du serveur : blocage XP / Level Up, logs Discord, webhooks."),
      keys: ["enableXpBlock","enableFakeWarning","enableGmNotes","hidePlayerStarTab","createPantheonFolder","downtimeWebhookUrl","tmWebhookUrl"] },
    { firstKey: "enableDiscordLog", master: "enableDiscordLog", icon: "fa-clipboard-list", title: tl("Log Discord"),
      desc: tl("Envoie un message Discord à chaque modification de fiche (objets, XP, pièces, niveaux…) et, en option, à la création/suppression de fiches, scènes et journaux. Cochez précisément ce qui est loggé, et si les PNJ sont inclus."),
      keys: ["enableDiscordLog","discordLogWebhookUrl","logInventory","logXp","logCurrency","logLevelsElements","logSheetEdits","logModuleErrors","logActors","logScenes","logJournals","logIncludeNpc"] },
    { firstKey: "enableChatCards", master: "enableChatCards", icon: "fa-comment-dots", title: tl("Cartes de chat"),
      desc: tl("Habillage des cartes de chat dnd5e (attaques, sorts, objets). Interrupteur général + choix de ce qui est activé. La couleur reste un choix par joueur (fenêtre « Accessibilité »)."),
      keys: ["enableChatCards","chatCardsTheme","chatCardsBigButtons","chatCardsExpandDice","chatCardsFoldDescription"] },
    { firstKey: "enablePolymorph", master: "enablePolymorph", icon: "fa-paw", title: tl("Transformation"),
      desc: tl("Wild Shape (druide) et Polymorphie (sort) — deux systèmes distincts via le moteur dnd5e. Active/désactive l'ensemble et règle l'application des limites de facteur de puissance (FP)."),
      keys: ["enablePolymorph","transformEnforceCr","transformStrictCr"] },
    { firstKey: "enableReactReminder", icon: "fa-bolt", title: tl("Rappels de combat"),
      desc: tl("Assistant de combat contextuel (dépend de Midi-QOL) : rappel des réactions (avec notif au MJ de la party), actions bonus utiles (Smite…), maîtrises d'arme, et avantage/désavantage. Chaque point est activable séparément."),
      keys: ["enableReactReminder","enableBonusReminder","enableMasteryReminder","enableAdvantageReminder"] },
    { firstKey: "tmSkillBase", master: "tmEnabled", icon: "fa-hourglass-half",  title: tl("Temps morts"),
      desc: tl("Règles configurables des temps morts : valeurs, formules (gain de compétence, artisanat) et tables (parchemins, objets magiques). Chaque serveur peut avoir ses propres règles."),
      keys: ["tmEnabled","tmSkillBase","tmAddAbilityMod","tmBonusMaitrise","tmBonusExpertise","tmBonusTools","tmRollMinDays","tmReliableTalent","tmSkillFormula","tmCraftNonMagicCostDiv","tmCraftNonMagicDaysPerGp","tmCraftNonMagicCostFormula","tmCraftNonMagicDaysFormula","tmSingleUseFactor","tmScrollTable","tmMagicTable","tmRollTable"] },
    { firstKey: "enableTokenAppearance", icon: "fa-toolbox",         title: "Toolkit",
      desc: tl("Apparences de tokens, transformations, tailles Large, TGCM, utilitaires GM, templates AoE, boutiques MEJ et réapprovisionnement."),
      keys: ["enableCasierGm","enableExpeditionDate","enableChatTools","enableExportDialog","enablePlayerListToggle","enableTokenAppearance","enableTokenPortraitButton","enableTokenAccroche","enableGmNotesNpc","enableTgcm","enableCompanions","enableFolderMove","enableToolAbilityFix","enableConnStats","enablePlayerListCompact","enableTemplateSnap","enableFollowTemplates","enableMejShopFix","enableMejRestock","shopRestockDays","shopRestockDaysCommon","shopRestockDaysUncommon","shopRestockDaysRare","shopRestockDaysVeryRare","shopRestockDaysLegendary"] },
    { firstKey: "relationsEnabled", master: "relationsEnabled",      icon: "fa-heart",           title: tl("Fiche PJ — Relations"),
      desc: tl("Onglet Relations : liens entre personnages, détection automatique des rencontres, anonymisation."),
      keys: ["relationsEnabled","relationsAnonymization","relationsLastSeen"] },
    { firstKey: "bestiaryEnabled", master: "bestiaryEnabled",       icon: "fa-dragon",          title: tl("Fiche PJ — Bestiaire"),
      desc: tl("Onglet Bestiaire : créatures rencontrées, répertoriées par personnage."),
      keys: ["bestiaryEnabled","bestiaryAnonymization","bestiaryLastPosition","bestiaryLastSeen","bestiaryDamageTags","bestiaryArmorClass"] },
    { firstKey: "carnetEnabled", master: "carnetEnabled",         icon: "fa-book-open",       title: tl("Fiche PJ — Carnet & Expéditions"),
      desc: tl("Onglets Carnet (notes enrichies) et Expéditions (dates + durée)."),
      keys: ["carnetEnabled","enablePcStatus"] },
    { firstKey: "enableExpeditionMap", master: "enableExpeditionMap",   icon: "fa-map",             title: tl("Carte des expéditions"),
      desc: tl("Brouillard de guerre par party et par personnage sur une scène dédiée."),
      keys: ["enableExpeditionMap","expeditionMapSceneId","expeditionMapSceneIds","expeditionMapTemplateFolder","expeditionRevealRadius"] },
    { firstKey: "enableSceneCues", master: "enableSceneCues",       icon: "fa-clapperboard",    title: tl("Mise en scène — Cues audio"),
      desc: tl("Cues audio attachés aux tokens : déclenchement auto quand le token perd son invisibilité GM, ou manuel. Réglage de la seconde de départ, du volume et du fondu."),
      keys: ["enableSceneCues","sceneCuesDefaultVolume"] },
    { firstKey: "rangeFixEnabled", master: "rangeFixEnabled",       icon: "fa-bullseye",        title: tl("Midi Range Fix"),
      desc: tl("Correction du calcul de portée midi-qol pour les tokens Large et plus."),
      keys: ["rangeFixEnabled","rangeAdjust"] },
    { firstKey: "enableDiagnosticMenu", icon: "fa-gear", title: tl("Module — éléments de base"),
      desc: tl("Menus et automatismes du module lui-même : diagnostic, administration, message après mise à jour, reprise des anciennes données, fenêtre des droits. La fenêtre « À propos » reste toujours là : c'est elle qui reçoit le code de licence."),
      keys: ["enableDiagnosticMenu","enableAdminMenu","enableSiteMessage","enableLegacyMigration","enableOwnershipScroll"] },
    { firstKey: "serverName", master: "tutoEnabled", icon: "fa-circle-question", title: tl("Tutoriel"),
      desc: tl("Fenêtre de bienvenue et guide interactif, configurable section par section."),
      keys: ["tutoEnabled","welcomeWindowTitle","serverName","welcomeText","welcomeWarning","welcomeStartLabel","tutoBarreWestmarch","tutoTourFiche","tutoNoteGm","tutoMonPerso","tutoBestiary","tutoRelations","tutoCarnet","tutoHorloge","tutoCasier","tutoMonde","tutoCues","tutoBoutiques","tutoTempsMorts","tutoApparenceTokens","tutoHudToken","tutoOutilsGm","tutoAccessibilite","tutoEchange","tutoTransformation","tutoCompagnons","tutoPantheon","showWelcome"] },
];

const ACCENT = "#e67e22";

// Réglages GELÉS : affichés grisés/désactivés dans la configuration (on ne peut
// pas les modifier). Utilisé pour une fonctionnalité temporairement coupée.
export const FROZEN_SETTINGS = new Set(["enableTgcm", "enableTokenAppearance"]);

// Schémas des tables de temps morts éditées en grille (champs structurés).
const TM_TABLE_SCHEMAS = {
    tmScrollTable: {
        fallback: TM_DEFAULT_SCROLL,
        rowLabel: (i) => `Niveau ${i}${i === 0 ? " (mineur)" : ""}`,
        cols: [
            { field: "days", label: tl("Jours"),     type: "number" },
            { field: "cost", label: tl("Coût (PO)"), type: "number" }
        ]
    },
    tmMagicTable: {
        fallback: TM_DEFAULT_MAGIC,
        rowLabel: (i, row) => row.key,
        cols: [
            { field: "label", label: tl("Nom"),         type: "text"   },
            { field: "days",  label: tl("Jours"),       type: "number" },
            { field: "cost",  label: tl("Coût (PO)"),   type: "number" },
            { field: "lvl",   label: "Niv. requis", type: "number" }
        ]
    },
    tmRollTable: {
        fallback: TM_DEFAULT_ROLL,
        rowLabel: (i) => `Palier ${i + 1}`,
        cols: [
            { field: "max",   label: tl("Résultat ≤"), type: "number" },
            { field: "mult",  label: tl("Multipl."),   type: "number" },
            { field: "label", label: tl("Libellé"),    type: "text"   }
        ]
    }
};

function normalizeTable(key) {
    const val = game.settings.get(MOD, key);
    return (Array.isArray(val) && val.length) ? val : TM_TABLE_SCHEMAS[key].fallback;
}

function tableControlHtml(key, cfg) {
    const schema = TM_TABLE_SCHEMAS[key];
    const rows   = normalizeTable(key);
    const th = `<tr><th style="text-align:left;font-size:.72em;color:#888;padding:0 6px 3px 0;"></th>${
        schema.cols.map(c => `<th style="text-align:left;font-size:.72em;color:#888;padding:0 4px 3px;">${c.label}</th>`).join("")}</tr>`;
    const tb = rows.map((row, i) => `<tr>
        <td style="font-size:.8em;color:#aaa;white-space:nowrap;padding:2px 6px 2px 0;">${schema.rowLabel(i, row)}</td>
        ${schema.cols.map(c => `<td style="padding:1px 4px;"><input type="${c.type}" ${c.type === "number" ? 'step="any"' : ""} name="${key}__${i}__${c.field}" value="${escapeAttr(row[c.field] ?? "")}" style="width:100%;box-sizing:border-box;"></td>`).join("")}
    </tr>`).join("");
    return `<div class="scwm-set" data-key="${key}" style="padding:8px 4px;border-bottom:1px solid rgba(255,255,255,0.06);">
        <label style="display:block;font-weight:600;margin-bottom:4px;">${cfg.name}</label>
        <table style="width:100%;border-collapse:collapse;"><thead>${th}</thead><tbody>${tb}</tbody></table>
    </div>`;
}

function readTableFromForm(key, root) {
    const schema = TM_TABLE_SCHEMAS[key];
    return normalizeTable(key).map((row, i) => {
        const out = { ...row };
        for (const c of schema.cols) {
            const el = root.querySelector(`[name="${key}__${i}__${c.field}"]`);
            if (!el) continue;
            out[c.field] = c.type === "number" ? Number(el.value) : el.value;
        }
        return out;
    });
}

// ── Table du système d'étoiles (niveau → étoiles requises + total) ──
const STARXP_LEVELS = 19;   // niveaux 1→2 … 19→20 (dnd5e plafonne à 20)

function normalizeStarLevels() {
    let raw = game.settings.get(MOD, "starXpLevels");
    if (!Array.isArray(raw)) raw = [];
    const out = [];
    for (let i = 0; i < STARXP_LEVELS; i++) {
        const n = Math.max(0, Math.round(Number(raw[i]) || 0));
        out.push(n > 0 ? n : 3);
    }
    return out;
}

function starTableHtml(cfg) {
    const rows = normalizeStarLevels();
    const total = rows.reduce((a, b) => a + b, 0);
    const body = rows.map((n, i) => `<tr>
        <td style="font-size:.8em;color:#aaa;white-space:nowrap;padding:2px 6px 2px 0;">${tl("Niveau {0} → {1}", i + 1, i + 2)}</td>
        <td style="padding:1px 4px;">
            <input type="number" min="1" step="1" class="scwm-starxp-input" name="starXpLevels__${i}"
                   value="${n}" style="width:80px;box-sizing:border-box;">
            <span style="color:#e6be3c;margin-left:4px;">★</span>
        </td>
    </tr>`).join("");
    return `<div class="scwm-set" data-key="starXpLevels" style="padding:8px 4px;border-bottom:1px solid rgba(255,255,255,0.06);">
        <label style="display:block;font-weight:600;margin-bottom:4px;">${tl("Coût en étoiles par niveau")}</label>
        <p style="margin:0 0 6px;font-size:.8em;color:#999;">${tl("Nombre d'étoiles à accumuler pour passer chaque niveau. Le total indique combien de sessions représente une progression complète (niveau 1 → 20).")}</p>
        <table style="width:100%;border-collapse:collapse;"><tbody>${body}</tbody></table>
        <div class="scwm-starxp-total" style="margin-top:8px;padding-top:6px;border-top:1px solid rgba(230,190,60,0.4);font-weight:700;color:#e6be3c;">
            ${tl("Total :")} <span class="scwm-starxp-total-n">${total}</span> ★
            <span style="font-weight:400;color:#999;font-size:.85em;">
                (≈ <span class="scwm-starxp-total-s1">${total}</span> ${tl("sessions à 1★,")}
                <span class="scwm-starxp-total-s2">${Math.ceil(total / 2)}</span> ${tl("à 2★,")}
                <span class="scwm-starxp-total-s3">${Math.ceil(total / 3)}</span> ${tl("à 3★)")}
            </span>
        </div>
    </div>`;
}

function readStarTableFromForm(root) {
    const out = [];
    for (let i = 0; i < STARXP_LEVELS; i++) {
        const el = root.querySelector(`[name="starXpLevels__${i}"]`);
        out.push(Math.max(1, Math.round(Number(el?.value) || 3)));
    }
    return out;
}

// ============================================================
// Panneau de configuration REGROUPÉ — un seul bouton ouvre une fenêtre
// où toutes les catégories sont classées par grands thèmes, avec des
// sections repliables. Les boutons « Configurer » individuels restent
// disponibles en parallèle pour un accès direct aux gros modules.
// ============================================================

// Regroupement des catégories (firstKey) par thème. Les catégories non
// listées ici sont ajoutées automatiquement à « Divers ».
const CONFIG_GROUPS = [
    { title: tl("Fiche PJ & personnages"), icon: "fa-id-card",
      cats: ["relationsEnabled", "bestiaryEnabled", "carnetEnabled", "enableCharValidation", "enableStarXp", "xpProgEnabled", "enableSourceControl", "disableElectrum"] },
    { title: tl("Party & jeu de groupe"), icon: "fa-users",
      cats: ["enableParty", "enablePartyTime", "enableExpeditionMap", "enableHarvest"] },
    { title: "Combat", icon: "fa-bolt",
      cats: ["enableReactReminder", "rangeFixEnabled", "enablePolymorph"] },
    { title: "Serveur & monde", icon: "fa-server",
      cats: ["enableXpBlock", "mondeEnabled", "enableDiscordLog", "tmSkillBase", "enableSceneCues", "commonFolderPJ"] },
    { title: "Personnalisation & interface", icon: "fa-sliders",
      cats: ["enableChatCards", "enableTokenAppearance", "uihide", "tweakTree", "companionProfiles"] },
    { title: tl("Aide & découverte"), icon: "fa-circle-question",
      cats: ["serverName", "enableDiagnosticMenu"] }
];

function _groupedCategories() {
    const byKey = new Map(CATEGORIES.map(c => [c.firstKey, c]));
    const used = new Set();
    const groups = CONFIG_GROUPS.map(g => ({
        title: g.title, icon: g.icon,
        cats: g.cats.map(k => byKey.get(k)).filter(Boolean)
    }));
    for (const g of groups) for (const c of g.cats) used.add(c.firstKey);
    const misc = CATEGORIES.filter(c => !used.has(c.firstKey));
    if (misc.length) groups.push({ title: tl("Divers"), icon: "fa-ellipsis", cats: misc });
    return groups.filter(g => g.cats.length);
}

function registerConfigHub() {
    try {
        game.settings.registerMenu(MOD, "menu-config-hub", {
            name:  tl("⚙ Panneau de configuration (tout)"),
            label: tl("Ouvrir le panneau"),
            hint:  tl("Tous les réglages du module, classés par thème avec des sections repliables. Point d'entrée recommandé."),
            icon:  "fas fa-gears",
            type:  makeLauncher({ firstKey: "config-hub", title: tl("Panneau de configuration"), icon: "fa-gears", open: () => openConfigHub() }),
            restricted: true
        });
    } catch (e) {
        journal.critique(tl("[{0}] registerMenu « Panneau de configuration » échec :", MOD), e);
    }
}

// Une catégorie qui a un handler `open` (éditeur dédié) et aucune clé n'est
// pas inlinable : on affiche un bouton qui ouvre son éditeur.
const _catIsInlinable = (cat) => Array.isArray(cat.keys) && cat.keys.length > 0 || !!cat.tree;
const _hubHostId = (cat) => `scwm-hub-cat-${cat.firstKey}`;

// ── Filtre « Uniquement l'actif » du panneau ───────────────────
// Réglages non booléens qui n'ont de sens que si une case est cochée : masqués
// avec elle.
const HUB_DEPENDANCES = {
    sessionLogWebhookUrl: "enableSessionLog", sessionLogForum: "enableSessionLog", sessionTags: "enableSessionLog",
    shopRestockDays: "enableMejRestock", shopRestockDaysCommon: "enableMejRestock", shopRestockDaysUncommon: "enableMejRestock",
    shopRestockDaysRare: "enableMejRestock", shopRestockDaysVeryRare: "enableMejRestock", shopRestockDaysLegendary: "enableMejRestock",
    ...Object.fromEntries(PARTYDARK_SUB_SETTINGS.map(k => [k, "enablePartyDarkness"]))
};
const _hubFiltreActif = () => { try { return game.settings.get(MOD, "hubActifsSeulement") !== false; } catch { return true; } };
const _bool = (k) => { try { return game.settings.settings.get(`${MOD}.${k}`)?.type === Boolean ? !!game.settings.get(MOD, k) : null; } catch { return null; } };

function _hubMarquerInactifs(root) {
    // 1. Lignes : case décochée, ou réglage dépendant d'une case décochée.
    root.querySelectorAll(".scwm-hub-cat .scwm-set[data-key]").forEach(el => {
        const k = el.dataset.key;
        if (_bool(k) === false || (HUB_DEPENDANCES[k] && _bool(HUB_DEPENDANCES[k]) === false)) el.setAttribute("data-scwm-off", "");
    });
    // 2. Branches de l'arbre des modifications ciblées sans aucune feuille active.
    [...root.querySelectorAll(".scwm-hub-cat details")].reverse().forEach(d => {
        if (!d.querySelector(".scwm-set:not([data-scwm-off])")) d.setAttribute("data-scwm-off", "");
    });
    // 3. Catégorie dont tout est désactivé (et sans autre champ hors lignes).
    root.querySelectorAll(".scwm-hub-cat:not([data-scwm-off])").forEach(cat => {
        const body = cat.querySelector(".scwm-hub-cat-body");
        const lignes = body ? [...body.querySelectorAll(".scwm-set")] : [];
        if (!lignes.length || lignes.some(l => !l.hasAttribute("data-scwm-off"))) return;
        const autres = [...body.querySelectorAll("input, select, textarea")].some(i => !i.closest(".scwm-set"));
        if (!autres) cat.setAttribute("data-scwm-off", "");
    });
    // 4. Thèmes sans catégorie visible : bouton de navigation masqué aussi.
    root.querySelectorAll(".scwm-hub-group").forEach(sec => {
        if (sec.querySelector(".scwm-hub-cat:not([data-scwm-off]), .scwm-hub-launch:not([data-scwm-off])")) return;
        sec.setAttribute("data-scwm-off", "");
        root.querySelector(`.scwm-hub-navbtn[data-group="${sec.dataset.group}"]`)?.setAttribute("data-scwm-off", "");
    });
}

function _hubAppliquerFiltre(root, on) {
    root.classList.toggle("scwm-filtre-actifs", on);
    const n = root.querySelectorAll(".scwm-hub-scroll .scwm-set[data-scwm-off], .scwm-hub-cat[data-scwm-off], .scwm-hub-launch[data-scwm-off]").length;
    const lbl = root.querySelector(".scwm-hub-filtre-n");
    if (lbl) lbl.textContent = on && n ? ` ${tl("({0} masqués)", n)}` : "";
    // Thème affiché devenu masqué → on passe au premier thème visible.
    const actif = root.querySelector(".scwm-hub-navbtn.active");
    if (on && actif?.hasAttribute("data-scwm-off")) root.querySelector(".scwm-hub-navbtn:not([data-scwm-off])")?.click();
}

export async function openConfigHub() {
    const groups = _groupedCategories();

    const filtreOn = _hubFiltreActif();
    const groupHtml = groups.map((g, gi) => {
        const cats = g.cats.map(cat => {
            // Catégorie coupée par son interrupteur principal → masquée par le filtre.
            const off = cat.master && !game.settings.get(MOD, cat.master) ? " data-scwm-off" : "";
            if (!_catIsInlinable(cat)) {
                // Catégorie à éditeur dédié (Profils compagnons, Interface—Masquer…).
                return `<div class="scwm-hub-launch"${off}>
                    <div><i class="fa-solid ${cat.icon}"></i> <strong>${cat.title}</strong>
                        <div class="scwm-hub-launch-desc">${cat.desc ?? ""}</div></div>
                    <button type="button" class="scwm-hub-open" data-cat="${cat.firstKey}">
                        ${tl("<i class=\"fa-solid fa-up-right-from-square\"></i> Ouvrir")}</button>
                </div>`;
            }
            return `<details class="scwm-hub-cat"${off}>
                <summary><i class="scwm-hub-caret fa-solid fa-caret-right"></i><i class="fa-solid ${cat.icon}"></i> ${cat.title}</summary>
                <div class="scwm-hub-cat-body">${buildCategoryForm(cat, _hubHostId(cat), { banner: false })}</div>
            </details>`;
        }).join("");
        return `<section class="scwm-hub-group" data-group="${gi}" ${gi === 0 ? "" : 'style="display:none;"'}>
            <h2 class="scwm-hub-group-title"><i class="fa-solid ${g.icon}"></i> ${g.title}</h2>
            ${cats}
        </section>`;
    }).join("");

    const nav = groups.map((g, gi) =>
        `<button type="button" class="scwm-hub-navbtn ${gi === 0 ? "active" : ""}" data-group="${gi}">
            <i class="fa-solid ${g.icon}"></i><span>${g.title}</span></button>`).join("");

    const filtre = `<label class="scwm-hub-filtre" title="${tl("Masque les fonctions et options désactivées pour ne gérer au quotidien que ce qui est actif. Décoche pour tout voir (et réactiver une fonction).")}">
        <input type="checkbox" class="scwm-hub-filtre-cb" ${filtreOn ? "checked" : ""}>
        <span>${tl("Uniquement l'actif")}<small class="scwm-hub-filtre-n"></small></span></label>`;
    const content = `
    <div id="scwm-hub" class="scwm-hub ${filtreOn ? "scwm-filtre-actifs" : ""}">
        <div class="scwm-hub-nav">${filtre}${nav}</div>
        <div class="scwm-hub-scroll">${groupHtml}</div>
    </div>`;

    const wireHub = () => {
        const root = document.getElementById("scwm-hub");
        if (!root) return;
        // Navigation entre thèmes.
        root.querySelectorAll(".scwm-hub-navbtn").forEach(btn => btn.addEventListener("click", (e) => {
            e.preventDefault();
            const gi = btn.dataset.group;
            root.querySelectorAll(".scwm-hub-navbtn").forEach(b => b.classList.toggle("active", b === btn));
            root.querySelectorAll(".scwm-hub-group").forEach(s => s.style.display = (s.dataset.group === gi) ? "" : "none");
            root.querySelector(".scwm-hub-scroll")?.scrollTo({ top: 0 });
        }));
        // Boutons « Ouvrir » des éditeurs dédiés.
        root.querySelectorAll(".scwm-hub-open").forEach(btn => btn.addEventListener("click", (e) => {
            e.preventDefault();
            const cat = CATEGORIES.find(c => c.firstKey === btn.dataset.cat);
            if (cat?.open) cat.open();
        }));
        // Câblage de chaque formulaire de catégorie inliné, chacun sur SON hôte
        // (évite les collisions de sélecteurs entre catégories).
        for (const g of groups) for (const cat of g.cats) {
            if (!_catIsInlinable(cat)) continue;
            const host = document.getElementById(_hubHostId(cat));
            if (host) { try { wireCategoryForm(cat, host); } catch (err) { journal.avert(`[${MOD}] wire hub ${cat.firstKey}`, err); } }
        }
        // Filtre « Uniquement l'actif » : marque ce qui est désactivé À L'OUVERTURE
        // (une case décochée pendant l'édition reste visible jusqu'à la prochaine).
        _hubMarquerInactifs(root);
        const cb = root.querySelector(".scwm-hub-filtre-cb");
        cb?.addEventListener("change", async () => {
            _hubAppliquerFiltre(root, cb.checked);
            try { await game.settings.set(MOD, "hubActifsSeulement", cb.checked); } catch (err) { journal.avert(`[${MOD}] hubActifsSeulement`, err); }
        });
        _hubAppliquerFiltre(root, !!cb?.checked);
    };

    await foundry.applications.api.DialogV2.wait({
        window:      { title: tl("Soruta — Panneau de configuration"), icon: "fas fa-gears" },
        position:    { width: 780 },
        rejectClose: false,
        content,
        render:      wireHub,
        buttons: [
            {
                action: "save", default: true,
                label: tl("Tout enregistrer"), icon: '<i class="fa-solid fa-save"></i>',
                callback: async () => {
                    let reload = false;
                    for (const g of groups) for (const cat of g.cats) {
                        if (!_catIsInlinable(cat)) continue;
                        const host = document.getElementById(_hubHostId(cat));
                        if (host) reload = (await saveCategoryForm(cat, host, { silent: true })) || reload;
                    }
                    ui.notifications?.info(tl("Réglages enregistrés."));
                    if (reload) {
                        const ok = await foundry.applications.api.DialogV2.confirm({
                            window:  { title: tl("Rechargement requis") },
                            content: `<p>${tl("Certains changements nécessitent un rechargement pour s'appliquer. Recharger maintenant ?")}</p>`
                        });
                        if (ok) window.location.reload();
                    }
                }
            },
            { action: "close", label: tl("Fermer"), icon: '<i class="fa-solid fa-xmark"></i>', callback: () => {} }
        ]
    });
}

// ============================================================
// Menus par catégorie — chaque grande section devient un bouton
// "Configurer" (registerMenu) qui ouvre une fenêtre dédiée (DialogV2)
// avec uniquement les réglages de cette section.
// ============================================================

function registerCategoryMenus() {
    // Ordre alphabétique des catégories (l'affichage suit l'ordre d'enregistrement).
    const sorted = [...CATEGORIES].sort((a, b) => a.title.localeCompare(b.title, "fr", { sensitivity: "base" }));
    for (const cat of sorted) {
        try {
            game.settings.registerMenu(MOD, `menu-${cat.firstKey}`, {
                name:       cat.title,
                label:      tl("Configurer"),
                hint:       cat.desc,
                icon:       `fas ${cat.icon}`,
                type:       makeLauncher(cat),
                restricted: true   // GM uniquement (réglages "world")
            });
        } catch (e) {
            journal.critique(tl("[{0}] registerMenu \"{1}\" échec :", MOD, cat.title), e);
        }
    }
}

// Foundry fait new type().render(true) au clic du bouton. registerMenu EXIGE
// que type soit une sous-classe de FormApplication ou d'ApplicationV2 (sinon
// l'enregistrement échoue et le module n'apparaît pas dans la config). On étend
// donc ApplicationV2 et on détourne render() pour ouvrir notre fenêtre DialogV2.
function makeLauncher(category) {
    return class extends foundry.applications.api.ApplicationV2 {
        static DEFAULT_OPTIONS = {
            id:     `scwm-menu-${category.firstKey}`,
            window: { title: category.title }
        };
        async render() { (category.open ?? (() => openCategoryDialog(category)))(); return this; }
        async close()  { return this; }
    };
}

async function openCategoryDialog(category) {
    const uid = `scwm-cat-${category.firstKey}`;
    await foundry.applications.api.DialogV2.wait({
        window:      { title: `Configurer — ${category.title}`, icon: `fas ${category.icon}` },
        position:    { width: 560 },
        rejectClose: false,
        content:     buildCategoryForm(category, uid),
        render:      () => wireCategoryForm(category, document.getElementById(uid)),
        buttons: [
            {
                action: "save", default: true,
                label: tl("Enregistrer"), icon: '<i class="fa-solid fa-save"></i>',
                callback: async () => await saveCategoryForm(category, document.getElementById(uid))
            },
            { action: "close", label: tl("Fermer"), icon: '<i class="fa-solid fa-xmark"></i>', callback: () => {} }
        ]
    });
}

function boolKeysOf(category) {
    return category.keys.filter(k => game.settings.settings.get(`${MOD}.${k}`)?.type === Boolean);
}

function buildCategoryForm(category, uid, { banner = true } = {}) {
    const toggleBar = boolKeysOf(category).length >= 2 ? `
        <div style="display:flex;gap:12px;justify-content:flex-end;margin:0 4px 8px;font-size:.8em;">
            ${tl("<a class=\"scwm-all-on\"  style=\"color:#8fd19e;cursor:pointer;\">Tout activer</a>")}
            <span style="color:#555;">·</span>
            ${tl("<a class=\"scwm-all-off\" style=\"color:#e58f8f;cursor:pointer;\">Tout désactiver</a>")}
        </div>` : "";
    return `
    <div id="${uid}" class="scwm-cat-form" style="display:flex;flex-direction:column;max-height:60vh;overflow-y:auto;padding-right:4px;">
        ${banner ? licenseBannerHtml() : ""}
        ${category.desc ? `<p style="margin:0 0 8px;font-size:.85em;color:#aaa;font-style:italic;">${category.desc}</p>` : ""}
        ${toggleBar}
        ${category.tree ? renderTweakTree(category.tree) : category.keys.map(settingControlHtml).join("")}
        ${category.firstKey === "commonFolderPJ" ? blocGuideReglagesHtml() : ""}
    </div>`;
}

// Bandeau « droits & version » affiché en tête de chaque fenêtre de réglages.
export function licenseBannerHtml() {
    const version = game.modules.get(MOD)?.version ?? "";
    return `
    <div style="display:flex;align-items:center;gap:8px;margin:0 0 10px;padding:7px 10px;
                border:1px solid rgba(201,162,39,0.5);border-radius:5px;
                background:linear-gradient(180deg,rgba(201,162,39,0.12),rgba(0,0,0,0.15));">
        <i class="fa-solid fa-shield-halved" style="color:${ACCENT};font-size:15px;"></i>
        <div style="font-size:.78em;line-height:1.4;color:#d8cfa8;">
            ${tl("<strong>Soruta — Completed Westmarch</strong> · v{0}<br>\n            © 2026 Soruta — Tous droits réservés. Usage personnel autorisé ; toute\n            redistribution, modification ou usage commercial est interdit sans autorisation écrite.", version)}
        </div>
    </div>`;
}

function settingControlHtml(key) {
    const cfg = game.settings.settings.get(`${MOD}.${key}`);
    if (!cfg) return "";
    if (key === "starXpLevels") return starTableHtml(cfg);
    const xpProg = xpProgControlHtml(key);
    if (xpProg !== null) return xpProg;
    const monde = mondeControlHtml(key);
    if (monde !== null) return monde;
    if (key === "sessionTags") return tagListControlHtml();
    if (TM_TABLE_SCHEMAS[key]) return tableControlHtml(key, cfg);
    const val    = game.settings.get(MOD, key);
    const reload = cfg.requiresReload ? ` <span style="color:${ACCENT};font-size:.78em;">${tl("⟳ rechargement")}</span>` : "";
    const hint   = cfg.hint ? `<p style="margin:3px 0 0;font-size:.8em;color:#999;">${cfg.hint}</p>` : "";
    const wrap   = "padding:8px 4px;border-bottom:1px solid rgba(255,255,255,0.06);";

    if (cfg.type === Boolean) {
        const frozen = FROZEN_SETTINGS.has(key);
        const frozenNote = frozen ? ` <span style="color:${ACCENT};font-size:.78em;">${tl("⏸ temporairement désactivé")}</span>` : "";
        return `<div class="scwm-set" data-key="${key}" style="${wrap}${frozen ? "opacity:.5;" : ""}">
            <label style="display:flex;align-items:center;justify-content:space-between;gap:12px;cursor:${frozen ? "not-allowed" : "pointer"};font-weight:600;margin:0;">
                <span>${cfg.name}${reload}${frozenNote}</span>
                <input type="checkbox" name="${key}" ${val ? "checked" : ""} ${frozen ? "disabled" : ""} style="width:18px;height:18px;flex-shrink:0;">
            </label>${hint}</div>`;
    }

    let control;
    if (cfg.choices && typeof cfg.choices === "object") {
        const opts = Object.entries(cfg.choices)
            .map(([v, lbl]) => `<option value="${escapeAttr(v)}" ${val === v ? "selected" : ""}>${lbl}</option>`)
            .join("");
        control = `<select name="${key}" style="width:100%;">${opts}</select>`;
    } else if (cfg.type === Number) {
        control = `<input type="number" name="${key}" value="${val ?? 0}" step="any" style="width:100%;">`;
    } else if (key === "sourceAllowPlayers" || key === "sourceAllowGm" || key === "sourceDeny") {
        // Listes de sources potentiellement longues → zone multi-ligne.
        const ph = key === "sourceDeny" ? "Ex. : conjure-animals ; silvery-barbs ; UA" : "Ex. : XPHB ; TCE : sous-classe, don ; XGE : sort";
        control = `<textarea name="${key}" rows="4" placeholder="${ph}"
            style="width:100%;box-sizing:border-box;resize:vertical;min-height:70px;font-family:var(--font-mono,monospace);font-size:.9em;">${escapeAttr(val ?? "")}</textarea>`;
    } else if (key === "welcomeText" || key === "welcomeWarning") {
        // Textes de la fenêtre de bienvenue : zone multi-ligne.
        control = `<textarea name="${key}" rows="${key === "welcomeText" ? 4 : 2}"
            style="width:100%;box-sizing:border-box;resize:vertical;min-height:44px;">${escapeAttr(val ?? "")}</textarea>`;
    } else if (key === "gmAutoFolderParent") {
        // Nom de dossier saisi librement (PAS un sélecteur : le même nom sert
        // dans Acteurs, Journaux et Scènes).
        control = `<input type="text" name="${key}" value="${escapeAttr(val ?? "")}" placeholder="${tl("Nom du dossier parent (ex. Game Master)")}" style="width:100%;">`;
    } else if (key === "starXpMaxAward") {
        // Curseur 1 à 10 + valeur affichée en étoiles.
        const r = cfg.range ?? { min: 1, max: 10, step: 1 };
        const v = Math.min(r.max, Math.max(r.min, Math.round(Number(val)) || 3));
        control = `<div style="display:flex;align-items:center;gap:8px;">
            <input type="range" name="${key}" class="scwm-star-max" min="${r.min}" max="${r.max}" step="${r.step}" value="${v}" style="flex:1;">
            <span class="scwm-star-max-v" style="flex:0 0 64px;text-align:right;font-weight:600;color:#e6be3c;">${v} ★</span></div>`;
    } else if (key === "mondeTailleEpingle") {
        // Curseur + valeur affichée (8 à 512 px).
        const v = Math.min(512, Math.max(8, Number(val) || 32));
        control = `<div style="display:flex;align-items:center;gap:8px;">
            <input type="range" name="${key}" class="scwm-taille-epingle" min="8" max="512" step="4" value="${v}" style="flex:1;">
            <span class="scwm-taille-epingle-v" style="flex:0 0 56px;text-align:right;">${tl("{0} px", v)}</span></div>`;
    } else if (key === "mondeFolderPlace") {
        // Registre du monde : NOM du dossier de journaux (créé au besoin).
        control = `<input type="text" name="${key}" value="${escapeAttr(val ?? "")}" placeholder="Lieux" style="width:100%;">`;
    } else if (key === "mondePackPerson" || key === "mondePackOrg") {
        // Registre du monde : compendium de JOURNAUX (vide = créé automatiquement).
        control = `<select name="${key}" style="width:100%;">${packOptionsHtml(val, "JournalEntry").replace(tl("— aucun —"), tl("— créé automatiquement —"))}</select>`;
    } else if (key === "mondePackPersonFolder" || key === "mondePackOrgFolder") {
        // Registre du monde : NOM d'un dossier DANS le compendium (créé au besoin).
        control = `<input type="text" name="${key}" value="${escapeAttr(val ?? "")}" placeholder="${tl("(racine du compendium)")}" style="width:100%;">`;
    } else if (key === "expeditionMapTemplateFolder") {
        control = `<select name="${key}" style="width:100%;">${folderOptionsHtml(val).replace(tl("— aucun —"), tl("— « Tokens de groupe » (automatique) —"))}</select>`;
    } else if (key.includes("Folder")) {
        control = `<select name="${key}" style="width:100%;">${folderOptionsHtml(val)}</select>`;
    } else if (key.includes("Pack")) {
        // Les compendiums d'OBJETS (craft) vs d'ACTEURS.
        const docType = (key === "tmCraftPack" || key === "commonPackCraft") ? "Item" : "Actor";
        control = `<select name="${key}" style="width:100%;">${packOptionsHtml(val, docType)}</select>`;
    } else if (key === "expeditionMapSceneId") {
        control = `<select name="${key}" style="width:100%;">${sceneOptionsHtml(val)}</select>`;
    } else if (key === "expeditionMapSceneIds") {
        const ids = Array.isArray(val) ? val.filter(Boolean) : [];
        const rows = ids.map(id => sceneRowHtml(id)).join("");
        control = `<div class="scwm-scene-list" data-key="${key}">
            <div class="scwm-scene-rows">${rows}</div>
            <button type="button" class="scwm-scene-add"
                    style="margin-top:2px;padding:3px 10px;border-radius:4px;cursor:pointer;
                           border:1px solid rgba(201,162,39,0.4);background:rgba(201,162,39,0.12);color:#c9a227;">
                ${tl("<i class=\"fa-solid fa-plus\"></i> Ajouter une carte")}
            </button>
        </div>`;
    } else if (key === "activationCode") {
        // Champ masqué (comme un mot de passe) — la valeur ne s'affiche pas en clair.
        control = `<input type="password" name="${key}" value="${escapeAttr(val ?? "")}" autocomplete="new-password" style="width:100%;">`;
    } else if (key.endsWith("Son")) {
        // Chemin audio avec « Parcourir » (FilePicker audio) et « Tester ».
        control = `<div style="display:flex;gap:4px;">
            <input type="text" name="${key}" value="${escapeAttr(val ?? "")}" placeholder="${tl("Aucun son")}" style="flex:1 1 auto;min-width:0;">
            <button type="button" class="scwm-filepicker" data-target="${key}" data-fptype="audio" title="${tl("Parcourir")}" style="flex:0 0 auto;width:34px;"><i class="fa-solid fa-file-audio"></i></button>
            ${key === "mondeBanniereSon" ? `<button type="button" class="scwm-test-banniere" data-target="${key}" title="${tl("Tester la bannière (sur ton écran)")}" style="flex:0 0 auto;width:34px;"><i class="fa-solid fa-play"></i></button>` : ""}
        </div>`;
    } else if (key.endsWith("Image")) {
        // Chemin d'image avec bouton « Parcourir » (FilePicker).
        control = `<div style="display:flex;gap:4px;">
            <input type="text" name="${key}" value="${escapeAttr(val ?? "")}" style="flex:1 1 auto;min-width:0;">
            <button type="button" class="scwm-filepicker" data-target="${key}" data-fptype="image" title="Parcourir" style="flex:0 0 auto;width:34px;"><i class="fa-solid fa-file-import"></i></button>
        </div>`;
    } else {
        control = `<input type="text" name="${key}" value="${escapeAttr(val ?? "")}" style="width:100%;">`;
    }
    return `<div class="scwm-set" data-key="${key}" style="${wrap}">
        <label style="display:block;font-weight:600;margin-bottom:4px;">${cfg.name}${reload}</label>
        ${control}${hint}</div>`;
}

function wireCategoryForm(category, root) {
    if (!root) return;

    // Dossiers & Compendiums : générer le journal « Où ranger quoi ? ».
    root.querySelector(".scwm-rg-generer")?.addEventListener("click", async (e) => {
        e.preventDefault();
        const btn = e.currentTarget;
        btn.disabled = true;
        try {
            await saveCategoryForm(category, root, { silent: true });   // le guide lit les réglages enregistrés
            if (await genererEtOuvrirGuide()) btn.innerHTML = `${tl("<i class=\"fa-solid fa-book\"></i> Mettre à jour et ouvrir le journal")}`;
        } finally { btn.disabled = false; }
    });

    // Tout activer / désactiver
    const boolKeys = boolKeysOf(category);
    const setAll = (v) => boolKeys.forEach(k => {
        if (FROZEN_SETTINGS.has(k)) return;   // ne pas réactiver un réglage gelé
        const el = root.querySelector(`[name="${k}"]`);
        if (el) { el.checked = v; el.disabled = false; el.closest(".scwm-set").style.opacity = "1"; }
    });
    root.querySelector(".scwm-all-on")?.addEventListener("click",  e => { e.preventDefault(); setAll(true); });
    root.querySelector(".scwm-all-off")?.addEventListener("click", e => { e.preventDefault(); setAll(false); });

    // Boutons « Parcourir » (FilePicker) pour les champs d'image.
    root.querySelectorAll(".scwm-filepicker").forEach(btn => btn.addEventListener("click", (e) => {
        e.preventDefault();
        const input = root.querySelector(`[name="${btn.dataset.target}"]`);
        if (!input) return;
        const FP = foundry.applications?.apps?.FilePicker?.implementation ?? globalThis.FilePicker;
        new FP({ type: btn.dataset.fptype || "image", current: input.value, callback: (path) => { input.value = path; } }).browse();
    }));

    // Système d'étoiles : maximum par session (valeur affichée à côté du curseur).
    root.querySelectorAll(".scwm-star-max").forEach(r => r.addEventListener("input", () => {
        const v = r.parentElement?.querySelector(".scwm-star-max-v");
        if (v) v.textContent = `${r.value} ★`;
    }));

    // Registre du monde : taille des épingles (valeur affichée à côté du curseur).
    root.querySelectorAll(".scwm-taille-epingle").forEach(r => r.addEventListener("input", () => {
        const v = r.parentElement?.querySelector(".scwm-taille-epingle-v");
        if (v) v.textContent = `${r.value} px`;
    }));

    // Registre du monde : aperçu de la bannière « Nouveau lieu découvert ».
    root.querySelectorAll(".scwm-test-banniere").forEach(btn => btn.addEventListener("click", (e) => {
        e.preventDefault();
        afficherBanniere(tl("Port de Brume"), root.querySelector(`[name="${btn.dataset.target}"]`)?.value ?? "");
    }));

    // Liste dynamique de cartes d'expédition : + ajoute une ligne, × retire.
    const sceneList = root.querySelector(".scwm-scene-list");
    if (sceneList) {
        const rowsBox = sceneList.querySelector(".scwm-scene-rows");
        sceneList.querySelector(".scwm-scene-add")?.addEventListener("click", (e) => {
            e.preventDefault();
            rowsBox?.insertAdjacentHTML("beforeend", sceneRowHtml(""));
        });
        sceneList.addEventListener("click", (e) => {
            const del = e.target.closest?.(".scwm-scene-del");
            if (!del) return;
            e.preventDefault();
            del.closest(".scwm-scene-row")?.remove();
        });
    }

    // Liste d'intrigues (tags) : + ajoute une ligne, × retire.
    const tagList = root.querySelector(".scwm-tag-list");
    if (tagList) {
        const rowsBox = tagList.querySelector(".scwm-tag-rows");
        tagList.querySelector(".scwm-tag-add")?.addEventListener("click", (e) => {
            e.preventDefault();
            rowsBox?.insertAdjacentHTML("beforeend", tagRowHtml(""));
            rowsBox?.querySelector(".scwm-tag-row:last-child .scwm-tag-input")?.focus();
        });
        tagList.addEventListener("click", (e) => {
            const del = e.target.closest?.(".scwm-tag-del");
            if (!del) return;
            e.preventDefault();
            del.closest(".scwm-tag-row")?.remove();
        });
    }

    // Table du système d'étoiles : total recalculé en direct.
    const starInputs = [...root.querySelectorAll(".scwm-starxp-input")];
    if (starInputs.length) {
        const recompute = () => {
            const total = starInputs.reduce((a, el) => a + Math.max(1, Math.round(Number(el.value) || 3)), 0);
            const set = (sel, v) => { const n = root.querySelector(sel); if (n) n.textContent = String(v); };
            set(".scwm-starxp-total-n", total);
            set(".scwm-starxp-total-s1", total);
            set(".scwm-starxp-total-s2", Math.ceil(total / 2));
            set(".scwm-starxp-total-s3", Math.ceil(total / 3));
        };
        starInputs.forEach(el => el.addEventListener("input", recompute));
        recompute();
    }

    // Progression XP : curseurs liés et tableau recalculé en direct.
    wireXpProg(root);
    // Registre du monde : éditeur des rubriques.
    cablerMonde(root);

    // Cascade Horloge de party : options grisées sans l'interrupteur principal,
    // réglages d'obscurité grisés sans l'obscurité, alerte de faim grisée sans
    // les rations.
    const ptMaster = root.querySelector(`[name="enablePartyTime"]`);
    if (ptMaster) {
        const dark    = root.querySelector(`[name="enablePartyDarkness"]`);
        const rations = root.querySelector(`[name="partyTimeRations"]`);
        const setState = (key, on) => {
            const el = root.querySelector(`[name="${key}"]`);
            if (!el) return;
            el.disabled = !on;
            const box = el.closest(".scwm-set");
            if (box) box.style.opacity = on ? "1" : "0.5";
        };
        const applyPt = () => {
            for (const k of PARTYTIME_SUB_SETTINGS) setState(k, ptMaster.checked);
            for (const k of PARTYDARK_SUB_SETTINGS) setState(k, ptMaster.checked && !!dark?.checked);
            setState("partyTimeHungerWarning", ptMaster.checked && !!rations?.checked);
        };
        ptMaster.addEventListener("change", applyPt);
        dark?.addEventListener("change", applyPt);
        rations?.addEventListener("change", applyPt);
        applyPt();
    }

    // Cascade Party : grise les sous-options quand le maître est décoché.
    const master = root.querySelector(`[name="enableParty"]`);
    if (master) {
        const subs = PARTY_DEPENDENT_SETTINGS
            .map(k => root.querySelector(`[name="${k}"]`))
            .filter(Boolean);
        const apply = () => subs.forEach(cb => {
            cb.disabled = !master.checked;
            const box = cb.closest(".scwm-set");
            if (box) box.style.opacity = master.checked ? "1" : "0.5";
        });
        master.addEventListener("change", apply);
        apply();
    }
}

async function saveCategoryForm(category, root, { silent = false } = {}) {
    if (!root) return false;
    let needsReload = false;
    for (const key of category.keys) {
        const cfg = game.settings.settings.get(`${MOD}.${key}`);
        if (!cfg) continue;
        if (FROZEN_SETTINGS.has(key)) continue;   // réglage gelé : on ne le modifie pas

        // Liste d'intrigues (tags) → tableau de chaînes (nettoyé, dédupliqué).
        if (key === "sessionTags") {
            const container = root.querySelector(`.scwm-tag-list[data-key="${key}"]`);
            const seen = new Set();
            const tags = container
                ? [...container.querySelectorAll(".scwm-tag-input")]
                    .map(i => i.value.trim())
                    .filter(v => v && !seen.has(v.toLowerCase()) && seen.add(v.toLowerCase()))
                : [];
            if (JSON.stringify(game.settings.get(MOD, key) ?? []) !== JSON.stringify(tags)) {
                await game.settings.set(MOD, key, tags);
            }
            continue;
        }

        // Table du système d'étoiles (niveau → étoiles).
        if (key === "starXpLevels") {
            const arr = readStarTableFromForm(root);
            if (JSON.stringify(game.settings.get(MOD, key)) !== JSON.stringify(arr)) {
                await game.settings.set(MOD, key, arr);
            }
            continue;
        }

        // Progression XP (niveau max, curseurs, XP par défaut, plages de bonus).
        if (XP_PROG_KEYS.has(key) || MONDE_KEYS.has(key)) {
            const v = XP_PROG_KEYS.has(key) ? readXpProg(key, root) : lireMonde(key, root);
            if (v !== undefined && JSON.stringify(game.settings.get(MOD, key)) !== JSON.stringify(v)) {
                await game.settings.set(MOD, key, v);
            }
            continue;
        }

        // Tables de temps morts (grille de champs) — reconstruites à part.
        if (TM_TABLE_SCHEMAS[key]) {
            const arr = readTableFromForm(key, root);
            if (JSON.stringify(game.settings.get(MOD, key)) !== JSON.stringify(arr)) {
                await game.settings.set(MOD, key, arr);
            }
            continue;
        }

        // Liste dynamique de cartes d'expédition → tableau d'IDs (dédupliqué).
        if (key === "expeditionMapSceneIds") {
            const container = root.querySelector(`.scwm-scene-list[data-key="${key}"]`);
            const ids = container
                ? [...new Set([...container.querySelectorAll(".scwm-scene-select")].map(s => s.value).filter(Boolean))]
                : [];
            if (JSON.stringify(game.settings.get(MOD, key) ?? []) !== JSON.stringify(ids)) {
                await game.settings.set(MOD, key, ids);
            }
            continue;
        }

        const el = root.querySelector(`[name="${key}"]`);
        if (!el) continue;

        let v;
        if (cfg.type === Boolean)      v = el.checked;
        else if (cfg.type === Number)  { v = Number(el.value); if (Number.isNaN(v)) v = cfg.default ?? 0; }
        else                           v = el.value;
        if (game.settings.get(MOD, key) !== v) {
            await game.settings.set(MOD, key, v);
            if (cfg.requiresReload) needsReload = true;
        }
    }
    if (silent) return needsReload;
    ui.notifications?.info(tl("{0} — réglages enregistrés.", category.title));
    if (needsReload) {
        const ok = await foundry.applications.api.DialogV2.confirm({
            window:  { title: tl("Rechargement requis") },
            content: `<p>${tl("Certains changements nécessitent un rechargement de la page pour s'appliquer. Recharger maintenant ?")}</p>`
        });
        if (ok) window.location.reload();
    }
    return needsReload;
}

function escapeAttr(s) {
    return String(s).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function folderOptionsHtml(currentVal) {
    const all = game.folders.filter(f => f.type === "Actor");
    const walk = (parentId, depth) => all
        .filter(f => (f.folder?.id ?? null) === parentId)
        .sort((a, b) => (a.sort ?? 0) - (b.sort ?? 0) || a.name.localeCompare(b.name))
        .flatMap(f => [
            `<option value="${f.id}" ${f.id === currentVal ? "selected" : ""}>${"  ".repeat(depth * 2)}${depth > 0 ? "└ " : ""}${f.name}</option>`,
            ...walk(f.id, depth + 1)
        ]);
    return [`<option value="">${tl("— aucun —")}</option>`, ...walk(null, 0)].join("");
}

function sceneOptionsHtml(currentVal) {
    return [
        `<option value="">${tl("— Aucune —")}</option>`,
        ...game.scenes.contents.map(s => `<option value="${s.id}" ${s.id === currentVal ? "selected" : ""}>${s.name}</option>`)
    ].join("");
}

// Liste d'intrigues (tags de rapports) — rangées de champs texte + / −.
function tagRowHtml(val = "") {
    return `<div class="scwm-tag-row" style="display:flex;gap:4px;margin-bottom:4px;">
        <input type="text" class="scwm-tag-input" value="${escapeAttr(val)}" placeholder="${tl("Nom de l'intrigue…")}" style="flex:1 1 auto;min-width:0;">
        <button type="button" class="scwm-tag-del" title="${tl("Retirer cette intrigue")}"
                style="flex:0 0 auto;width:30px;border-radius:4px;cursor:pointer;
                       border:1px solid rgba(192,57,43,0.4);background:rgba(192,57,43,0.12);color:#e58f8f;">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>`;
}
function tagListControlHtml() {
    const tags = (game.settings.get(MOD, "sessionTags") || []).filter(Boolean);
    const rows = tags.map(t => tagRowHtml(t)).join("");
    return `<div class="scwm-set" data-key="sessionTags" style="padding:8px 4px;border-bottom:1px solid rgba(255,255,255,0.06);">
        <label style="display:block;font-weight:600;margin-bottom:4px;">${tl("Intrigues (tags de rapports)")}</label>
        <p style="margin:0 0 6px;font-size:.8em;color:#999;">${tl("Liste d'intrigues/trames que le MJ pourra cocher sur ses rapports de session, pour relier plusieurs quêtes (récompense finale, joueurs liés, recrutement…).")}</p>
        <div class="scwm-tag-list" data-key="sessionTags">
            <div class="scwm-tag-rows">${rows}</div>
            <button type="button" class="scwm-tag-add"
                    style="margin-top:2px;padding:3px 10px;border-radius:4px;cursor:pointer;
                           border:1px solid rgba(201,162,39,0.4);background:rgba(201,162,39,0.12);color:#c9a227;">
                ${tl("<i class=\"fa-solid fa-plus\"></i> Ajouter une intrigue")}
            </button>
        </div>
    </div>`;
}

// Une ligne « carte supplémentaire » : sélecteur de scène + bouton retirer.
function sceneRowHtml(selectedId = "") {
    return `<div class="scwm-scene-row" style="display:flex;gap:4px;margin-bottom:4px;">
        <select class="scwm-scene-select" style="flex:1 1 auto;min-width:0;">${sceneOptionsHtml(selectedId)}</select>
        <button type="button" class="scwm-scene-del" title="Retirer cette carte"
                style="flex:0 0 auto;width:30px;border-radius:4px;cursor:pointer;
                       border:1px solid rgba(192,57,43,0.4);background:rgba(192,57,43,0.12);color:#e58f8f;">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>`;
}

// Menu déroulant des compendiums (valeur = collection). docType filtre le type
// de document (Actor par défaut ; Item pour les objets craftables).
function packOptionsHtml(currentVal, docType = "Actor") {
    const packs = game.packs.filter(p => p.documentName === docType)
        .sort((a, b) => (a.title ?? a.metadata?.label ?? "").localeCompare(b.title ?? b.metadata?.label ?? ""));
    return [
        `<option value="">${tl("— aucun —")}</option>`,
        ...packs.map(p => {
            const label = p.title ?? p.metadata?.label ?? p.collection;
            return `<option value="${p.collection}" ${p.collection === currentVal ? "selected" : ""}>${escapeAttr(label)}</option>`;
        })
    ].join("");
}
