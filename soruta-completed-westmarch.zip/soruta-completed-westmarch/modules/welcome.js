// ============================================================
// welcome.js — Fenêtre de bienvenue
// ============================================================

import { startTutorial, SECTION_LABELS, SECTION_ICONS, SETTING_KEYS, isSectionAvailable, SECTION_ESSENTIAL } from './tutorial.js';
import { Dialog } from "./compat.js";

import { MOD } from "./const.js";
import { tl } from "./i18n.js";
const MODULE = MOD;

/**
 * Affiche la fenêtre de bienvenue uniquement si l'utilisateur
 * n'a pas choisi "Ne plus afficher".
 */
export function showWelcomeIfNeeded() {
    if (!game.settings.get(MODULE, "tutoEnabled")) return;
    if (!game.settings.get(MODULE, "showWelcome")) return;  // GM a désactivé pour tout le monde
    if (game.settings.get(MODULE, "hideWelcome"))  return;  // cet utilisateur a cliqué "Ne plus afficher"
    showWelcome();
}

/**
 * Affiche le sélecteur de sections (bouton toolbar).
 * Permet de choisir quelles parties du tutoriel revoir.
 */
// Sections déjà parcourues pendant cette session (pour la coche du menu).
const _doneSections = new Set();

/**
 * Parcours guidé : lance d'abord les sections ESSENTIELLES à la suite (comme
 * l'ancien tutoriel), puis ouvre le MENU pour les sections optionnelles.
 */
export function startEssentialsThenHub() {
    const essential = Object.entries(SECTION_LABELS)
        .filter(([k]) => isSectionAvailable(k) && SECTION_ESSENTIAL.has(k))
        .map(([k]) => k);
    if (!essential.length) { showTutorialHub(); return; }
    startTutorial(essential, () => {
        essential.forEach(k => _doneSections.add(k));
        showTutorialHub();
    });
}

/**
 * MENU du guide : liste les sections. On clique une section → on la fait → on
 * revient ici. On répète jusqu'à fermer (croix) ou « Ne plus afficher ».
 * C'est le mode recommandé : chacun ne fait que ce qui l'intéresse.
 */
export function showTutorialHub() {
    const entries = Object.entries(SECTION_LABELS).filter(([k]) => isSectionAvailable(k));

    const rowHtml = ([key, label]) => {
        const icon = SECTION_ICONS[key] ?? "fa-circle";
        const done = _doneSections.has(key);
        return `
        <button type="button" class="tuto-hub-row" data-section="${key}"
                style="display:flex;align-items:center;gap:10px;width:100%;text-align:left;
                       padding:7px 10px;border-radius:5px;cursor:pointer;
                       border:1px solid rgba(201,162,39,0.25);
                       background:${done ? "rgba(143,209,158,0.08)" : "rgba(201,162,39,0.07)"};color:inherit;">
            <i class="fas ${icon}" style="width:18px;text-align:center;color:#c9a227;"></i>
            <span style="flex:1;">${label}</span>
            ${done
                ? '<i class="fa-solid fa-check" style="color:#8fd19e;"></i>'
                : '<i class="fa-solid fa-chevron-right" style="opacity:.4;"></i>'}
        </button>`;
    };

    const essential = entries.filter(([k]) => SECTION_ESSENTIAL.has(k));
    const optional  = entries.filter(([k]) => !SECTION_ESSENTIAL.has(k));

    const groupHtml = (title, sub, color, arr) => arr.length ? `
        <div style="margin-top:4px;">
            <div style="font-size:11px;text-transform:uppercase;letter-spacing:.05em;color:${color};margin:8px 2px 3px;font-weight:700;">
                ${title} <span style="opacity:.65;font-weight:400;text-transform:none;letter-spacing:0;">${sub}</span>
            </div>
            <div style="display:flex;flex-direction:column;gap:5px;">${arr.map(rowHtml).join("")}</div>
        </div>` : "";

    const content = `
    <div class="tuto-hub-body">
        <p style="margin:0 0 8px;font-size:13px;">
            ${tl("Chaque section est courte, et tu <strong>reviens à ce menu</strong> après.\n            Commence par les sections <strong style=\"color:#8fd19e;\">à connaître</strong> ;\n            le reste est optionnel. Ferme la fenêtre (croix) quand tu as fini.")}
        </p>
        <p style="margin:0 0 8px;color:#e0a13a;font-size:12px;display:flex;gap:6px;align-items:flex-start;">
            <i class="fa-solid fa-triangle-exclamation" style="margin-top:2px;"></i>
            <span>${tl("Ferme les fiches/fenêtres ouvertes avant : le guide ouvre lui-même celles qu'il explique.")}</span>
        </p>
        <div class="tuto-hub-list" style="max-height:52vh;overflow-y:auto;padding-right:4px;">
            ${(essential.length || optional.length)
                ? groupHtml(tl("À connaître"), "(essentiel)", "#8fd19e", essential)
                  + groupHtml(tl("Optionnel"), tl("(pour aller plus loin)"), "#c9a227", optional)
                : `<p style="opacity:.7;">${tl("Aucune section disponible.")}</p>`}
        </div>
    </div>`;

    let dlg;
    dlg = new Dialog({
        title:   tl("Guide du serveur"),
        content,
        buttons: {
            essentials: {
                icon:  '<i class="fa-solid fa-star"></i>',
                label: tl("Les essentiels"),
                callback: () => startTutorial(essential.map(([k]) => k), () => {
                    essential.forEach(([k]) => _doneSections.add(k));
                    showTutorialHub();
                })
            },
            all: {
                icon:  '<i class="fa-solid fa-list-check"></i>',
                label: tl("Tout faire"),
                callback: () => startTutorial(entries.map(([k]) => k), () => {
                    entries.forEach(([k]) => _doneSections.add(k));
                    showTutorialHub();
                })
            },
            hide: {
                icon:  '<i class="fa-solid fa-eye-slash"></i>',
                label: tl("Ne plus afficher à la connexion"),
                callback: () => {
                    game.settings.set(MODULE, "hideWelcome", true);
                    ui.notifications.info(tl("[Guide] La fenêtre d'accueil ne s'affichera plus. Bouton « ? » dans la barre WestMarch pour rouvrir le menu."));
                }
            },
            close: { icon: '<i class="fa-solid fa-times"></i>', label: tl("Fermer") }
        },
        default: "close",
        render: (html) => {
            const root = html instanceof HTMLElement ? html : html?.[0];
            if (!root) return;
            root.querySelectorAll(".tuto-hub-row").forEach(btn => btn.addEventListener("click", () => {
                const key = btn.dataset.section;
                try { dlg.close(); } catch {}
                // Lance la section ; au retour (fin/croix/Échap), on rouvre le menu.
                startTutorial([key], () => { _doneSections.add(key); showTutorialHub(); });
            }));
        }
    }, {
        width:   420,
        classes: ["dialog", "tuto-hub-dialog"]
    });
    dlg.render(true);
}

/**
 * Affiche la fenêtre de bienvenue (appelable depuis le bouton toolbar).
 */
// Textes de la fenêtre de bienvenue (réglages du MJ). Mise en forme minimale et
// sûre : le texte est échappé, puis **mot** → gras et retour à la ligne → <br>.
const TEXTES_BIENVENUE = ["welcomeWindowTitle", "serverName", "welcomeText", "welcomeWarning", "welcomeStartLabel"];
function texteBienvenue(key) {
    try { return String(game.settings.get(MODULE, key) ?? ""); } catch { return ""; }
}
function miseEnForme(texte) {
    return foundry.utils.escapeHTML(texte.trim())
        .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
        .replace(/\r?\n/g, "<br>");
}

/**
 * Fige les textes de bienvenue : tant qu'un texte n'a jamais été enregistré,
 * Foundry affiche sa valeur par défaut, traduite dans la langue de CHAQUE
 * utilisateur. Au premier chargement par le MJ actif, on enregistre la valeur
 * affichée : elle devient le texte du serveur, identique pour tous et
 * indépendant de la langue, modifiable dans Réglages → Tutoriel.
 */
export async function figerTextesBienvenue() {
    if (!game.user?.isGM || game.users?.activeGM?.id !== game.user.id) return;
    const monde = game.settings.storage?.get?.("world");
    for (const key of TEXTES_BIENVENUE) {
        const id = `${MODULE}.${key}`;
        const deja = monde?.getSetting?.(id) ?? monde?.find?.(x => x.key === id);
        if (deja) continue;
        try { await game.settings.set(MODULE, key, texteBienvenue(key)); } catch { /* droits */ }
    }
}

export function showWelcome() {
    const titre   = texteBienvenue("serverName").trim();
    const texte   = texteBienvenue("welcomeText");
    const avert   = texteBienvenue("welcomeWarning");
    const fenetre = texteBienvenue("welcomeWindowTitle").trim() || tl("Bienvenue");
    const bouton  = texteBienvenue("welcomeStartLabel").trim() || tl("Commencer");

    const content = `
    <div class="tuto-welcome-body">
        <div class="tuto-welcome-icon">
            <i class="fa-solid fa-scroll"></i>
        </div>
        ${titre ? `<h2 class="tuto-welcome-title">${foundry.utils.escapeHTML(titre)}</h2>` : ""}
        ${texte.trim() ? `<p class="tuto-welcome-text">${miseEnForme(texte)}</p>` : ""}
        ${avert.trim() ? `<p class="tuto-welcome-warn" style="margin-top:8px;color:#e0a13a;font-size:12px;">
            <i class="fa-solid fa-triangle-exclamation"></i> ${miseEnForme(avert)}
        </p>` : ""}
    </div>`;

    new Dialog({
        title:   fenetre,   // DialogV2 échappe lui-même le titre
        content,
        buttons: {
            start: {
                icon:     '<i class="fa-solid fa-play"></i>',
                label:    bouton,    // DialogV2 échappe lui-même le libellé
                callback: () => startEssentialsThenHub()
            }
        },
        default: "start"
    }, {
        width:   460,
        classes: ["dialog", "tuto-welcome-dialog"]
    }).render(true);
}
