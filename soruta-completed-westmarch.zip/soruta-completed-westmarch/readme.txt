================================================================================
                   SORUTA — COMPLETED WESTMARCH
                   Module Foundry VTT — Privé
================================================================================

Version : 6.8.4
Auteur  : Soruta (Discord : s0ruta)
Système : dnd5e sur Foundry VTT v13+ (ciblé v14)
Accès   : © 2026 Soruta — Tous droits réservés. Usage personnel autorisé.
          Toute redistribution, modification ou usage commercial est
          strictement interdit sans autorisation écrite.

--------------------------------------------------------------------------------
DESCRIPTION
--------------------------------------------------------------------------------

Module West March unifié. Regroupe en un seul paquet l'ensemble des anciens
modules Soruta, jusque-là distribués séparément :

  westmarch · serveur · toolkit · relations · bestiaire
  carnet · carte-expeditions · midi-range-fix · tutoriel

Toutes les fonctionnalités restent activables / désactivables individuellement
depuis les paramètres du module. Les données (settings et flags) sont désormais
regroupées sous un identifiant unique : "soruta-completed-westmarch".

Le module a depuis été enrichi de nombreuses fonctions West March propres au
serveur : Casier du MJ (tableau de bord), validation des personnages (demande,
verrouillage, montée de niveau, limites & stock), cues audio de mise en scène,
onglet Note GM privé, statut de disponibilité des PJ, pause de party, et un
regroupement central des dossiers/compendiums communs (« Dossiers & Compendiums »).

MIGRATION AUTOMATIQUE — Au premier chargement par un GM, le module reprend
automatiquement toutes les données des anciens modules (réglages + flags sur
les acteurs, scènes, tokens, joueurs, objets, journaux, pages et combats) et
les recopie sous le nouvel identifiant. Opération non destructive (les anciennes
données sont laissées en place) et exécutée une seule fois. Voir migration.js.

--------------------------------------------------------------------------------
ARCHITECTURE
--------------------------------------------------------------------------------

index.js
   Point d'entrée unique. Enregistre les helpers Handlebars, les settings, puis
   initialise toutes les features au hook "init" (et Midi Range Fix + fenêtre de
   bienvenue au hook "ready"). Lance la migration au premier "ready" GM.

modules/const.js
   Constantes partagées : MOD (namespace unique), LEGACY_IDS (anciens modules,
   pour la migration), TUTO_TOGGLES (sections du tutoriel).

modules/licence.js
   Licence par clé, validée par le serveur licence.altheia.eu. Le MJ saisit sa
   clé une fois ; le serveur renvoie un jeton signé (RSA, SHA-256) lié au monde
   et valable 7 jours, renouvelé chaque jour par le MJ actif. Serveur
   injoignable → le jeton reste valable jusqu'à son échéance. Signature vérifiée
   par Web Crypto, ou en JavaScript pur sur un serveur Foundry servi en HTTP.

modules/site.js
   Lien vers la page du module sur le site (altheia.eu/foundry-modules.html) :
   message privé aux MJ dans le chat au premier lancement puis après chaque
   mise à jour (une fois par version et par monde), et lien dans « À propos ».

modules/settings.js
   Tous les paramètres des 9 anciens modules sous un namespace unique. Les clés
   en collision ont été préfixées par domaine (relations*, bestiary*, carnet*,
   rangeFix*, tuto*). Bannière, séparateurs de sections, sélecteurs de dossiers
   et de scène, cascade visuelle du système de Party.

modules/migration.js
   Reprise automatique des settings et des flags des anciens modules vers MOD.
   Remappe la seule clé de flag en collision : "list" → "relationsList" /
   "bestiaryList". Idempotente (suivi via le setting "migrationVersion").

FICHE PERSONNAGE
   character-sheet.js  — Une seule sous-classe dnd5e (PARTS/TABS) composant les
                         onglets Relations / Bestiaire / Carnet / Expéditions et
                         Note GM (privé, GM) selon les settings activés. Masque
                         aussi l'onglet « étoile » aux joueurs (option).
   relations.js        — Système de relations entre acteurs (flag relationsList).
   bestiary.js         — Bestiaire par personnage (flag bestiaryList).
   carnet.js           — Onglets Carnet (notes ProseMirror) et Expéditions
                         (dates + durée), bouton "Date Expédition" dans la barre.
   pcstatus.js         — Badge de disponibilité des PJ (Disponible / En expédition)
                         dans le répertoire des Acteurs, déduit des expéditions.

WESTMARCH CORE
   chat.js combat.js player.js playerlist.js session.js anticheat.js scenes.js
   journal.js image.js audio.js document.js socket.js partypause.js connstats.js
   — Party, filtrage du chat, combat par party (blocage de mouvement hors tour
     natif), pause de party (remplace le pause global, banner natif), liste des
     joueurs compacte, journal / clôture de session, anti-cheat, téléportation
     de groupe, partage d'images, stats de connexion, audio cloisonné par party.
   homebrew.js  — Menu des réglages donnant l'adresse de la source homebrew
                  Plutonium propre au serveur.
   partytime.js — Horloge de party : date propre à chaque party pendant
                  l'expédition, avance par heures / jours, consommation des
                  rations, rattrapage du calendrier global à la clôture,
                  obscurité des scènes selon l'heure de la party.

GESTION DES PERSONNAGES & MENEUR
   casier.js         — Tableau de bord du MJ (bouton WestMarch) : onglets
                       Dashboard, Rapports, Expéditions, Temps morts (validation
                       embarquée), Validation des personnages, Monde, Où ranger
                       quoi ?, Suivi des GM.
   rangement.js      — « Où ranger quoi ? » : guide de rangement des PJ, PNJ,
                       créatures, lieux… généré depuis les réglages réels, avec
                       vérification du monde et journal MJ tenu à jour.
   monde.js          — Registre du monde : fiches PNJ / lieux / organisations de
                       Monk's Enhanced Journal rédigées sur un modèle commun
                       (rubriques réglables, secrets MJ natifs), liées aux acteurs,
                       aux scènes et entre elles (relations MEJ), relations PJ
                       recopiées, historique alimenté à la clôture de session.
   charvalidation.js — Cycle de vie des PJ : demande de création → validation GM
                       (acteur créé dans « Joueurs / <joueur> », propriétaire =
                       joueur), construction, soumission, verrouillage sélectif
                       (construction bloquée / jeu libre), montée de niveau
                       validée, limites de persos et système de stock (Observateur).

MISE EN SCÈNE
   sceneaudio.js     — Cues audio (bouton WestMarch, GM) : sons préparés avec
                       seconde de départ / volume / fondu, déclencheurs (manuel,
                       révélation d'un token, début de combat), lecture locale par
                       party (faible latence), navigateur de playlists monde/compendiums.

SERVEUR
   tm.js         — Temps morts (gain de compétence + artisanat ; ajout automatique
                   de l'objet fabriqué depuis un compendium ; validation dans le Casier).
   xp.js         — Blocage XP / Level Up côté joueur (levé pendant la création d'un
                   perso et lors d'une montée de niveau validée par le MJ).
   xpprogress.js — Progression par l'XP de base (D&D 5e) : tableau de progression
                   dynamique, curseurs de rythme et de quantité d'XP, XP par défaut
                   et bonus de plage dans « Clore la session », niveau max du
                   serveur (XP plafonnée, montée bloquée, étoiles comprises).
   caldate.js    — Notification Discord au changement de date (API calendrier
                   native game.time.calendar — Mini Calendar, etc.).
   discordlog.js — Logs Discord des modifications (objets, monnaie, XP, persos).
   fake-warning.js + serveur-socket.js — Faux message d'avertissement GM (queries v13).

TOOLKIT
   rage.js goliath.js polymorph.js token.js items.js tgcm.js foldermove.js
   mejshop.js mejrestock.js export-dialog.js template.js
   — Tailles Large (Rage/Goliath), transformation de token, apparences multiples,
     protégé TGCM, correction stat des outils, déplacer/dupliquer, correctifs et
     réapprovisionnement des boutiques MEJ, export "fiche originale", snap AoE.

CARTE / MIDI / TUTORIEL
   map.js        — Carte des expéditions (fog par party et par personnage).
   range-fix.js  — Correction de portée midi-qol pour tokens Large+.
   tutorial.js welcome.js toolbar.js — Fenêtre de bienvenue + tutoriel interactif.

templates/   — Onglets de fiche (character-relations / bestiary / journal /
               downtime / gmnotes .hbs).
styles/      — Feuilles de style de toutes les features (dont casier, charvalidation,
               sceneaudio, pcstatus, gmnotes, partypause, connstats, playerlist).

--------------------------------------------------------------------------------
DÉPENDANCES
--------------------------------------------------------------------------------

Obligatoire :
  - dnd5e v3+ (système de jeu)

Optionnelles (une feature se désactive silencieusement si absente) :
  - midi-qol            — requis par Midi Range Fix
  - Monk's Enhanced Journal — requis par les correctifs et le restock des boutiques
  - Mini Calendar       — calendrier du monde (dates du Carnet, notif Discord de
                          changement de jour). Le module lit l'API native
                          game.time.calendar : tout module de calendrier v13
                          (Mini Calendar, etc.) convient, aucune dépendance figée.
  - lib-wrapper         — snap live des templates AoE

Le blocage de mouvement hors tour en combat est désormais natif (setting
"Blocage de mouvement hors tour") : Monk's TokenBar n'est plus nécessaire.

--------------------------------------------------------------------------------
PARAMÈTRES CONFIGURABLES
--------------------------------------------------------------------------------

Paramètres du jeu → Configuration des modules → Soruta — Completed Westmarch

Regroupés par section : Dossiers & Compendiums · Système de Party ·
Création de personnages · Serveur (dont Note GM) · Temps morts · Toolkit ·
Fiche PJ (Relations / Bestiaire / Carnet) · Carte des expéditions ·
Mise en scène — Cues audio · Midi Range Fix · Tutoriel.

La section « Dossiers & Compendiums » centralise, à un seul endroit, les dossiers
et compendiums communs (PJ, PNJ, cimetière, créatures, objets craftables, dossier
des nouveaux personnages) utilisés par toutes les fonctions.

--------------------------------------------------------------------------------
NOTE DE FUSION (clés renommées)
--------------------------------------------------------------------------------

Collisions résolues lors de la fusion :
  Settings :
    relations (enabled/anonymization/folderPJ/folderPNJ/folderCreatures)
      → relationsEnabled / relationsAnonymization / relationsFolderPJ / …
    bestiaire (enabled/anonymization/folderPJ/packCreatures/folderCreatures)
      → bestiaryEnabled / bestiaryAnonymization / bestiaryFolderPJ / …
    carnet.enabled              → carnetEnabled
    midi-range-fix.enabled      → rangeFixEnabled  (rangeAdjust inchangé)
    tutoriel.<toggles>          → tuto<Toggle>      (serverName/showWelcome inchangés)
  Flags :
    relations « list »          → relationsList
    bestiaire « list »          → bestiaryList
    (toutes les autres clés convergent sans conflit : partyId, tm,
     carnetNotes, expeditions, tgcm, polymorphForms, images, restock, etc.)

--------------------------------------------------------------------------------
COMPTES JOUEURS
--------------------------------------------------------------------------------

Les comptes joueurs (non-GM) ne peuvent pas exécuter de commandes console.
Tout diagnostic doit passer par le compte GM en reproduisant l'interaction UI.

================================================================================
                   COMPLETED WESTMARCH — MISES À JOUR
================================================================================

v6.8.4 | 2026-11-17
   - Poids du monde, colonne « Format » : affiche en gras le format du
     fichier PRINCIPAL (fond d'une scène, image d'un acteur ou d'un objet),
     et seulement le nombre des autres formats (tuiles, objets…) avec le
     détail au survol. Avant, une scène listait pêle-mêle les formats de son
     fond et de toutes ses tuiles. Fichier : modules/casier.js.
   - Correctif Monk's Enhanced Journal : avec MEJ 14.x actif, plus rien ne
     pouvait être envoyé dans un compendium (glisser-déposer d'une playlist,
     d'un acteur, d'un objet… sans effet ; erreur « can't access property
     "type", object is undefined » dans fixType). MEJ remplace
     CompendiumCollection#importDocument et y appelle fixType(this.object),
     propriété qui n'existe pas sur un compendium. Le module fait ignorer à
     fixType un objet absent ; le reste de MEJ est inchangé. Réglage :
     enableMejCompendiumFix (activé). Fichiers : modules/mejfix.js
     (nouveau), modules/settings.js, index.js.

v6.8.3 | 2026-11-17
   - Casier, Poids du monde : colonne « Formats » (extensions des médias de
     chaque élément, la plus lourde d'abord) et nouveau tableau « Par format
     de fichier » (nombre de fichiers, poids et part du total pour .webp,
     .png, .jpg, .ogg…, chaque fichier compté une fois). Repère d'un coup
     les formats lourds à convertir. Fichiers : modules/casier.js,
     modules/i18n-en.js.
   - Menu du guide : le bouton « Ne plus afficher à la connexion » débordait
     toujours. La correction de 6.8.1 visait une classe de bouton qui
     n'existe pas dans ces fenêtres (DialogV2) ; elle vise maintenant leurs
     vrais boutons. Fichier : styles/tutoriel.css.

v6.8.2 | 2026-11-17
   - Fenêtre de bienvenue : le texte du bouton et le titre de la fenêtre
     affichaient les apostrophes sous la forme « &#x27; » (échappés deux
     fois). Fichier : modules/welcome.js.
   - Casier : boutons « Réinitialiser » retirés des onglets Rapports,
     Assiduité et Expéditions (ils faisaient doublon et permettaient à
     n'importe quel MJ d'effacer les données de tous). Le ménage se fait
     uniquement par « Préparer l'ouverture du serveur » (réglages,
     Administration du module, mot de passe admin), qui couvre les mêmes
     données case par case. Fichiers : modules/casier.js,
     modules/adminpass.js (liste des actions protégées mise à jour).
   - Carnet : nouvelle police des notes, « Immortal » (fonts/Immortal.ttf),
     à la place de Perry Gothic (éditeur, titres et texte des notes).
   - Tutoriel, Échange entre joueurs : la 1re étape ne cible plus la liste
     des joueurs (le cadrage tombait mal) ; elle explique au centre de
     l'écran où trouver l'icône d'échange et quand elle apparaît.

v6.8.1 | 2026-11-17
   - Sorts d'enchantement d'arme (True Strike, Magic Weapon, Shillelagh…) :
     au lancement, plus besoin de glisser l'arme dans la carte de chat.
     Une seule arme équipée : elle est enchantée directement ; plusieurs :
     une fenêtre liste les armes acceptées par le sort, la dernière choisie
     est présélectionnée (« Plus tard » laisse la zone de dépôt du chat).
     L'enchantement précédent du même sort sur les armes du personnage est
     retiré avant (pas de « (True Strike) (True Strike) »). Durée,
     concentration et fin de l'effet restent celles de dnd5e. Réglage :
     Modifications ciblées → Sorts → Enchantements d'arme.
   - Tutoriel : une section décochée dans « Sections du tutoriel » n'est
     plus proposée nulle part (le menu du guide et le parcours des
     essentiels l'affichaient quand même). La section Temps morts suit
     aussi l'interrupteur des Temps morts, et la section Casier celui du
     Casier du MJ.
   - Tutoriel : étape « Intrigues » du Casier retirée (l'onglet n'existe
     plus ; les intrigues restent présentées à la clôture de session et
     dans les rapports en attente).
   - Tutoriel, Carte des expéditions : la section commence par afficher la
     première carte configurée (scène principale, sinon la première carte
     ajoutée). Simple affichage pour le MJ : la scène n'est pas activée,
     les joueurs ne sont pas déplacés.
   - Tutoriel, Carte des expéditions, étape « Le token de groupe » : ouvre
     l'onglet Acteurs, déplie le dossier du token modèle « Token à copier et
     rennomer » et le surligne. Le surlignage d'une étape est retiré à
     l'étape suivante et à la fermeture du tutoriel.
   - Tutoriel, étape « Statut de disponibilité » : déplie bien le dossier
     « Tutoriel » (et ses parents) pour montrer le badge sur le personnage
     de démonstration. Le dépliage des dossiers du tutoriel est fiabilisé
     pour Foundry v13+ (il ne marchait qu'avec l'ancien balisage) : vaut
     aussi pour le dossier Panthéons et le token de groupe.
   - Menu du guide et fenêtre de bienvenue : les boutons à libellé long
     (« Ne plus afficher à la connexion »…) débordaient en haut et en bas.
     Hauteur libre avec retour à la ligne ; le menu range ses 4 boutons en
     grille 2 × 2. Fichier : styles/tutoriel.css.
   - Fenêtre de bienvenue entièrement personnalisable par le MJ (Réglages
     → Tutoriel) : titre de la fenêtre, titre principal, texte,
     avertissement et texte du bouton. Texte et avertissement : zone
     multi-ligne, Entrée pour aller à la ligne, **mot** pour le gras ;
     laissés vides, ils ne s'affichent pas. Au premier chargement par le
     MJ, les textes affichés sont enregistrés comme textes du serveur : ils
     ne changent plus avec la langue de chacun.
   - Tutoriel, Panthéons : surligne le bon dossier, celui du journal des
     Dieux créé par le module (la recherche par texte pouvait tomber sur un
     dossier parent, ou sur le premier dossier venu).
   - Tutoriel : les étapes d'une fonctionnalité désactivée sur le serveur
     ne sont plus montrées (Date d'expédition, statut de disponibilité,
     clôture de session et rapports, Temps morts et Validation dans le
     Casier, boutiques MEJ, portrait / apparence / polymorph des tokens,
     faux message, outils de chat, TGCM, blocage XP, logs Discord, export).
     Les fonctionnalités gelées par le module (apparence des tokens, TGCM)
     comptent comme désactivées. Une section dont toutes les étapes sont
     masquées disparaît du menu du guide.
   - Indicateur « géré » sur les fiches (engrenages dorés) : la bulle
     affiche le nom du module (« Géré par Soruta — Completed Westmarch : »)
     au lieu de « Géré par le module ».
   - Tutoriel : nouvelle section « HUD du token » (joueurs et MJ), sans
     token requis : une fenêtre explicative « Boutons du HUD » montre
     chaque symbole et son rôle — boutons de Foundry (visibilité, combat,
     cible, états, mode de déplacement, élévation, barres), puis ceux du
     module, seulement si leur fonction est active et non gelée (portrait,
     forme sauvage / polymorphie, récolte ; MJ : accrocher, cues, TGCM).
     Pour le MJ, la ligne « Accrocher » explique porter, mener et le
     décrochage (fonction présentée nulle part ailleurs). Réglage :
     Tutoriel → HUD du token.
   - Accrocher un token (porter / mener) — corrections :
     · Mener : le token mené s'arrêtait parfois à cheval entre deux cases
       et trop près (diagonales coupées en demi-cases) ; distances comptées
       en cases (diagonale = 1) et positions calées sur la grille.
     · Accrocher un 2e token au même PJ ajoutait un détour dans la piste
       commune : le token déjà mené le suivait ensuite.
     · Après un rechargement ou un changement de MJ, le premier
       déplacement du token mené filait en ligne droite (à travers les
       murs) : la piste repart maintenant du point de départ du PJ.
     · Deux déplacements rapprochés du PJ pouvaient décrocher le token tout
       seul ou lancer deux animations concurrentes : déplacements traités
       l'un après l'autre, marquage par compteur.
     · Lecture du trajet adaptée au format de mouvement de Foundry v13+.
     · Un changement d'élévation seul du PJ est suivi par ses accrochés.
   - Horloge de party : hors combat, barre fine centrée en haut de l'écran
     (soleil / lune, heure avec secondes, date, Party ou Monde, pause). À
     droite, bouton qui ouvre le calendrier : vue du mois de la date de la
     party (ou du monde), jour courant mis en avant, fêtes du calendrier du
     serveur signalées, navigation de mois en mois. Pour le MJ : à gauche
     « Jour suivant » (+1 jour, rations comprises), et un curseur (0 à 12 h,
     par 10 min) avec un bouton de validation pour avancer le temps. Hors
     expédition, ces boutons avancent le calendrier du monde. En combat,
     l'horloge reprend sa place à droite de la liste des joueurs (le
     carrousel de combat occupe le haut de l'écran).
   - Tutoriel : nouvelle section « Horloge & calendrier » (barre du temps,
     Party / Monde, calendrier ; MJ : jour suivant et curseur ; place de
     l'horloge en combat). Montrée seulement si l'horloge de party et son
     affichage sont actifs. Réglage : Tutoriel → Horloge de party.
   - Tutoriel : nouvelle section MJ « Registre du monde » (15 étapes),
     Casier ouvert sur l'onglet Monde : à quoi sert le registre entre MJ,
     créer une fiche (et les autres portes d'entrée), où elles sont
     rangées, les rubriques et les secrets MJ, ne pas écrire dans Monk's,
     liens d'un PNJ (acteur, lieu, relations des PJ), épingle et cartes
     locales d'un lieu, ce que voient les joueurs (découverte), la liste et
     ses icônes, recherche et « Modifiées depuis ma dernière session »,
     Actualiser, Ranger dans les compendiums, Supprimer, et les règles d'or
     entre MJ. Montrée si le registre est actif et Monk's Enhanced Journal
     installé. Réglage : Tutoriel → Registre du monde.
   - Nouveau : anniversaires. Le jour de l'anniversaire d'un PJ, un message
     de fête (🎂, portrait, âge si l'année de naissance est connue) apparaît
     dans le chat. Date réglée avec le bouton gâteau de l'en-tête de la
     fiche ou le clic droit sur l'acteur → « Date d'anniversaire » (le
     joueur pour son PJ, le MJ pour tous). En expédition, la date de la
     party fait foi ; sinon le calendrier du monde. Plusieurs jours avancés
     d'un coup : chaque jour est vérifié. Option : les PNJ aussi.
     Réglages : catégorie « Anniversaires ».
   - « Forcer la reprise » quitte la barre WestMarch : c'est maintenant un
     bouton « Débloquer la pause » dans les réglages du module (MJ). Même
     effet : enlève la pause globale et toutes les pauses de party.
   Fichiers : modules/enchantarme.js (nouveau), modules/anniversaire.js
   (nouveau), modules/partytime.js, modules/caldate.js, modules/settings.js,
   modules/i18n-en.js, modules/tutorial.js, modules/partypause.js, index.js.

v6.8.0 | 2026-11-11
   - Casier, onglet Monde : corbeille sur chaque fiche (PNJ, lieu,
     organisation). Confirmation, puis suppression de l'entrée (monde ou
     compendium déverrouillé) et nettoyage de ce qui la désignait :
     relations Monk's des autres fiches, lien « fichePage » des acteurs et
     scènes. Options : retirer ses épingles sur les cartes (coché par
     défaut), supprimer aussi l'acteur lié d'un PNJ (décoché par défaut).
   - Réglages personnels enregistrés par COMPTE (portée « user ») et non
     plus par navigateur (« client ») : deux comptes ouverts sur le même
     ordinateur (MJ et joueur) ne les partagent plus, et un joueur les
     retrouve depuis un autre appareil. Concerne : Langue du module (avec
     une copie locale pour le tout début du chargement), Accessibilité
     (daltonisme, contraste et couleur des contours, avatars,
     auto-masquage, contrôles compacts, indicateur « géré », Health
     Estimate, horloge de party), FunnyStats, couleur des cartes de chat,
     « Désactiver mes rappels de combat », « Ne plus afficher » l'accueil.
     Restent par navigateur : mode verbeux, statistiques de connexion,
     repli de la liste des joueurs. Les choix déjà faits avec l'ancienne
     version sont à refaire une fois.
   Fichiers : modules/monde.js, modules/i18n.js, modules/accessibility.js,
   modules/settings.js, modules/funnystats.js, modules/i18n-en.js.

v6.7.9 | 2026-11-09
   - FunnyStats : une attaque qui atteignait la CA pouvait être comptée comme
     ratée avec Midi-QOL (sa liste de cibles touchées peut être vidée avant
     la fin du déroulé). Une cible compte maintenant comme touchée si Midi
     l'a marquée touchée OU si le total d'attaque atteint sa CA ; critique :
     touchée ; échec critique : ratée.
   Fichiers : modules/funnystats.js.

v6.7.8 | 2026-11-09
   - FunnyStats, corrections :
     « Annulés » devient « Résistés » (dégâts réduits par résistances,
     immunités, réductions). Ils étaient comptés à chaque APERÇU de la
     carte « Appliquer les dégâts », sur chaque client : chiffre très
     gonflé. Désormais seul le dernier calcul de l'acteur compte, une fois,
     quand les dégâts sont vraiment appliqués (dnd5e.applyDamage, ou
     dnd5e.damageActor sur le client qui a fait la mise à jour).
     « Absorbés » devient « Abs. PV temp. » (dégâts encaissés par les PV
     temporaires), pour ne plus le confondre avec la résistance.
     Attaques touchées : avec Midi-QOL, lues à la fin du déroulé
     (midi-qol.RollComplete) ; à AttackRollComplete, la liste des cibles
     touchées pouvait être encore vide, tout comptait comme raté. Sans
     Midi-QOL, les cibles sont lues aussi dans flags.dnd5e.targets.
   - FunnyStats, nouvelles stats (onglet Combat) : « Max dgt / round »
     (dégâts infligés en un seul round), « Moy. dgt / round » (dégâts
     infligés ÷ rounds du combat), « Max soins / round »,
     « Dgt bruts » (ce que les coups auraient fait sans résistances ni PV
     temporaires : infligés + part résistée par les cibles, attribuée à
     l'attaquant).
   - FunnyStats : bouton « Historique des dés » : tous les jets du combat
     round par round (combattant dont c'est le tour, lanceur, type de jet,
     résultat, formule, détail des dés, dés écartés barrés, 20 et 1
     naturels en couleur), filtres par combattant et par type de jet.
     Enregistré par le MJ actif depuis les messages du chat (y compris les
     jets ajoutés après coup aux cartes Midi-QOL) ; jets « aveugles »
     exclus ; 1 500 jets au plus par combat.
   Fichiers : modules/funnystats.js, modules/i18n-en.js.

v6.7.7 | 2026-11-08
   - Réinitialisation du brouillard : l'outil « gomme » de la barre
     WestMarch est retiré. La réinitialisation (un personnage ou tout le
     monde) ne se lance plus que depuis Réglages du module → Administration
     du module, avec le mot de passe admin. Le bouton s'y appelle
     « Réinitialisation du brouillard » (au lieu de « Effacer la carte
     d'expédition »). L'étape du tutoriel indique ce nouveau chemin.
   - Changement d'apparence des tokens temporairement désactivé (comme le
     TGCM) : plus de bouton « Image suivante » dans le HUD ni de liste
     d'apparences dans l'onglet Jeton du prototype. Le réglage est grisé
     dans le Toolkit (« temporairement désactivé »). Les apparences déjà
     enregistrées sur les acteurs sont conservées. Le tutoriel saute
     l'étape « Cycle d'apparences », et aussi l'étape « Protection TGCM »
     (fonction déjà gelée) : une étape peut porter « disabled: true ».
   - Tout se désactive : nouveaux réglages (Toolkit, activés par défaut)
     pour ce qui tournait sans interrupteur :
       « Casier du MJ » (bouton Casier du MJ + « Présentations des MJ »
       des joueurs), « Bouton Date Expédition », « Outils de chat du MJ »
       (effacer sa party, importer, export .txt/JSON), « Export d'acteur
       avec choix » (sinon export natif), « Bouton pour réduire la liste
       des joueurs ».
     Le réglage « Go With Party depuis les journaux » existait mais n'était
     jamais lu : le menu « Go Alone / Go With Party » des liens de scène
     des journaux le respecte maintenant.
     Nouvelle catégorie « Module — éléments de base » (thème Aide &
     découverte) : menu Diagnostic, menu Administration du module (ces
     deux-là après rechargement), message du site après une mise à jour,
     reprise des anciennes données, fenêtre des droits défilante. Seule
     la fenêtre « À propos » reste toujours présente : elle reçoit le code
     de licence.
     Échange entre joueurs : quand le réglage est coupé, le MJ refuse
     aussi les demandes d'échange (pas seulement le bouton masqué).
     L'onglet WestMarch disparaît de la barre quand il n'a plus aucun outil
     visible (tout désactivé, ou rien pour cet utilisateur : un joueur
     n'avait parfois qu'un onglet vide).
   - FunnyStats : retrait de la note « Pour le fun : l'auteur d'un dégât
     ou d'un soin est deviné… » sous le tableau de fin de combat.
   Fichiers : modules/map.js, modules/adminpass.js, modules/casier.js,
   modules/tutorial.js, modules/token.js, modules/settings.js,
   modules/funnystats.js, modules/carnet.js, modules/journal.js,
   modules/playerlist.js, modules/export-dialog.js, modules/chat.js,
   modules/trade.js, modules/adminpass.js, modules/site.js,
   modules/migration.js, modules/document.js,
   modules/i18n-en.js, index.js.

v6.7.6 | 2026-11-08
   - Mot de passe admin du module : Réglages du module → « Administration du
     module » (MJ). Il protège « Préparer l'ouverture du serveur » et
     l'effacement de la carte d'expédition (brouillard exploré, d'un
     personnage ou de tous : bouton de la barre WestMarch ; zones révélées :
     bouton de l'onglet Expéditions du Casier). Créé par le premier MJ qui
     lance une action protégée, ou depuis la fenêtre d'administration ; on
     peut le changer en donnant l'ancien. 6 caractères minimum, commun à
     tous les MJ. Seule son empreinte est enregistrée (PBKDF2-SHA-256, sel
     aléatoire, réglage monde « adminPass »), jamais le mot de passe. Après
     une saisie correcte, il n'est pas redemandé pendant 5 minutes.
     Protection côté navigateur : elle empêche les erreurs et les abus
     simples, pas un MJ qui efface le réglage depuis la console.
   - « Préparer l'ouverture du serveur » passe du Casier (Dashboard) à la
     fenêtre « Administration du module » des réglages.
   - Contenu homebrew (Plutonium) : l'ancienne méthode (copier l'adresse
     du fichier du module dans « Additional Homebrew Files ») est retirée,
     car elle ne marchait que pour ceux qui l'avaient ajoutée eux-mêmes. Le
     menu des réglages, désormais réservé au MJ (« Installer / vérifier »),
     donne la marche à suivre de l'index homebrew local de Plutonium :
     lien de homebrew/westmarch-perso.json dans Data/assets/homebrew/,
     index.json {"toImport":["westmarch-perso.json"]}, option « Load Local
     Homebrew Index », Blocklist et Contrôle des sources. Bouton « Vérifier
     ce serveur » : teste index.json et le fichier servis.
   - Système d'étoiles : curseur « Étoiles maximum par session » (1 à 10,
     3 par défaut, réglage monde starXpMaxAward) dans la catégorie Système
     d'étoiles. Il fixe le nombre d'étoiles du sélecteur de « Clore la
     session » et de l'attribution en attente du Casier (une valeur déjà
     choisie au-dessus du nouveau maximum reste affichée).
   - Panneau de configuration : case « Uniquement l'actif » en haut de la
     colonne des thèmes, cochée par défaut (préférence de chaque MJ,
     réglage utilisateur hubActifsSeulement). Elle masque les fonctions
     coupées par leur interrupteur principal, les options décochées (et les
     champs qui en dépendent : webhook du journal de session, délais de
     réapprovisionnement, heures d'obscurité), les branches vides des
     modifications ciblées et les thèmes sans rien d'actif. Calculé à
     l'ouverture : une case décochée pendant l'édition reste visible. Le
     lien « Tout activer » est caché tant que le filtre est actif. Décocher
     la case affiche tout, pour réactiver une fonction.
   - Registre du monde : le dossier des lieux n'est plus créé en double
     selon la langue (« Lieux » pour un MJ en français, « Places » pour un
     MJ en anglais). Le nom par défaut est reconnu dans les deux langues et
     le dossier retenu porte un flag (mondeDossier) qui le retrouve ensuite
     quel que soit le client. Les doublons existants sont fusionnés au
     prochain chargement d'un MJ : fiches et sous-dossiers déplacés dans le
     dossier retenu, doublon vide supprimé. Même correction pour retrouver
     les compendiums « Registre — PNJ » / « Registre — Organisations » (le
     nom de comparaison était traduit, donc jamais reconnu dans l'autre
     langue).
   - Registre du monde, fiche PNJ : bouton « Créer l'acteur » à côté de la
     zone « Acteur lié » (affiché tant qu'aucun acteur n'est lié). Il crée
     un acteur PNJ (type npc) au nom saisi dans la fiche, rangé dans le
     dossier des PNJ de « Dossiers & Compendiums », invisible des joueurs,
     et le lie tout de suite dans les deux sens (comme un acteur glissé),
     même si la fenêtre est ensuite annulée. Lien « ouvrir » pour remplir
     sa fiche. Glisser un acteur existant reste possible.
   Fichiers : modules/adminpass.js (nouveau), modules/casier.js,
   modules/map.js, modules/homebrew.js, modules/monde.js, modules/starxp.js,
   modules/settings.js, modules/tutorial.js, modules/i18n-en.js,
   styles/settings-hub.css, index.js.

v6.7.5 | 2026-11-08
   - Casier → Dashboard : bouton « Préparer l'ouverture du serveur… » pour
     effacer d'un coup les données laissées par les tests. Une fenêtre liste,
     avec le nombre d'éléments concernés, ce qui peut être effacé (tout coché
     par défaut) : rapports en attente, fils Discord des rapports, journal des
     sessions (présence, assiduité), zones révélées de la carte, historique des
     expéditions et temps morts sur toutes les fiches de PJ, demandes de
     création et de montée de niveau en attente. En dessous, la liste des
     fiches de PJ ayant un joueur, à supprimer au choix (aucune cochée par
     défaut) : les onglets Statistiques et Registre se calculent à partir de
     ces fiches. Confirmation par la saisie de « RESET ». Réservé aux MJ,
     s'applique à tous les MJ, irréversible. Fichier : modules/casier.js.
   - Nouveau : accrocher un token à un PJ (Toolkit, activé par défaut). Dans
     le HUD d'un token (clic droit, MJ), l'icône chaîne accroche ce token (PNJ,
     objet, autre PJ) au token d'un PJ de la scène, en mode « Porter » (posé
     sur le PJ, même trajet) ou « Mener » (suit derrière à la distance de
     l'accrochage). Quand le joueur déplace son PJ, le token accroché suit
     tout seul : aucun droit à donner, c'est le MJ connecté qui le déplace.
     Le token accroché passe uniquement par le chemin du PJ (son trajet, ou
     sa piste en mode Mener) : il ne traverse pas les murs, et l'animation
     suit ce même chemin. Décrochage : même icône, suppression du porteur, ou
     déplacement du token accroché par quelqu'un d'autre. Boucles refusées.
     Nouveau fichier : modules/accroche.js.
   - Nouveau : FunnyStats, tableau de fin de combat façon « fin de partie »
     (option personnelle dans « Accessibilité » → Divertissement, désactivée
     par défaut ; lien « Voir le dernier tableau »). Pour chaque combattant,
     PJ d'un côté, PNJ de l'autre : dégâts infligés, reçus, annulés
     (résistances, immunités, réductions), absorbés par les PV temporaires,
     soins sur soi et sur les autres, PV temporaires gagnés, éliminations,
     K.O. (onglet « Combat ») ; distance parcourue (unité de la scène, sans
     compter les trajets d'un token porté ou mené), actions, actions bonus et
     réactions utilisées, sorts lancés, consommables utilisés, attaques
     réussies et ratées, réussites critiques (20 naturel ou critique, compté
     une seule fois par jet) et échecs critiques (1 naturel) (onglet
     « Déplacements, actions et dés »). Meilleure valeur de chaque colonne en
     doré, et des titres parmi les PJ : MVP, Bourreau, Tank, Ange gardien,
     Inébranlable, Globe-trotter, Infatigable, Béni des dés, Maudit des dés.
     Relevé fait par le MJ connecté (hooks de PV de dnd5e, calcul des dégâts,
     messages d'attaque / dégâts / soins, utilisation des activités dnd5e,
     déplacements des tokens, hooks de Midi-QOL s'il est actif),
     gardé sur le combat pour survivre à un rechargement, puis publié à la
     suppression du combat. L'auteur d'un dégât ou d'un soin est déduit du
     dernier jet qui visait la cible (sinon le dernier jet, sinon le
     combattant dont c'est le tour). Nouveau fichier : modules/funnystats.js ;
     modifiés : accessibility.js, index.js.

v6.7.4 | 2026-10-31
   - Numérotation : chaque chiffre de version reste entre 0 et 9. Les
     versions publiées 6.6.10 à 6.6.13 correspondent à 6.7.0 à 6.7.3 ; la
     suite reprend en 6.7.4 (numéro plus grand que 6.6.13, donc proposé en
     mise à jour par Foundry à tous les serveurs).
   - Horloge de la party : elle ne recouvre plus la liste des joueurs. Sa
     position se cale sur le bord droit réellement visible de la liste (le
     plus à droite de tous ses éléments : noms longs, avatars, contenu qui
     déborde du conteneur), et non plus sur le seul conteneur #players.
     Fichier : modules/partytime.js.

v6.6.13 | 2026-10-31
   - Horloge de la party affichée dans un rectangle à DROITE de la liste des
     joueurs, aligné sur son bas (position recalculée chaque seconde : suit
     la taille de la liste). Heure avec les secondes (hh:mm:ss), date et
     étiquette Party / Monde en dessous. Fichier : modules/partytime.js.

v6.6.12 | 2026-10-31
   - Réglages du module → « Contenu homebrew (Plutonium) » (ouvert à tous) :
     affiche l'adresse de la source homebrew du serveur (background
     « Origine personnalisée »), calculée pour CE serveur (origine du
     navigateur + préfixe de route de Foundry via getRoute), avec un bouton
     « Copier ». Fichier : modules/homebrew.js (nouveau).

v6.6.11 | 2026-10-31
   - Retrait du background en compendium (6.6.6 et 6.6.8) : plus de
     compendium « Backgrounds » ni de dossier « Soruta WestMarch », plus de
     section « Contenu personnalisé » ni de modules/origins.js. Le background
     « Origine personnalisée » est fourni uniquement par la source homebrew
     5etools pour Plutonium : homebrew/westmarch-perso.json, à charger par
     son URL <serveur>/modules/soruta-completed-westmarch/homebrew/
     westmarch-perso.json.

v6.6.10 | 2026-10-31
   - Horloge de party : le sablier « Avancer le temps de la party » refuse
     de s'ouvrir sans expédition ouverte (avertissement). Plus aucune
     écriture d'horloge (avance, round de combat, enregistrement minute)
     sans expédition en cours.
   - Ouverture d'expédition : l'horloge de la party est toujours recalée sur
     le calendrier global (heure globale exacte ; si une autre date est
     choisie, ce jour-là à l'heure globale actuelle, au lieu de 8 h). Une
     ancienne horloge restée ouverte pour la party est remplacée.
   Fichier : modules/partytime.js.

v6.6.9 | 2026-10-31
   - Horloge de party — écoulement en temps réel (option « Écoulement en
     temps réel ») : pendant l'expédition, hors combat, une seconde réelle =
     une seconde de jeu pour la party. L'horloge s'arrête quand la party est
     en pause (pause de party ou pause globale), en combat, ou dissoute
     (clôture de session), et repart ensuite. Stockage : heure de base +
     heure serveur de départ (anchor) ; chaque client calcule l'heure sans
     écriture. Le GM de la party enregistre l'heure atteinte une fois par
     minute (rations et obscurité si besoin). Si le GM n'est plus connecté,
     au plus 3 minutes sont comptées.
   - Combat (option « +6 secondes par round de combat ») : chaque nouveau
     round du combat de la party ajoute CONFIG.time.roundTime (6 s) à son
     horloge. Un retour en arrière de round ne remonte pas le temps.
   - Horloge affichée (option « Afficher l'horloge de la party ») : petit
     bandeau au-dessus de la liste des joueurs (pas en haut : carrousel de
     combat). Chacun voit l'heure de SA party (soleil / lune, heure, date,
     icône pause quand le temps est arrêté), ou celle du calendrier du monde
     hors expédition. Rafraîchi chaque seconde, sans écriture. Chaque joueur
     peut le masquer dans Accessibilité (« Afficher l'horloge de la party »).
   - Toutes les écritures d'horloge passent par une file unique (avance
     manuelle, rounds, enregistrement minute, pause) : pas d'écrasement.
   Fichiers : modules/partytime.js, modules/settings.js,
   modules/accessibility.js, modules/i18n-en.js.

v6.6.8 | 2026-10-31
   - Background « Origine personnalisée » installé automatiquement dans le
     compendium « Backgrounds » du module (dossier « Soruta WestMarch »).
     Nouvelle section de réglages « Contenu personnalisé » → « Background
     Origine personnalisée » (désactivé par défaut, rechargement requis).
     Activé, le GM actif écrit au chargement du monde le background au
     format dnd5e (plus besoin de Plutonium) :
       caractéristiques +2/+1 ou +1/+1/+1 parmi les six (avancement ASI,
       3 points, max 2) ; un don d'origine au choix (ItemChoice restreint
       aux dons de sous-type « origin » des compendiums chargés, PHB
       préféré au SRD à nom égal, dépôt d'un autre don possible) ; deux
       compétences ; un outil d'artisan / instrument / jeu ; aucun
       équipement, 200 po de richesse de départ.
     Le compendium est déverrouillé le temps de l'écriture puis reverrouillé.
     Une mise à jour du module vide le compendium : le background est
     recréé au chargement suivant (id stable scwmOriginePerso, version
     dans flags). Couper le réglage ne supprime rien. Fichier :
     modules/origins.js (nouveau).

v6.6.7 | 2026-10-31
   - Section de réglages dédiée « Horloge de party » (thème Party & jeu de
     groupe), sortie de « Système de Party ». Interrupteur principal
     (enablePartyTime) + options indépendantes, toutes cochées par défaut :
       Consommation des rations (partyTimeRations) ;
       Alerte de faim et d'épuisement (partyTimeHungerWarning, grisée sans
       les rations) ;
       Rappel de l'eau (partyTimeWaterReminder) ;
       Résumé dans le chat (partyTimeChatSummary) : coupé, seules les
       alertes sont publiées et le GM voit la date dans une notification ;
       Rattrapage du calendrier global (partyTimeCatchUp) : coupé, la
       clôture ferme l'horloge sans toucher au calendrier global ;
       Obscurité des scènes (enablePartyDarkness) avec niveau de nuit,
       lever et coucher du soleil (grisés sans l'obscurité).
     Les options sont grisées quand l'interrupteur principal est coupé.
     Les réglages existants gardent leur valeur. Fichiers :
     modules/settings.js, modules/partytime.js, modules/i18n-en.js.

v6.6.6 | 2026-10-31
   - Compendium « Backgrounds » (type Item, dnd5e) rangé dans le dossier de
     compendiums « Soruta WestMarch » (visible en Observateur par les
     joueurs). Livré vide : le MJ le déverrouille et y importe le background
     via Plutonium, puis le dossier packs/backgrounds/ du serveur est recopié
     dans le dépôt pour qu'il survive aux mises à jour.
   - homebrew/westmarch-perso.json : source homebrew 5etools « West Marches
     - Contenu personnalisé » (abréviation WMP, auteur Soruta), lisible par
     Plutonium à l'adresse
     <serveur>/modules/soruta-completed-westmarch/homebrew/westmarch-perso.json.
     Contient le background « Origine personnalisée » : +2/+1 ou +1/+1/+1
     au choix parmi les six caractéristiques, un don d'origine, deux
     compétences, un outil d'artisan / instrument / jeu, 200 po en
     équipement de départ.

v6.6.5 | 2026-10-31
   - Accessibilité → « Afficher l'état de santé estimé » (par joueur, coché
     par défaut, visible seulement si le module Health Estimate est actif) :
     chaque joueur choisit s'il voit le texte d'état de santé au survol des
     tokens. Health Estimate reste actif pour la table ; sur le client du
     joueur qui décoche, sa fonction d'affichage est remplacée par une
     fonction vide et son calque est masqué. Recocher rétablit l'affichage
     sans rechargement. Fichier : modules/accessibility.js.
   - Horloge de party et rations (Système de Party → « Horloge de party et
     rations », activée par défaut). Pendant une expédition, chaque party a
     sa propre date, sans toucher au calendrier global :
       - l'horloge démarre à l'ouverture de l'expédition (bouton Date
         Expédition du Carnet) : heure globale exacte si l'expédition
         commence aujourd'hui, sinon 8 h le jour choisi ;
       - bouton sablier « Avancer le temps de la party » (groupe WestMarch,
         GM) : avance de N heures ou N jours, ou repos long (+8 h) ;
       - chaque minuit franchi consomme 1 ration par PJ (objet consommable
         d'identifiant « rations », ou dont le nom contient « ration ») ;
         case « Nourri autrement » par PJ (Baie nourricière, Création de
         nourriture et d'eau, chasse…), mémorisée pour la party ;
       - plus de rations : le module compte les jours sans manger et le dit
         dans le chat ; au-delà de 3 + mod. de Constitution (min. 1), il
         rappelle la règle d'Épuisement, sans rien appliquer (le MJ tranche) ;
       - rappel de l'eau dans le chat à chaque nouveau jour (réglage
         « Horloge de party : rappel de l'eau ») ;
       - résumé publié dans le chat de la party (date, rations, alertes).
   - Clôture d'expédition : la date proposée est celle de la party (libellé
     « Date de la party »). Quand plus aucun PJ de la party n'a d'expédition
     ouverte, le calendrier global avance jusqu'à la date de la party si
     elle est plus loin (notification Discord de changement de jour
     incluse), puis l'horloge de la party est supprimée. Si le calendrier
     global est déjà plus loin, il ne bouge pas.
   - Obscurité des scènes (réglage « Horloge de party : obscurité des
     scènes », activé par défaut) : clic droit sur une scène du répertoire →
     « Suivre l'heure de la party ». Une scène cochée où se trouve un PJ de
     la party prend l'obscurité de l'heure de la party à chaque avance :
     nuit pleine avant le lever et après le coucher du soleil, transition de
     2 h à l'aube et au crépuscule, 0 en journée. Niveau de nuit (0,9) et
     heures du lever (6 h) et du coucher (20 h) réglables. Deux parties sur
     la même scène : la première arrivée garde la main (flag de scène
     « darknessParty ») tant qu'elle y a un PJ et que son expédition est
     ouverte ; l'autre reprend la main à sa prochaine avance. Les scènes non
     cochées (donjons, intérieurs) ne changent jamais. Une erreur sur
     l'obscurité ne bloque ni l'avance du temps ni les rations.
   - État stocké dans le réglage de monde « partyClockState » (une entrée
     par party, clé = id du GM de la party).
   Fichiers : modules/partytime.js (nouveau), modules/carnet.js,
   modules/settings.js, modules/i18n-en.js, index.js.

v6.6.4 | 2026-10-26
   - Moine — Arts martiaux automatiques (Modifications ciblées → Classes →
     Moine, activé par défaut) : sans armure ni bouclier, les frappes à
     mains nues et les armes de moine utilisent le dé d'Arts martiaux s'il
     est plus grand que celui de l'arme (deux mains comprises pour une arme
     Polyvalente), et la Dextérité quand elle est meilleure que la Force,
     même si l'attaque de l'arme était réglée sur la Force. Rien n'est
     modifié dans les objets : la règle est appliquée en mémoire quand dnd5e
     prépare l'arme, la fiche affiche donc le bon dé. Armes de moine selon
     les règles de la classe : 2024 (armes simples de corps à corps + armes
     de guerre de corps à corps Légères) ou 2014 (épée courte + armes
     simples de corps à corps sans À deux mains ni Lourde). Dé lu dans
     l'échelle de la classe (@scale.monk.die), sinon déduit du niveau.
     Fichier : modules/monk.js.
   - Capacités qui se rechargent au jet d'initiative (Modifications ciblées
     → Classes, une case par capacité, activées par défaut). Au premier jet
     d'initiative du combat, le MJ connecté applique :
       Moine — Métabolisme surnaturel (s'il reste une utilisation et qu'un
       point de focus est dépensé : focus au maximum, PV = dé d'Arts
       martiaux + niveau) ; Focus parfait (focus remontés à 4) ou Perfection
       de l'être en 2014 (4 ki s'il n'en reste aucun) ;
       Barbare — Rage persistante (rages récupérées, une fois par repos long) ;
       Barde — Inspiration supérieure (2 en 2024, 1 en 2014) ;
       Druide — Archidruide 2024 (une Forme sauvage s'il n'en reste aucune).
     Une capacité déjà épuisée ne fait rien ; un message de chat résume ce
     qui a été récupéré. Fichier : modules/initiative-recup.js.
   - Inspiration héroïque : Humain Ingénieux (Resourceful) → cochée à la fin
     d'un repos long ; don Musicien → à la fin d'un repos court ou long, le
     joueur choisit jusqu'à « bonus de maîtrise » alliés (le MJ connecté fait
     l'écriture). Fichier : modules/inspiration.js.
   - Priorité aux automatisations existantes : si l'objet de la capacité est
     déjà automatisé (récupération « Initiative » réglée dans dnd5e, macro
     Midi-QOL onUse, objet de Chris's Premades, Gambit's Premades ou Midi
     Item Showcase), le module ne fait rien pour cette capacité.

v6.6.3 | 2026-10-26
   - Anglais par défaut : tout le texte du module (réglages, fiches, onglets,
     Casier, fenêtres, messages de chat, notifications, journal Discord,
     tutoriel, guide « Où ranger quoi ? ») s'affiche en anglais, sauf pour
     les utilisateurs dont la langue Foundry est le français, qui gardent le
     texte d'origine. Chaque utilisateur voit sa langue (réglage « Langue »
     de Foundry). Dates et nombres suivent aussi la langue.
     Fichiers : modules/i18n.js (fonction tl, langue, memeNom) et
     modules/i18n-en.js (dictionnaire français → anglais, ~2 400 entrées).
     Un texte absent du dictionnaire reste en français, sans erreur.
   - Noms créés par le module (dossiers « Tokens de groupe », « Panthéons »,
     « Carnet commun », « Tutoriel », « Import », acteur modèle « Token à
     copier et rennomer », compendiums « Registre — PNJ / Organisations »,
     pages du guide) : reconnus dans les deux langues, pas de doublon si
     des MJ de langues différentes se succèdent.
   - Dossiers par défaut (validation des personnages, fiches de lieux) :
     fixés une fois dans la langue du MJ au premier lancement, pour que tous
     les clients lisent le même nom.
   - Contrôle des sources : le mot-clé « species » (et « espece ») est
     accepté comme « race ».
   - Nouveau réglage client « Module language / Langue du module »
     (Automatique / English / Français, rechargement) : chaque utilisateur
     peut avoir le module dans une autre langue que Foundry, par exemple
     Foundry en anglais et le module en français.
   - Messages de la console (F12) traduits aussi.
   - Dieux de Faerûn : version anglaise livrée (data/dieux-de-faerun-en.json,
     101 pages, noms anglais officiels, tri alphabétique anglais). Le dossier
     « Panthéons » est créé dans la langue du MJ au premier lancement.
   - Inchangé : le contenu de base de la fiche démo du tutoriel reste en
     français ; les noms de mois du calendrier servent de repère et ne sont
     pas traduits.

v6.6.2 | 2026-10-26
   - Corrections : l'icône « géré par le module » n'apparaît plus en double
     sur les lignes de la fiche ; « Dernière position » et « Dernière
     rencontre » du Bestiaire ont la même police que « Première rencontre » ;
     cartes de chat : un bouton-icône qui répète une action déjà présente en
     bouton texte (ex. « Healing » d'une activité de soin Midi-QOL) est
     masqué au lieu d'apparaître une seconde fois. Plus généralement, deux
     boutons de la même carte qui portent le même libellé (dnd5e, Midi-QOL
     ou habillage du module) ne s'affichent jamais ensemble : seul le
     premier reste visible.
   - Cartes de chat (thème) : la formule des jets (barre sombre « 1d20 + 7 »
     des cartes dnd5e / Midi-QOL) héritait du texte foncé du thème et
     devenait illisible ; elle repasse en texte clair.

v6.6.1 | 2026-10-26
   - Sécurité : les notes et la dernière position des Relations, les notes
     du Bestiaire, les noms affichés et les titres du Carnet sont échappés ;
     le contenu HTML des notes du Carnet est nettoyé (scripts, iframes,
     attributs on…, liens javascript: retirés) à l'affichage et à
     l'enregistrement. Avant, un joueur pouvait glisser du code dans une
     note qui s'exécutait chez le MJ à l'ouverture de sa fiche.
   - Problèmes du module dans le log Discord : tous les messages du module
     passent par modules/log.js. Les vrais problèmes (erreur, fonction
     cassée, conflit avec un autre module ou une mise à jour de Foundry qui
     passe par-dessus, erreur non rattrapée venant des fichiers du module)
     sont envoyés dans le log Discord par le client où ils arrivent, sous un
     séparateur « 🚨 Problèmes du module », avec le message, l'endroit dans
     le code, le joueur concerné, les versions (Foundry, système, module) et
     la mention « Contacter le propriétaire du module ». Un même problème
     n'est envoyé qu'une fois toutes les 10 minutes (15 envois au plus par
     chargement). Nouvelle case « Problèmes du module » (logModuleErrors)
     dans Paramètres → Log Discord. Les petits soucis contournés restent
     dans la console du navigateur (F12).
   - Bouton « Diagnostic » dans les paramètres du module (MJ, disponible
     même sans licence) : versions, licence, modules tiers nécessaires aux
     fonctions activées (Monk's, libWrapper, Midi-QOL…), réglages
     essentiels (dossiers PJ / PNJ, compendium des créatures, carte des
     expéditions, webhook), joueurs sans personnage ou PJ hors du dossier,
     et problèmes détectés depuis le chargement. ✅ / ⚠️ / ❌ par ligne, et
     bouton « Copier » pour l'envoyer au propriétaire du module. Nouveau
     fichier modules/diagnostic.js.
   - Relations et Bestiaire : « Dernière rencontre », date mise à jour
     automatiquement quand le personnage revoit le PJ / PNJ / la créature
     (date du calendrier du monde si disponible, date réelle au survol ;
     sinon date réelle). Réglages relationsLastSeen et bestiaryLastSeen.
   - Indicateur « géré par le module » : icône d'engrenages dorée sur les
     aptitudes dont le module applique la règle (Healer, Alert, Large Form,
     Giant's Havoc, Form of the Beast), avec l'explication au survol ;
     désactivable par chaque joueur (Accessibilité). Nouveau fichier
     modules/gere.js.
   - Nettoyage : fichier modules/hotbar.js supprimé (vide, plus importé
     depuis que « Interface — Masquer des éléments » gère la barre de
     macros) ; fonctions jamais appelées retirées (closeExpedition,
     myCharActor, unlockActor, CompanionProfilesMenu, totalStars,
     openDowntimeDialog, showTutorialSelector, export de test de la
     licence) ; ouverture des portraits via l'API actuelle de Foundry
     (ImagePopout) au lieu de l'ancien nom global.
   - Modifications ciblées → Features : « Healer (Guérisseur) — relance des
     1 sur les soins » (enableHealerReroll, activé par défaut). Pour un
     personnage qui a le don Healer, chaque jet de soins d'un sort (ou du
     Battle Medic du don) reçoit le modificateur « r1 » sur ses dés
     (2d8 + @mod → 2d8r1 + @mod) : un dé qui fait 1 est relancé une fois et
     le nouveau résultat est gardé. PV temporaires, potions et dégâts ne
     sont pas concernés. Nouveau fichier modules/healer.js.
   - Modifications ciblées → Features : « Alert (Vigilant) — échange
     d'initiative » (enableAlertSwap, activé par défaut). Pour les comptes
     MJ, un bouton d'échange apparaît dans le suivi de combat sur la ligne
     d'un personnage de joueur qui a le don Alert, une fois son initiative
     lancée. Le MJ choisit un autre joueur du combat (initiative lancée ;
     un personnage neutralisé est grisé) : les deux initiatives sont
     échangées et un message l'annonce dans le chat. Après usage, le bouton
     reste disponible en grisé (nouvel échange avec confirmation). Don
     reconnu par l'identifiant « alert » ou le nom « Alert » / « Vigilant ».
     Nouveau fichier modules/alert.js.
   - Log Discord : les PNJ et créatures importés d'un compendium (ou par
     Plutonium) ne sont plus jamais loggés (création, suppression, objets,
     XP, monnaie), pour ne pas dévoiler ce que le MJ prépare. Les PNJ créés
     à la main et les PJ restent loggés comme avant.
   - Log Discord : nouveau contenu « Modifications des fiches »
     (logSheetEdits, activé par défaut). Toute modification d'un objet,
     d'une aptitude ou d'un sort (nom, description, dégâts, portée,
     utilisations max…) et de la fiche elle-même (caractéristiques,
     maîtrises, langues, résistances, biographie…) est loggée, avec la
     liste des champs changés (avant → après pour les valeurs simples).
     Seuls les champs réellement modifiés comptent ; ce qui change en jeu
     n'est pas loggé (PV, utilisations dépensées, emplacements de sorts,
     équiper / préparer / harmoniser, dés de vie dépensés).
   - Log Discord : quand le thème des messages change (inventaire,
     aptitudes & sorts, progression, monnaie, modifications de fiche,
     personnages, scènes, journaux), une ligne de séparation avec le nom
     du thème est ajoutée au-dessus du message.
   - Messages « problème du module » (log Discord, console, diagnostic) :
     ajout du lien d'invitation du Discord Althéia pour ouvrir un ticket
     plutôt qu'envoyer un message privé.

v6.6.0 | 2026-10-23
   - Bestiaire : « Première rencontre » n'est plus modifiable à la main
     (remplie une fois, à l'ajout de la créature), comme « Dernière
     position ».
   - Bestiaire, étiquettes de dégâts : rangées automatiquement par groupe
     (faiblesses, puis résistances, puis immunités, puis les types non
     notés ; ordre alphabétique dans chaque groupe). Le rangement se fait
     quand la souris quitte la liste ou 1,5 s après le dernier clic, pour
     que l'étiquette ne se déplace pas pendant qu'on clique dessus.

v6.5.9 | 2026-10-23
   - Bestiaire : « Dernière position » n'est plus modifiable à la main
     (texte simple, mis à jour automatiquement quand le personnage revoit
     la créature, aussi dans une fiche déjà ouverte).
   - Bestiaire : la CA estimée n'est plus une liste déroulante mais une
     jauge de 6 barres dorées dans le style du bestiaire (clic pour choisir,
     re-clic sur la barre choisie pour revenir à « inconnue » ; niveau et
     fourchette au survol). Les valeurs déjà notées sont conservées.

v6.5.8 | 2026-10-23
   - Bestiaire, trois nouveaux champs par créature (chacun désactivable
     dans Paramètres → Bestiaire) :
       · « Dernière position » (bestiaryLastPosition) : scène où le
         personnage a vu la créature en dernier, mise à jour automatiquement
         quand il la revoit, modifiable par le joueur ;
       · « CA » estimée (bestiaryArmorClass) : liste très faible (≤ 13),
         faible (14–15), moyenne (16–17), élevée (18–19), très élevée
         (20–21), extrême (≥ 22) ;
       · « Dégâts » (bestiaryDamageTags) : une étiquette par type de dégâts
         (13 types) ; chaque clic change son état et sa forme : neutre
         (pointillés) → faiblesse (rouge, carrée) → résistance (bleue,
         arrondie) → immunité (dorée, pleine) → neutre. En lecture seule,
         seules les étiquettes notées s'affichent.

v6.5.7 | 2026-10-18
   - Relations, ajout automatique : seul le personnage sur lequel le joueur
     est connecté (Configuration du joueur → personnage) détecte, et
     seulement les jetons que SON jeton voit vraiment : pas à travers un mur
     ou une porte fermée (au moins un point de la cible en ligne de vue), pas
     un jeton caché par le MJ, et, si la scène utilise la vision des jetons,
     seulement ce qui est visible à l'écran (lumière, obscurité, vision dans
     le noir). Avant, n'importe quel PJ possédé par le joueur sur la scène
     recevait tous les jetons de la scène. Nouveau contrôle quand un jeton
     bouge ou apparaît, qu'une porte s'ouvre, ou que le joueur change de
     personnage. Seuls les murs qui bloquent la vue comptent (murs de
     mouvement ou de son seuls, portes ouvertes ignorés ; mur limité comme
     dans Foundry). Aucune détection sur les scènes déclarées comme carte
     des expéditions. Nouveau fichier modules/perception.js.
   - Bestiaire, ajout automatique : mêmes règles que les Relations
     (personnage connecté, créatures vues par son jeton, rien sur les cartes
     des expéditions). Textes du tutoriel mis à jour.
   - Contrôle des sources : un sort, don, aptitude ou objet refusé (liste
     noire ou source non autorisée) ne fait plus échouer l'import d'une
     classe. Avant, l'import (Plutonium, avancement dnd5e) crée la classe et
     tout ce qu'elle donne d'un seul coup ; refuser un seul élément du lot
     cassait l'import (fiche sans classe, sorts à moitié ajoutés). Désormais
     ces contenus sont créés, puis retirés automatiquement une fois l'import
     terminé (2,5 s sans nouvelle création sur la fiche), avec un message
     qui liste ce qui a été retiré et pourquoi. Classes, sous-classes,
     espèces et historiques refusés restent bloqués immédiatement.
   - Nouveau réglage « Taille des épingles de lieux » (mondeTailleEpingle,
     Registre du monde) : curseur de 8 à 512 px, 32 par défaut. La taille est
     appliquée à l'affichage par chaque client, tout de suite, sans recharger
     (Foundry impose 32 px minimum à une note : l'icône est mise à l'échelle,
     la pointe reste sur le point exact).
   - Registre du monde : le dossier des lieux (« Lieux » par défaut) est créé
     dès que le registre est actif (au démarrage, à l'activation ou au
     changement de son nom), et les fiches de lieux restées à la racine des
     journaux y sont rangées.
   - Nouveaux réglages mondePackPersonFolder et mondePackOrgFolder : nom d'un
     dossier DANS le compendium des PNJ / des organisations où ranger les
     fiches (créé s'il n'existe pas ; vide = racine). Utilisé à la création
     et par « Ranger dans les compendiums ».
   - Carte des expéditions : l'acteur modèle « Token à copier et rennomer »
     est rangé dans un dossier d'acteurs « Tokens de groupe » (couleur or
     orangé), créé automatiquement, sauf si un autre dossier est choisi dans
     le réglage expeditionMapTemplateFolder.

v6.5.6 | 2026-10-17
   - Progression XP, tableau des paliers : la colonne « XP pour monter » est
     de nouveau modifiable, en plus de « Hausse % », et les deux sont liées.
     Changer l'XP d'un niveau recalcule sa hausse % ; le niveau suivant garde
     son XP (son % est ajusté). Changer un % décale les niveaux suivants (ils
     gardent leur %). L'XP du niveau 1 (300 par défaut) est aussi modifiable :
     elle est la base de la courbe. En mode objectif, la valeur tapée est
     respectée et les autres niveaux s'ajustent pour tenir la durée visée.
     Réglage xpGrowthOverrides : entrée 0 = XP du niveau 1, puis les hausses
     en % (précision 0,01 %).
   - Épingles des lieux : le carré sombre que Foundry dessine derrière
     chaque note est masqué ; seule l'épingle apparaît sur la carte (le cadre
     de survol reste visible en mode « Notes de journal », pour la déplacer).
   - Toutes les notes de lieux de la carte du monde deviennent des épingles
     fines, quelle que soit leur icône (livre, logo de Monk's…) : conversion
     faite une seule fois au démarrage (réglage interne
     mondeEpinglesMigrees), puis à chaque nouvelle note de lieu posée sur la
     carte du monde (glisser-déposer du journal compris). Une icône changée
     ensuite à la main est respectée. Les notes qui ne sont pas des lieux ne
     changent pas.
   - Carte des expéditions : le brouillard des joueurs passe juste sous les
     notes de journal, pour que le nom d'un lieu découvert (au survol de son
     épingle) ne soit plus coupé par le noir des cases voisines. Les joueurs
     ne voient toujours que les notes des lieux qu'ils ont le droit de voir.

v6.5.5 | 2026-10-17
   - Épingle d'un lieu : « Placer sur la carte » affiche la carte du monde et
     attend un clic à l'emplacement voulu (curseur en croix, Échap ou clic
     droit pour annuler) ; l'épingle est centrée sur la case cliquée. La
     fenêtre « Rédiger » se réduit pendant la pose, puis revient.
   - L'épingle n'a plus d'étiquette figée : elle affiche le nom du journal (le
     nom tapé dans « Rédiger » est appliqué avant la pose). Les épingles
     restées sur « Nouveau lieu » ou sur un ancien nom sont corrigées.
   - Poser ou déplacer une épingle n'est pas une découverte par le groupe :
     les joueurs qui avaient déjà exploré la case reçoivent l'accès sans
     bannière ni message. La bannière reste réservée au groupe qui arrive sur
     la case.
   - Création d'une fiche : la fenêtre « Rédiger » repasse devant si Monk's
     ouvre le journal tout juste créé.
   - Épingles des lieux : nouvelle icône, une petite épingle fine plantée dans
     la carte (32 px, la pointe tombe sur le point exact) ; le nom du lieu
     s'affiche au survol. Les anciennes épingles posées par le module (icône
     livre) sur la carte du monde sont converties.
   - Nouveau réglage « Épingles visibles dans tous les modes »
     (mondeEpinglesPartout, activé par défaut) : sur la carte du monde, les
     épingles restent affichées quel que soit l'outil (jetons, mesures…), et
     plus seulement en mode « Notes de journal », et restent survolables
     (nom au survol). Les joueurs ne voient que les lieux découverts.
   - « Où ranger quoi ? » : l'onglet du Casier est retiré. À la place, bouton
     « Générer le journal » dans Paramètres → Dossiers & Compendiums : il
     enregistre les réglages de la fenêtre puis crée (ou met à jour) le
     journal « 📌 Où ranger quoi ? (MJ) », réservé aux MJ, avec deux pages :
     le guide (dossiers et compendiums réglés) et la vérification du monde
     (ce qui est mal rangé, avec liens). Le journal se met à jour tout seul
     quand ces réglages changent.

v6.5.4 | 2026-10-17
   - Registre du monde : les fiches PNJ et Organisation sont rangées dans des
     compendiums de journaux du monde (« Registre — PNJ », « Registre —
     Organisations », créés automatiquement à la première fiche) au lieu de
     dossiers, pour alléger le chargement du monde. Les fiches Lieu restent
     des journaux du monde (dossier « Lieux ») car les épingles de carte et la
     découverte par le brouillard ont besoin de journaux du monde.
     Réglages : mondePackPerson, mondePackOrg (choix du compendium),
     mondeFolderPlace ; mondeFolderPerson et mondeFolderOrg ne sont plus
     utilisés. Une fiche en compendium n'a pas de droits par joueur : elle est
     réservée aux MJ (pour la montrer, l'importer dans le monde).
   - Onglet Monde du Casier : bouton « Ranger dans les compendiums » pour
     déplacer les fiches PNJ / Organisation existantes du monde (même id,
     relations, liens @UUID et fiches d'acteurs mis à jour). Le compendium
     doit être déverrouillé pour créer ou modifier une fiche.
   - « Où ranger quoi ? » indique les compendiums du registre et signale les
     fiches PNJ / Organisation restées dans le monde.

v6.5.3 | 2026-10-17
   - Progression XP (D&D 5e) : les paliers sont désormais, PAR DÉFAUT, ceux de
     D&D 5e (le module affiche le temps qu'il faut en sessions et en mois avec
     l'XP par session). Option « Paliers ajustés à un objectif en mois » : les
     paliers de D&D sont mis à l'échelle pour atteindre le niveau max dans le
     délai voulu, en gardant la courbe de D&D ; le nombre de sessions varie
     donc d'un niveau à l'autre (fin du « même nombre de sessions par
     niveau » de la 6.5.2). Nouveau réglage : xpThresholdMode (« dnd » par
     défaut, ou « objectif »). Voir le détail dans l'entrée v6.4.0.
   - Tableau des paliers : colonne « Hausse % » modifiable niveau par niveau
     (hausse de l'XP pour monter par rapport au niveau précédent ; vide =
     hausse de D&D). Elle remplace la surcharge « XP pour monter » en XP
     (réglage xpGrowthOverrides au lieu de xpStepOverrides). Le palier de D&D
     s'affiche au survol. Arrondi plus fin (10 / 50 / 100 XP) pour respecter
     les pourcentages ; les paliers de D&D non modifiés restent exacts.
   - Objectif en mois : curseur jusqu'à 120 mois (10 ans).
   - Bonus d'XP de plage : champ « ≈ 1 fois toutes les N sessions »
     (récurrence théorique, vide = non compté). Utilisé UNIQUEMENT dans les
     calculs de durée du tableau : colonne « XP moy. / sess. » (XP par
     session + bonus ÷ récurrence, selon la plage du niveau), sessions, mois,
     et mise à l'échelle en mode objectif. Rien n'est imposé aux MJ : la
     clôture de session propose toujours les bonus à cocher librement.
   - « Recaler l'XP des PJ » corrigé : le module retient sur quels paliers
     l'XP des PJ est comptée (réglage xpCalibration, D&D par défaut) et
     convertit depuis ceux-là, quel que soit l'ordre des changements. La
     fenêtre affiche la liste des changements (PJ, niveau, XP avant → après)
     avant validation, explique pourquoi il n'y a rien à faire le cas échéant,
     et prévient si les paliers affichés ne sont pas encore enregistrés.
     Recaler après être revenu aux paliers de D&D restaure l'XP d'origine.

v6.5.2 | 2026-10-17
   - Progression XP (D&D 5e) refondue : l'XP par session est un nombre unique
     réglé par le staff (proposé à la clôture) ; les paliers de niveau sont
     calculés (même nombre de sessions par niveau) et appliqués à la fiche
     dnd5e. Bouton « Recaler l'XP des PJ ». Réglages : xpPerSession (500),
     xpMonthsToCap (12), xpSessionsPerWeek (1), xpStepOverrides ;
     xpSessionsPerLevel, xpQuantity et xpDefaultOverrides ne sont plus utilisés.
   - Registre du monde : bannière « Nouveau lieu découvert ». Quand un lieu
     devient visible pour un joueur (découverte par le brouillard), son nom
     s'affiche en grand au centre de son écran, en lettres dorées sans fond ni
     fenêtre (police Enchanted Land), puis disparaît en fondu (≈ 5 s, sans
     bloquer les clics). Plusieurs découvertes s'enchaînent. Seuls les joueurs
     concernés ET connectés la voient (envoi ciblé par query, le message du
     chat reste la trace pour les absents). Réglages : mondeBanniere (afficher
     ou non, actif par défaut) et mondeBanniereSon (fichier audio facultatif,
     avec « Parcourir » et « Tester » qui montre la bannière sur ton écran).
   - Correctif : les réglages « Découverte des lieux par le brouillard » et
     « Prévenir le joueur d'un lieu découvert » apparaissent enfin dans la
     fenêtre « Registre du monde » (ils étaient enregistrés mais invisibles).
   - « Clore la session » : retrait du bloc « Fiches du monde concernées »
     (historique des fiches alimenté à la clôture) et de son réglage
     mondeHistoryOnClose. Les historiques déjà écrits restent sur les fiches.

v6.5.1 | 2026-10-17
   - Progression XP (D&D 5e) : le rythme se règle en mois réels pour atteindre
     le niveau max et en sessions par semaine ; le nombre de sessions par
     niveau est calculé (remplacé en 6.5.2 par les paliers calculés).
   - Casier : retrait du bouton « Réinitialiser les présentations des MJ »
     (onglet Dashboard). Les présentations ne peuvent plus être effacées en
     masse ; chaque MJ garde la sienne.

v6.5.0 | 2026-10-17
   - Nouveau : onglet « Où ranger quoi ? » dans le Casier (toujours présent).
       · Guide généré à partir des réglages réels (dossiers et compendiums
         communs, registre du monde, carte des expéditions, temps morts,
         dossiers des MJ) : où ranger les PJ, les PNJ récurrents, les
         créatures, les anciens PJ, les lieux, les objets craftables, et ce que
         chaque fonction (Relations, Bestiaire, Validation…) en fait.
       · Vérification du monde : réglages vides ou dossiers disparus, PJ de
         joueurs hors du dossier des PJ, acteurs posés sur une scène qui ne sont
         ni PNJ (dossier) ni créatures reconnues (compendium ou nom identique),
         créatures rangées dans le dossier des PNJ, lieux sans épingle. Chaque
         entrée s'ouvre d'un clic.
       · « Publier dans les journaux (MJ) » : crée le journal « 📌 Où ranger
         quoi ? (MJ) », réservé aux MJ, placé en tête de liste ; il est
         régénéré tout seul quand un réglage concerné change.
       · Nouveau fichier : modules/rangement.js. Modifiés : casier.js, index.js.
   - Nouveau : Registre du monde (catégorie de réglages « Registre du monde »,
     interrupteur éteint par défaut ; nécessite Monk's Enhanced Journal).
     Les fiches restent des fiches Monk's (PNJ = « person », lieu = « place »,
     organisation = « organization »), créées comme Monk's le fait lui-même.
       · « Rédiger la fiche » : une rubrique courte par case (réglables par type
         dans les paramètres : ajout, retrait, ordre, secret MJ). Le texte de
         la page est généré : rubriques vides omises, rubriques secrètes en
         blocs secrets natifs (jamais vus des joueurs, même page révélée ;
         l'état « révélé » d'un bloc est conservé). Glisser un acteur, un
         journal ou une scène dans une rubrique insère un lien @UUID.
         Rôle / Où le trouver alimentent aussi les champs natifs de Monk's.
       · Liens : acteur ↔ fiche PNJ (lien natif Monk's + flag fichePage),
         scène ↔ fiche lieu, lieu principal d'un PNJ et PNJ posés sur les
         cartes d'un lieu écrits dans les relations natives de Monk's.
       · Relations PJ ↔ PNJ (onglet Relations des fiches PJ) recopiées sur la
         fiche du PNJ, en bloc secret.
       · Visible par les joueurs : case à cocher (ownership par défaut
         Observateur) ; par défaut, fiches réservées aux MJ.
       · Points d'entrée : bouton d'en-tête « Fiche du monde » sur les fiches
         de PNJ, menus contextuels des acteurs, scènes (« Fiche du lieu ») et
         journaux (« Rédiger la fiche »), onglet « Monde » du Casier.
       · Onglet « Monde » du Casier : création (PNJ, lieu, organisation),
         recherche dans le nom et le contenu, filtre par type, filtre
         « modifiées depuis ma dernière session », date et auteur de la
         dernière modification, accès à l'acteur / la carte, bascule de
         visibilité, « Actualiser » (relations PJ, cartes, PNJ des cartes).
       · Épingles : un lieu est représenté par une note (épingle) posée sur la
         carte du monde (= les scènes de « Carte des expéditions »). « Voir sur
         la carte » (Casier, Rédiger) centre la vue sur l'épingle et la signale ;
         « Placer sur la carte » pose une épingle à déplacer ensuite. Le lien
         « scène ↔ lieu » ne sert plus qu'aux cartes LOCALES (intérieurs,
         donjons) ; « Fiche du lieu » n'est plus proposé sur la carte du monde.
       · Découverte par le brouillard (réglage mondeDecouverte, actif) : un lieu
         dont l'épingle est sur une case explorée par un personnage d'un joueur
         (ou sur une zone toujours éclairée) devient lisible par ce joueur
         (Observateur sur l'entrée : épingle visible, rubriques non secrètes).
         Mode par lieu : auto / toujours caché / visible par tous (Rédiger, ou
         clic sur l'icône du Casier). Recalcul automatique (MJ actif, différé)
         à chaque exploration, déplacement d'épingle, zone éclairée ou
         changement de propriétaire. Le module ne retire que les accès qu'il a
         donnés lui-même ; un accès donné à la main n'est jamais touché.
         Message privé « Nouveau lieu découvert » au joueur, une seule fois par
         lieu (réglage mondeDecouverteMessage) ; aucun message au premier calcul.
       · Sécurité des textes : une page déjà écrite dans Monk's n'est jamais
         écrasée en silence. « Rédiger » prévient et propose de garder l'ancien
         texte dans « Notes » ; les mises à jour automatiques (« Actualiser »)
         ne réécrivent pas une page modifiée à la main (les
         données sont gardées et réappliquées à la prochaine rédaction).
     Nouveaux réglages (monde) : mondeEnabled,
     mondeDecouverte, mondeDecouverteMessage, mondeFolderPerson / Place / Org
     (dossiers créés au besoin, rangement par type), mondeRubriques.
     Nouveau fichier : modules/monde.js. Modifiés : settings.js, session.js,
     casier.js, index.js, map.js (lecture de l'exploration exportée).

v6.4.0 | 2026-10-16
   - Nouvelle catégorie de réglages « Progression XP (D&D 5e) », pour jouer avec
     l'XP de base (le système d'étoiles reste disponible à la place) :
       · XP PAR SESSION : un seul nombre réglé par le staff (500 par défaut).
         C'est l'XP proposée par défaut dans « Clore la session ».
       · Sessions par semaine (0,25 à 7 ; 0,5 = une toutes les deux semaines).
       · PALIERS de niveau, au choix :
           - « Paliers officiels de D&D » (PAR DÉFAUT) : le module affiche le
             temps qu'il faut (sessions et mois réels) avec l'XP par session ;
           - « Paliers ajustés à un objectif en mois » (1 à 120 mois) : la
             courbe (D&D ou hausses modifiées) est multipliée par le facteur
             qui fait atteindre le niveau max en autant de sessions que la
             période en compte, XP moyenne par session (bonus compris). La courbe
             reste celle de D&D : peu de sessions pour les premiers niveaux,
             beaucoup pour les derniers.
         Tableau : palier, XP pour monter, hausse % (modifiable), XP moyenne
         par session (bonus compris selon leur récurrence), sessions, cumul en
         mois.
       · Les paliers en vigueur REMPLACENT ceux du système dnd5e
         (CONFIG.DND5E.CHARACTER_EXP_LEVELS) quand la progression est activée :
         le bouton de montée de niveau de la fiche les suit. Désactiver la
         progression restaure les paliers officiels. Le rapport de session
         utilise aussi ces paliers pour signaler les montées de niveau.
       · « Recaler l'XP des PJ » : convertit l'XP des PJ de joueurs depuis les
         paliers sur lesquels elle est comptée vers les paliers enregistrés, en
         gardant leur niveau et leur progression dans le niveau (aperçu des
         changements et confirmation).
       · Plages de niveaux (par défaut 1–4, 5–10, 11–16, 17–20), chacune avec
         ses bonus d'XP (nom + montant), ajoutables et supprimables.
   - « Clore la session » (interrupteur de la catégorie actif, étoiles éteintes) :
     calcule le niveau moyen de la party, pré-remplit « XP pour tous » avec l'XP
     par session, propose les bonus de la plage (selon le niveau moyen) en cases à cocher
     (non cochées) et affiche le total par PJ. Le rapport Discord gagne un champ
     « XP de la session » (base + bonus cochés + niveau moyen).
   - Niveau max autorisé sur le serveur (liste 1 à 20 ; 20 = aucun verrou),
     actif même interrupteur éteint : l'XP d'un PJ est plafonnée au palier de
     ce niveau (sans retirer d'XP déjà acquise), toute montée au-delà est
     refusée, MJ compris (classe ou multiclasse). Le système d'étoiles s'arrête
     aussi à ce niveau. Un PJ déjà au niveau max reçoit 0 XP à la clôture.
   - Nouveaux réglages (monde) : xpProgEnabled, xpLevelCap, xpPerSession,
     xpThresholdMode, xpMonthsToCap, xpSessionsPerWeek, xpGrowthOverrides,
     xpBonusRanges.
   - Nouveau fichier : modules/xpprogress.js. Modifiés : settings.js,
     session.js, starxp.js, index.js.

v6.3.1 | 2026-10-16
   - Site : au premier lancement puis après chaque mise à jour, les MJ reçoivent
     un message privé dans le chat avec le lien de la page du module sur le site
     d'Althéia (nouveautés, mises à jour, licence). Une fois par version et par
     monde ; les joueurs ne le voient pas.
   - « À propos » : ajout du lien vers la page du module.
   - Nouveau fichier : modules/site.js.

v6.3.0 | 2026-10-16
   - Licence : le code d'activation est remplacé par une CLÉ DE LICENCE
     personnelle (ALT-XXXX-XXXX-XXXX-XXXX), vérifiée par le serveur
     licence.altheia.eu. Chaque clé autorise un nombre limité de mondes et peut
     être révoquée. Saisie au premier lancement (fenêtre MJ) ou depuis
     « À propos », qui affiche aussi l'état de la licence.
   - La clé n'est pas conservée dans le monde : seul un jeton signé, lié au
     monde et valable 7 jours, y est stocké. Renouvellement automatique une fois
     par jour par le MJ actif ; les joueurs ne contactent jamais le serveur.
   - Période de grâce : si le serveur est injoignable, le module continue de
     fonctionner jusqu'à l'échéance du jeton (avertissement au MJ 2 jours avant).
     Un monde resté fermé plus longtemps renouvelle son jeton seul au retour du MJ.
   - Nouveau fichier : modules/licence.js. Retrait de l'ancien code d'activation
     (const.js). Le code de désactivation de « À propos » est inchangé.

v3.2.4 | 2026-08-04
   - Reglages : bandeau "droits & version" en tete de chaque fenetre de reglages.

v3.2.3 | 2026-08-04
   - Temps morts : reprise des apports du module autonome "downtime". Table des
     multiplicateurs du test de competence desormais editable (reglages), au lieu
     du code en dur ; interrupteur Reliable Talent (tmReliableTalent) ; champ
     "Bonus au jet" (valeur fixe ou des + provenance) ajoute au test, pris en compte
     dans l'apercu et le calcul. (const.js, settings.js, tm.js)

v3.2.2 | 2026-08-04
   - Diagnostic (carte des expeditions) : logs console [CE] au changement de
     personnage assigne, pour tracer la synchro d'ownership et la permutation de
     fog. (map.js)

v3.2.1 | 2026-08-04
   - Controle des sources : nouveau reglage "Champ compare" (menu deroulant) pour
     choisir si les listes portent sur le champ Book (livre) ou Identifier
     (identifiant precis de l'objet), ou les deux. (sourcecontrol.js, settings.js)

v3.2.0 | 2026-08-04
   - Controle des sources : filtrage par TYPE au sein d'une source. Syntaxe des
     listes : "Source" (tous types) ou "Source : type1, type2" (entrees separees
     par ";"). Types : race, classe, sous-classe, don, sort, historique, objet.
     Permet ex. d'autoriser seulement les races d'un livre mais pas ses sous-classes.
     Retro-compatible avec l'ancienne liste par virgules. (sourcecontrol.js, settings.js)

v3.1.9 | 2026-08-04
   - Controle des sources : nouveau reglage "Correspondance exacte des sources"
     (active par defaut). En exact, "PHB" n'autorise pas "XPHB" (PHB 2024) et les
     sources proches ne sont plus confondues. Mode souple (contient) disponible en
     option. (sourcecontrol.js, settings.js)

v3.1.8 | 2026-08-04
   - Nouveau : Controle des sources. Reglemente les livres/extensions D&D
     (Xanathar, Tal'Dorei, etc.) autorises sur les fiches PJ via deux listes
     blanches distinctes (joueurs / MJ). Le contenu d'une source non autorisee est
     bloque + avertissement, quelle que soit la methode d'ajout (Plutonium/5etools,
     glisser-deposer, manuel). Detection via system.source + flags. Option de
     blocage du contenu sans source. (sourcecontrol.js, settings.js, index.js)

v3.1.7 | 2026-08-04
   - Cues audio : correction d'affichage — la grille Depart/Volume/Fondu/Boucle et
     la ligne Declencheur ne se chevauchent plus (espacement vertical du corps du
     cue). (sceneaudio.css)

v3.1.6 | 2026-08-04
   - Rapports de session Discord : prise en charge des salons de type Forum
     (nouveau reglage "Salon Discord de type Forum"). Les rapports sont regroupes
     dans un post (fil) de forum par meneur, cree au 1er rapport puis reutilise
     (thread_id memorise). Salon textuel classique inchange. (settings.js, session.js)

v3.1.5 | 2026-08-04
   - Carte des expeditions : fiabilisation de la sauvegarde de fog quand l'onglet
     du joueur est en arriere-plan (navigateur qui throttle). Le GM pilote
     desormais le client concerne via des queries : commit force de la fog avant
     un changement de PJ, rechargement apres, et commit force apres chaque
     deplacement d'un token de groupe. Corrige "au changement de PJ j'ai la fog du
     PJ precedent". (map.js)

v3.1.4 | 2026-08-04
   - Carte des expeditions : la fog est desormais PERSONNELLE par personnage et
     unique pour toutes les expeditions (conservee et cumulative). Le token de
     groupe ne sert qu'a indiquer qui explore ; il ne partitionne plus la fog.
     Cle de sauvegarde = personnage seul, avec migration des anciennes cles
     "perso:groupe". (map.js)

v3.1.3 | 2026-08-04
   - Carte des expeditions : le MJ peut explorer POUR des joueurs hors-scene. En
     deplacant un token de GROUPE selectionne sur la scene, son exploration est
     enregistree dans la fog des membres du groupe qui ne regardent pas la scene
     (hors-ligne / autre scene), persistee par personnage. Necessite Vision par
     token sur la scene. (map.js)

v3.1.2 | 2026-08-04
   - Carte des expeditions : nouveau reglage "Dossier du token modele" — l'acteur
     Groupe modele est cree dans le dossier d'acteurs choisi (cree le dossier si
     nom libre inexistant). (settings.js, map.js)

v3.1.1 | 2026-08-04
   - Carte des expeditions : creation auto d'un acteur Groupe modele
     "Token a copier et rennomer" (token non lie + vision activee) et depot d'un
     exemplaire sur la scene configuree, pret a copier/renommer (idempotent). (map.js)

v3.1.0 | 2026-08-04
   - Casier / Suivi des GM : cliquer sur le pseudo d'un GM affiche uniquement
     son dashboard (stats + presentation) ; bouton retour. Presentation editable
     seulement pour son propre casier, sinon lecture seule. (casier.js, casier.css)

v3.0.9 | 2026-08-04
   - Creation de perso : quand un GM cree un PJ directement dans le sous-dossier
     d'un joueur (Dossier des PJ), les etapes de demande/validation sont sautees
     — la fiche est d'emblee validee, verrouillee et attribuee au joueur
     (proprietaire). (charvalidation.js)

v3.0.8 | 2026-08-04
   - Dossiers : nouveau reglage "Sous-dossier auto au nom du joueur". A la
     premiere connexion d'un joueur, le GM cree automatiquement dans le Dossier
     des PJ un sous-dossier a son nom (idempotent). (settings.js, charvalidation.js)

v3.0.7 | 2026-08-04
   - Temps morts / Craft : le champ "Nom" est desormais en lecture seule et ne
     fait qu'afficher l'objet choisi dans le compendium (clic sur le champ ou
     l'icone livre pour choisir). Plus de saisie libre (tm.js).

v3.0.6 | 2026-08-04
   - Note GM : onglet restyle (en-tete avec icone + titre + badge "Prive", zone de
     notes en panneau "papier", focus dore) au lieu du textarea brut
     (character-sheet.js, gmnotes.css).

v3.0.5 | 2026-08-04
   - Tutoriel (Mes personnages) : ajout d une etape d intro qui explique tout le
     principe du circuit (demande -> validation -> construction -> soumission ->
     verrouillage ; montee de niveau ; limites & stock), en plus des etapes
     d interface (tutorial.js).

v3.0.4 | 2026-08-04
   - Validation des personnages : dans "Mes personnages", le bouton "Monter de
     niveau" ne s affiche que si le PJ a atteint le seuil d XP (value >= max)
     (charvalidation.js).

v3.0.3 | 2026-08-04
   - Tutoriel : la fenetre de bienvenue ne propose plus que "Commencer le
     tutoriel" (bouton "Plus tard" retire ; fermeture via la croix) (welcome.js).

v3.0.2 | 2026-08-04
   - Validation des personnages : nouveau reglage "Bloquer les imports Plutonium
     hors autorisation" (defaut on). Sur une fiche VERROUILLEE, un joueur ne peut
     pas importer de contenu Plutonium (items marques du flag plutonium) ; l import
     n est possible que pendant une creation ou une montee de niveau autorisee par
     le MJ. GM jamais bloque (charvalidation.js, settings.js).

v3.0.1 | 2026-08-04
   - Tutoriel : les sections reservees aux joueurs (Mes personnages, Temps morts)
     sont cachees aux GM (elles y seraient vides). Nouvelle notion
     SECTION_PLAYER_ONLY (tutorial.js).

v3.0.0 | 2026-08-04
   - Version : passage en 3.0.0 (retenue — le versionnage ne depasse pas 9 par
     chiffre : 2.9.9 -> 3.0.0).
   - Tutoriel : la section "Note GM" passe apres "Carnet & Expeditions" dans l
     ordre de passage (tutorial.js).

v2.16.10 | 2026-08-04
   - Tutoriel : "Temps morts" n apparait plus qu une fois cote GM. L etape du
     Casier est placee entre Expeditions et Suivi des GM ; l etape de validation
     en double (section Temps morts) est retiree (tutorial.js).

v2.16.9 | 2026-08-04
   - Tutoriel : "Ne plus afficher" deplace de la fenetre de bienvenue vers la FIN
     du guide (propose seulement quand il est termine) — la fenetre de bienvenue
     n a plus que "Commencer" et "Plus tard" (welcome.js, tutorial.js).

v2.16.8 | 2026-08-04
   - Tutoriel : les fenetres de bienvenue et de selection affichent un
     avertissement invitant a fermer toutes les fiches/fenetres ouvertes avant de
     lancer le guide (welcome.js).

v2.16.7 | 2026-08-04
   - Readme : mise a jour des sections descriptives (architecture, features,
     reglages) pour refleter toutes les nouveautes (Casier, validation des
     personnages, cues audio, note GM, statut PJ, pause de party, dossiers &
     compendiums communs...).

v2.16.6 | 2026-08-04
   - Casier / Validation : les fiches a valider indiquent desormais s il s agit
     d une "Creation" (verte) ou d une "Montee de niveau" (bleue) — une fiche deja
     validee qui revient = montee de niveau (charvalidation.js, casier.js,
     charvalidation.css).

v2.16.5 | 2026-08-04
   - Validation des personnages : pendant la CREATION (fiche non encore
     verrouillee), xp.js laisse le joueur construire librement (XP, niveau,
     classe) au lieu de bloquer "level up non autorise". Le blocage ne s applique
     qu une fois la fiche validee & verrouillee (xp.js).

v2.16.4 | 2026-08-04
   - Validation des personnages : les persos valides sont crees dans un
     sous-dossier au NOM DU JOUEUR, a l interieur du dossier parent configure
     (ex. Joueurs / Gauthier). Le sous-dossier est cree au besoin (charvalidation.js).

v2.16.3 | 2026-08-04
   - Validation des personnages : la fenetre "Mes personnages" liste desormais
     TOUS les persos du joueur — y compris ceux crees a la main par le MJ (via la
     propriete du joueur), pas seulement ceux issus d une demande. Statut
     "jouable" pour ces persos hors circuit, avec option de soumission
     (charvalidation.js).

v2.16.2 | 2026-08-04
   - Validation des personnages : badge "En construction" (orange) sur la ligne de
     l acteur tant qu une montee de niveau est autorisee (fiche deverrouillee pour
     edition), jusqu a la re-validation (charvalidation.js, charvalidation.css).

v2.16.1 | 2026-08-04
   - Temps morts : suppression des messages "ajouter l objet a la main" (l objet
     s importe desormais automatiquement du compendium). Message de fin de craft
     simplifie ; plus de rappel manuel au demarrage (tm.js).

v2.16.0 | 2026-08-04
   - Tutoriel : mise a jour complete avec les nouvelles fonctionnalites. Nouvelles
     sections — Note GM (GM), Mes personnages (joueur : demande/soumission/stock),
     Cues audio (GM). Le Casier gagne les etapes onglets Temps morts et Validation.
     L etape de validation des temps morts pointe desormais le Casier (l ancien
     bouton de barre ayant ete retire). Toutes les etapes pointent l element
     concerne (const.js, tutorial.js, settings.js, charvalidation.js).

v2.15.2 | 2026-08-04
   - Casier / Temps morts : suppression du scroll interne (55vh) dans le panneau
     embarque, pour un scroll unique et fluide via la colonne du Casier (tm.js).

v2.15.1 | 2026-08-04
   - Fiche PJ : nouveau reglage "Masquer l onglet etoile aux joueurs" (Serveur).
     Cache l onglet a icone etoile (favoris) sur les fiches, cote joueurs
     uniquement ; les GM le voient toujours (character-sheet.js, settings.js).

v2.15.0 | 2026-08-04
   - Fiche PJ : onglet "Note GM" (reglage Serveur). Ajoute un onglet prive sur les
     fiches de personnage, visible et editable uniquement par les GM (la part
     n existe pas pour les joueurs). Notes stockees sur l acteur (flag gmNotes)
     (character-sheet.js, character-gmnotes.hbs, gmnotes.css, settings.js).

v2.14.0 | 2026-08-04
   - Casier : l onglet "Temps morts" embarque directement le panneau de validation
     (liste des declarations, recherche, modifier/refuser) et un bouton
     "Appliquer les gains" — plus besoin d ouvrir une fenetre separee. openDowntime
     refactorise en fonctions reutilisables (tm.js, casier.js).

v2.13.0 | 2026-08-04
   - Validation des personnages : limites & stock. Deux reglages — "Nombre de
     personnages max par joueur" (0 = illimite) et "Personnages actifs simultanes"
     (defaut 2). Au-dela du nombre d actifs, les persos passent EN STOCK : cadenas
     dans la fenetre "Mes personnages", ownership Observateur (non jouable),
     badge "Stock" sur la ligne de l acteur. Boutons Activer / Mettre en stock
     (changement d ownership via requete au GM). Le total limite le nombre de
     demandes de creation (charvalidation.js, settings.js, charvalidation.css).

v2.12.0 | 2026-08-04
   - Validation des personnages : MULTI-PERSONNAGES. La fenetre "Mes personnages"
     liste tous les persos du joueur (statut + actions) et un bouton "Demander un
     nouveau personnage" permet d en demander plusieurs (2e, 3e...). Chaque perso
     a ses propres actions (ouvrir, soumettre, monter de niveau).
   - Verrou : re-affichage de la fiche apres un blocage, pour que la valeur
     saisie (affichage optimiste) revienne bien a l etat verrouille reel
     (charvalidation.js, charvalidation.css).

v2.11.0 | 2026-08-04
   - Reglages : nouvelle section "Dossiers & Compendiums" en tete, qui regroupe
     en un seul endroit les dossiers/compendiums communs (PJ, PNJ, cimetiere,
     creatures, objets craftables, nouveaux persos). Les champs dupliques ont
     ete retires des sections Relations/Bestiaire/Temps morts/Creation de perso ;
     toutes les fonctions lisent ces valeurs centrales. Les valeurs deja saisies
     sont recopiees automatiquement (migration unique). (settings.js, relations.js,
     bestiary.js, tm.js, charvalidation.js, index.js).

v2.10.1 | 2026-08-04
   - Tutoriel (Caracteristiques) : le halo cible desormais directement les six
     cases de caracteristiques (une par capacite) au lieu du conteneur qui
     debordait sur les Skills/Saves (tutorial.js).

v2.10.0 | 2026-08-04
   - Validation des personnages : flux de MONTEE DE NIVEAU. Le joueur demande une
     montee de niveau (bouton dans "Mon personnage", fiche verrouillee) -> badge
     "Level up" sur la ligne de l acteur -> le GM autorise depuis le Casier
     (onglet Validation, section Montees de niveau) : la fiche se deverrouille et
     xp.js laisse passer la montee (flag levelUpGranted) -> le joueur monte de
     niveau puis re-soumet -> re-validation re-verrouille. (charvalidation.js,
     xp.js, casier.js).

v2.9.6 | 2026-08-04
   - Validation des personnages : badge "En creation" (violet) affiche des qu une
     fiche est creee pour un joueur et pas encore validee (avant meme la
     soumission) ; "A valider" quand soumise. Rafraichi a la creation de l acteur
     (charvalidation.js, charvalidation.css).

v2.9.5 | 2026-08-04
   - Temps morts : la fenetre de declaration du joueur ne depasse plus l ecran.
     Le contenu est borne (max-height 74vh) et devient scrollable, gardant les
     boutons Declarer/Ajouter accessibles (tm.js).

v2.9.4 | 2026-08-04
   - Tutoriel : la bulle ne sort plus de l ecran quand la cible est collee a un
     bord (clamp final sur les deux axes en plus du flip) (tutorial.js).

v2.9.3 | 2026-08-04
   - Casier : les temps morts ont desormais leur propre ONGLET "Temps morts"
     (avec compteur de declarations en attente) au lieu d un simple bouton sur
     le dashboard (casier.js, settings.js).

v2.9.2 | 2026-08-04
   - Reglages : la validation des personnages a desormais sa propre section
     "Creation de personnages" (au lieu d etre dans Systeme de Party)
     (settings.js).

v2.9.1 | 2026-08-04
   - Validation des personnages : le reglage "Dossier des personnages" est un
     selecteur de dossier (stocke un id) ; ensureFolder accepte desormais id ou
     nom, avec repli sur "Personnages" (charvalidation.js).

v2.9.0 | 2026-08-04
   - Artisanat : selecteur d objet lie au compendium. Dans le formulaire de craft,
     un bouton (livre) ouvre la liste des objets du compendium configure avec
     barre de recherche ; le choix remplit le nom, le prix et memorise l objet
     exact (uuid). A la fin du craft, CET objet est ajoute a la fiche (repli sur
     recherche par nom si aucun objet n a ete choisi) (tm.js).

v2.8.0 | 2026-08-04
   - Temps morts : la fenetre GM s ouvre desormais depuis le Casier (bouton
     "Temps morts" du dashboard) ; l icone dediee est retiree de la barre
     WestMarch (tm.js, casier.js).
   - Artisanat : a la fin d un craft, l objet est ajoute AUTOMATIQUEMENT a la
     fiche du joueur, cherche par nom dans un compendium d objets configure
     (reglage "Artisanat — Compendium des objets craftables"). Introuvable =
     rappel manuel comme avant (tm.js, settings.js).

v2.7.0 | 2026-08-04
   - Nouveau : Validation des personnages (tickets). Le joueur demande la
     creation d un perso (bouton "Mon personnage" dans la barre WestMarch) ;
     n importe quel GM valide depuis le Casier (onglet Validation) -> un acteur
     est cree dans un dossier dedie, le joueur en devient proprietaire. Il le
     construit (imports Plutonium compris) puis le soumet ; a la validation la
     fiche est VERROUILLEE : construction non modifiable cote joueur (caracs,
     maitrises, classe/espece/historique/aptitudes/sorts appris), jeu libre
     (tout ce que surveille anticheat + PV, monnaie, conditions...). Un badge
     "A valider" / "Level up" s affiche sur la ligne de l acteur, entre le nom
     et le statut d expedition. Respec/level-up prevus pour plus tard
     (charvalidation.js, charvalidation.css, casier.js, settings.js, index.js).

v2.6.0 | 2026-08-04
   - Cues audio : le gestionnaire gagne des SECTIONS (en-tetes repliables qui
     regroupent les cues) et le repli/depli de chaque cue, plus des fleches
     monter/descendre pour organiser. Etat de repli et ordre memorises
     (sceneaudio.js, sceneaudio.css).

v2.5.2 | 2026-08-04
   - Tutoriel (Caracteristiques) : le halo ne prend plus que la rangee des six
     boucliers (.ability-scores .bottom) au lieu de tout le conteneur qui
     debordait sur les Skills/Saving Throws (tutorial.js).

v2.5.1 | 2026-08-04
   - Tutoriel : l etape sur l Inspiration heroique precise qu elle ne vient pas
     que du MJ (aussi aptitudes, especes, autres sources) (tutorial.js).

v2.5.0 | 2026-08-04
   - Carnet : police de l editeur de notes remplacee par Perry Gothic
     (fonts/PerryGothic.ttf). Declaree via CONFIG.fontDefinitions (dispo aussi
     dans le menu de police de l editeur) (index.js, styles/carnet.css).

v2.4.1 | 2026-08-04
   - Pause de party : correction "jeu coince en pause". Une pause GLOBALE
     residuelle est levee au chargement, et la barre espace leve d abord une
     eventuelle pause globale avant de basculer la party (l interception ne peut
     plus laisser une pause globale coincee) (partypause.js).

v2.4.0 | 2026-08-04
   - Cues audio : navigateur de playlists. Un bouton note de musique a cote du
     champ fichier ouvre la liste des sons des playlists du MONDE et des
     COMPENDIUMS, avec ecoute locale (le MJ essaie sans que les joueurs
     entendent) et bouton Choisir qui remplit le fichier du cue (le chemin du
     son est reutilise directement, sans import) (sceneaudio.js, sceneaudio.css).

v2.3.4 | 2026-08-04
   - Pause de party : correction de la pause bloquee sur "activee". Interception
     fiable de la barre espace en phase de capture (avant le KeyboardManager de
     Foundry) pour que le pause global ne parte jamais, + anti-double-bascule
     (evite que capture clavier et game.togglePause s annulent). Le filet de
     securite se contente desormais d annuler une pause globale parasite sans
     toucher a l etat de party (partypause.js).

v2.3.3 | 2026-08-04
   - Pause de party : affichage via le banner NATIF #pause ("Game Paused") au
     lieu d un bandeau maison. Meme apparence que Foundry et compatibilite avec
     les modules d habillage de la pause (glow bleu de Monk, etc.). Le banner
     natif n est plus masque ; il est revele localement pour les membres de la
     party en pause (partypause.js, partypause.css).

v2.3.2 | 2026-08-04
   - Pause de party : filet de securite. Si une pause GLOBALE s active malgre le
     detournement de game.togglePause (macro, socket, module tiers), le GM actif
     l annule aussitot et bascule a la place la pause de sa party — plus de
     "pause qui stoppe toute la table" (partypause.js).

v2.3.1 | 2026-08-04
   - Cues audio : diffusion limitee a la PARTY du GM (flag partyId) au lieu de
     toute la table. Chaque client lisant le son en local, on ne notifie que les
     membres de la party (emetteur inclus). Si le systeme de Party est desactive,
     diffusion a tous comme avant (sceneaudio.js).

v2.3.0 | 2026-08-04
   - Cues audio : refonte en gestionnaire central. Nouveau bouton "Cues audio"
     dans la barre WestMarch (GM) ouvrant une fenetre de gestion. Les cues sont
     stockes au niveau du monde (survivent a la suppression du token). Chaque
     cue a un declencheur : Manuel, Revelation du token lie, ou Debut de combat.
     On lie un cue au token selectionne ; depuis le HUD du token on rejoue les
     cues lies. Prechargement + diffusion locale via queries v13. Remplace la
     config par-token (sceneaudio.js, sceneaudio.css, settings.js).

v2.2.1 | 2026-08-04
   - Cues audio : correction de la mise en page de la ligne "Fichier audio"
     (input ecrase par le bouton parcourir) (sceneaudio.css, sceneaudio.js).

v2.2.0 | 2026-08-04
   - Nouveau : Mise en scene — Cues audio. Attache a un token un cue audio
     (fichier, seconde de depart, volume, fondu, boucle) via un bouton dans son
     HUD. Le son part pour tous les joueurs quand le token perd son invisibilite
     GM (hidden true->false), ou manuellement ("Jouer pour tous"). Lecture locale
     sur chaque client via queries v13 (faible latence), prechargement au
     chargement de la scene. Categorie de reglages dediee, sans lien avec un
     autre module (sceneaudio.js, sceneaudio.css, settings.js, index.js).

v2.1.1 | 2026-08-04
   - Tutoriel (Expeditions) : ajout d une etape sur le Statut de disponibilite
     des PJ. Ouvre le repertoire des Acteurs et pointe le badge du perso demo
     (tutorial.js, pcstatus.css).

v2.1.0 | 2026-08-04
   - Nouveau : Statut de disponibilite des PJ. Un badge "Disponible" /
     "En expedition" s affiche a droite de chaque personnage dans le repertoire
     des Acteurs. Statut deduit automatiquement des expeditions (une expedition
     ouverte = En expedition). Activable dans Fiche PJ > Carnet & Expeditions
     (pcstatus.js, pcstatus.css).

v2.0.0 | 2026-08-04
   - Manifeste : suppression de la cle "fonts" (non reconnue par le schema
     Foundry v13/v14 → avertissement Package Warnings). La police Enchanted
     Land est desormais enregistree par code via CONFIG.fontDefinitions au
     hook init (index.js).

v1.9.9 | 2026-08-04
   - Tutoriel (Tour de la fiche) : ordre Inventaire avant Aptitudes, et ajout
     d une etape "Effets" apres les Sorts (tutorial.js).

v1.9.8 | 2026-08-04
   - Fiche demo tutoriel : correction du bug qui empechait sa (re)creation. Un
     echec de fetch marquait faussement la fiche comme creee ; desormais le
     succes n est enregistre qu apres un Actor.create confirme, l ancienne
     fiche n est supprimee qu apres creation de la nouvelle, et un suivi de
     version (tutorialActorVersion) permet de retenter tant que la creation a
     echoue (demoactor.js, settings.js).

v1.9.7 | 2026-08-04
   - Calendrier : passage a Mini Calendar. Le module lisait deja l API native
     game.time.calendar (aucune dependance Simple Calendar reelle) ; nettoyage
     des references residuelles a SimpleCalendar dans carnet.js et mise a jour
     de la dependance recommandee (module.json, readme).

v1.9.6 | 2026-08-04
   - Tutoriel (Tour de la fiche) : fusion des etapes "Niveau & experience" et
     "Repos & inspiration" en une seule etape "Niveau, experience & repos"
     (zone .right de l en-tete + barre d exp) (tutorial.js).

v1.9.5 | 2026-08-04
   - Tutoriel : correction du spotlight multi-zones. Le masque CSS ne decoupait
     pas les trous (alpha) ; remplace par un SVG en regle evenodd (vrais trous,
     clics traversants dans les zones eclairees) (tutorial.js).

v1.9.4 | 2026-08-04
   - Tutoriel (Tour de la fiche) : etape "Caracteristiques" calee sur
     section.ability-scores (confirme via inspection) (tutorial.js).

v1.9.3 | 2026-08-04
   - Tutoriel (Relations) : ordre des etapes inverse — "Reveler a la party"
     passe avant "Rendre anonyme" (tutorial.js).

v1.9.2 | 2026-08-04
   - Tutoriel (Tour de la fiche) : etape caracteristiques/competences scindee en
     deux — "Caracteristiques" (rangee du haut .ability-scores) et "Competences"
     (colonne .left) (tutorial.js).

v1.9.1 | 2026-08-04
   - Casier (Dashboard) : retrait de la case "Party active" (casier.js).

v1.9.0 | 2026-08-04
   - Fiche demo tutoriel (v8) : construite a partir d un personnage complet livre
     dans le module (data/tutorial-actor.json — Clerc 12, ~150 objets dont sorts).
     Overrides a la creation : image forcee (icone du coeur), ownership Aucun,
     dossier Tutoriel, flags demo (relations/bestiaire/notes/expeditions).
     demoactor.js charge le JSON via fetch.

v1.8.4 | 2026-08-04
   - Tutoriel : le spotlight supporte plusieurs cibles (step.targets = liste) via
     un masque SVG (un trou par zone). L etape "Niveau & experience" eclaire en
     forme de L la barre d XP (.meter.exp) ET le rond du niveau (tutorial.js).

v1.8.3 | 2026-08-04
   - Tutoriel (Tour de la fiche) : les caracteristiques/competences pointent la
     colonne gauche (.left) ; nouvelle etape "Jets de sauvegarde & defense" sur
     tout le bloc .saves (filigree-box), texte precisant defense = jet de
     sauvegarde OU CA (tutorial.js).

v1.8.2 | 2026-08-04
   - Tutoriel (Tour de la fiche) : etape en-tete scindee en deux — "Niveau &
     experience" (badge + barre XP) et "Repos & inspiration heroique" (boutons
     repos court/long, inspiration) (tutorial.js).

v1.8.1 | 2026-08-04
   - Tutoriel (Tour de la fiche) : selecteurs cales sur le DOM reel du sheet
     dnd5e2 : CA = .ac-badge, init/vitesse/maitrise = .lozenges, PV/des de vie =
     les deux .meter-group de .stats, en-tete = .sheet-header (tutorial.js).

v1.8.0 | 2026-08-04
   - Tutoriel (Tour de la fiche) : l etape "Les onglets de la fiche" ciblait par
     erreur la barre laterale (repertoire Acteurs). Elle vise desormais la barre
     d onglets du sheet via nav.tabs:has([data-tab=features]) (tutorial.js).

v1.7.9 | 2026-08-04
   - Tutoriel (Tour de la fiche) : selecteurs des champs affines pour le sheet
     dnd5e2 (.ac, .meter.hit-points, .meter.hit-dice, .meter.exp, data-ability).
     Certains restent a confirmer selon la version (tutorial.js).

v1.7.8 | 2026-08-04
   - Tutoriel (Tour de la fiche) : l etape "Le nom du personnage" ne pointe plus
     toute la barre de titre (.window-title) mais l element du nom du sheet
     (.document-name) (tutorial.js).

v1.7.7 | 2026-08-04
   - Tutoriel (Apparence des tokens) : les etapes ouvrant le Prototype Token
     (Ouvrir le Prototype Token, Cycle d apparences, Wild Shape/Polymorph) sont
     desormais gmOnly (les joueurs n ont pas les permissions). L etape "Voir le
     portrait" reste visible pour tous (tutorial.js).

v1.7.6 | 2026-08-04
   - Tutoriel : nouvelle section "Tour de la fiche" (avant le Bestiaire) qui
     ouvre la fiche demo et pointe nom, portrait, niveau/classe/XP, CA,
     initiative/vitesse/maitrise, PV, des de vie, caracteristiques, la barre
     d onglets, puis Aptitudes / Inventaire / Sorts / Biographie. Selecteurs de
     champs avec repli (bulle centree si non trouve) ; onglets surs
     (const.js, settings.js, tutorial.js).

v1.7.5 | 2026-08-04
   - Fiche demo tutoriel (v7) : ajout de monnaie (3 pp, 245 po, 60 pa, 40 pc).
     Recreation auto (demoactor.js).

v1.7.4 | 2026-08-04
   - Fiche demo tutoriel (v6) : ajout d aptitudes (features, type feat) —
     aptitudes de classe (Style de combat, Ennemi jure, Explorateur-ne, Attaque
     supplementaire, Ombres du Feywild), traits d espece (Vision dans le noir,
     Ascendance feerique) et historique. Recreation auto (demoactor.js).

v1.7.3 | 2026-08-04
   - Fiche demo tutoriel (v5) : l espece (Demi-elfe) et l historique (Ermite)
     recoivent un identifiant + une description pour etre correctement rattaches
     par dnd5e. Recreation auto de la fiche demo (demoactor.js).

v1.7.2 | 2026-08-04
   - Tutoriel (Relations, GM) : ajout de deux etapes apres "Bloquer/Retirer" :
     "Rendre anonyme" (fa-eye-slash) et "Reveler a la party" (fa-eye) (tutorial.js).

v1.7.1 | 2026-08-04
   - Tutoriel : nouvelle section GM "Casier du MJ" (ouvre le Casier et pointe
     Dashboard, presentation, Rapports, Expeditions, Suivi des GM). Une etape
     "Clore la session" est ajoutee en fin de section Carnet/Expeditions, juste
     avant la section Casier (const.js, settings.js, tutorial.js).

v1.7.0 | 2026-08-04
   - Relations : le selecteur d ajout propose desormais, en plus des dossiers
     PJ/PNJ, les acteurs de DEUX compendiums choisis en reglages (menus
     deroulants) : "Compendium des PNJ" (groupe PNJ) et "Compendium cimetiere
     des joueurs" (groupe Joueurs). Ajout par simple reference (nom+image, aucun
     acteur cree). Regroupement par source (relations.js, settings.js : nouveau
     controle compendium + packOptionsHtml).

v1.6.8 | 2026-08-04
   - Relations : suppression du reglage inutilise "Dossier des creatures"
     (vestige de l ancien module Relations, jamais utilise ; les creatures relevent du
     Bestiaire). Retire de settings.js, relations.js et migration.js.

v1.6.7 | 2026-08-04
   - Tutoriel : les etapes "Bloquer l ajout automatique" et "Retirer de chez
     tous les joueurs" sont desormais gmOnly (masquees pour les joueurs, ces
     boutons etant reserves au GM) (tutorial.js).

v1.6.6 | 2026-08-04
   - Fiche demo tutoriel (v4) : ownership par defaut "Aucun". Au lancement du
     tutoriel, le participant devient Proprietaire de la fiche demo (les joueurs
     passent par une requete au GM) ; a la fermeture (croix / Echap / derniere
     etape) il repasse en "Aucun". Query completed-westmarch.setDemoOwnership
     (demoactor.js, serveur-socket.js, tutorial.js).

v1.6.5 | 2026-08-04
   - Fiche demo tutoriel (v3) : ownership par defaut passe a Proprietaire (au
     lieu d Observateur) pour que les onglets Relations/Bestiaire/Carnet se
     presentent en mode editable comme une fiche de joueur normale. Recreation
     auto (demoactor.js).

v1.6.4 | 2026-08-04
   - Tutoriel : cliquer en dehors de la bulle (zone assombrie / fond) ne met
     plus fin au tutoriel. Fermeture uniquement via le bouton croix ou Echap
     (tutorial.js).

v1.6.3 | 2026-08-04
   - Tutoriel bestiaire : l etape "Consulter une entree" pointe desormais le
     chevron (.bst-toggle) au lieu d une bulle centree sans cible (tutorial.js).

v1.6.2 | 2026-08-04
   - Temps morts (validation GM) : ne trouvait les PJ que dans un dossier nomme
     "PJ". Desormais repli sur TOUS les personnages possedes par un joueur si
     aucun dossier "PJ" n est utilise (corrige "Aucun personnage joueur
     trouve") (tm.js).

v1.6.1 | 2026-08-04
   - Bouton barre WestMarch : "Temps morts — Gains" renomme en "Temps morts" (tm.js).

v1.6.0 | 2026-08-04
   - Fiche demo du tutoriel enrichie (v2) : aventurier niveau 12 complet
     (classe Rodeur/sous-classe/historique/race, equipement, bio,
     caracteristiques) + relations, bestiaire, notes et expeditions improvises
     et AUTO-SUFFISANTS (aucun acteur externe, aucun impact serveur ; les
     expeditions demo n ont pas de gmId donc n apparaissent pas dans le Casier).
     Montee de version auto : l ancienne fiche demo est remplacee (demoactor.js).
   - Relations : ajout d un groupe "Autres" pour les relations dont la cible
     n est pas dans un dossier PJ/PNJ (corrige aussi les relations orphelines)
     (relations.js).

v1.5.7 | 2026-08-04
   - Casier (Dashboard) : placeholder de la presentation, "vos regles maison"
     remplace par "vos criteres" (casier.js).

v1.5.6 | 2026-08-04
   - formatDate (carnet) : gere le retour objet {date,time} de Simple Calendar
     (formatDateTime) et renvoie toujours une chaine (corrige "[object Object]"
     sur les dates quand Simple Calendar est actif).
   - Casier / Expeditions en cours : n affiche que les expeditions dont le GM
     courant est le MJ (tag gmId), les anciennes non taguees ne sont plus
     listees (casier.js).

v1.5.5 | 2026-08-04
   - Suivi des GM : affiche desormais, par GM, le nombre d expeditions EN COURS
     (taguees a ce GM), avec le nom de chacune et la liste des joueurs qui y
     participent (casier.js / casier.css).

v1.5.4 | 2026-08-04
   - Casier : correction "[object Object]" dans Expeditions et Suivi des GM. Les
     dates d expedition (objet {day,month,year}) sont desormais formatees via
     carnet.formatDate ; cle de regroupement basee sur la date serialisee.

v1.5.3 | 2026-08-04
   - Casier : l onglet "Sessions" devient "Expeditions" et liste les expeditions
     EN COURS du GM (issues de l onglet Expedition), regroupees par expedition ;
     badge "En session" sur celle dont des participants sont dans la party
     actuelle du GM. Les expeditions sont taggees au GM createur (carnet.js).

v1.5.2 | 2026-08-04
   - Rapports de session en attente : pastille de notif sur le bouton Casier
     (par GM, aucun suivi inter-GM des rapports) + message chuchote a soi-meme
     (self-roll) a la connexion avec un bouton Ouvrir le Casier. Le badge se
     rafraichit a l enregistrement/envoi/suppression d un brouillon (casier.js,
     casier.css, session.js).

v1.5.1 | 2026-08-04
   - Casier : deux onglets ajoutes. "Dashboard" (par defaut) avec le nom du GM,
     un recap (rapports en attente, party active, sessions ouvertes) et une
     presentation editable persistante (reglage casierProfiles). "Suivi des GM"
     listant, pour chaque GM, sa session/party en cours et ses membres.
     Onglets passes en vertical (casier.js / casier.css).

v1.5.0 | 2026-08-04
   - Cloture de session enrichie : la fenetre ajoute un champ NOTES et un bouton
     "Enregistrer pour plus tard" (brouillon range dans le Casier) en plus de
     "Cloturer et envoyer". XP applique dans les deux cas.
   - Nouveau "Casier de [GM]" (icone dans la barre WestMarch, GM) : tableau de
     bord style livret. Onglet "Rapports a finaliser" (brouillons editables ->
     bouton Cloturer qui envoie le rapport sur Discord) et "Sessions en cours".
     casier.js / casier.css ; brouillons stockes dans le reglage sessionDrafts.
   - session.js refactore : buildSessionEmbed / sendSessionReport / CRUD des
     brouillons exportes et reutilises par le Casier.

v1.4.1 | 2026-08-04
   - Fiche demo du tutoriel : le module cree automatiquement au 1er chargement GM
     une fiche PJ dediee "Aventurier d exemple (Tutoriel)" (dossier Tutoriel,
     lecture pour tous). Le tutoriel l ouvre en priorite, donc il utilise
     toujours la meme fiche. Creation idempotente via tutorialActorCreated.
     Nouveau demoactor.js ; tutorial.js pointe dessus.

v1.4.0 | 2026-08-04
   - Tutoriel : l etape unique du bouton de retrait est scindee en DEUX etapes,
     une par bouton (fa-ban "Bloquer l ajout automatique" et fa-users-slash
     "Retirer de chez tous les joueurs") (tutorial.js).

v1.3.9 | 2026-08-04
   - Liste des joueurs compacte : la barre de recherche est de nouveau DANS le
     cadre du panneau (epinglee sticky en tete de .players-list), pleine largeur,
     fond solide opaque sans coins arrondis : elle ne sort plus du cadre et les
     noms ne transparaissent plus derriere (playerlist.js/.css).

v1.3.8 | 2026-08-04
   - Fiche PJ/PNJ : le bouton unique de retrait est scinde en DEUX boutons dans
     l en-tete : fa-ban "Bloquer l ajout automatique" (toggle des flags, ne
     retire rien) et fa-users-slash "Retirer de chez tous les joueurs" (action
     ponctuelle avec confirmation). relations.js, bestiary.js, tutorial.js.

v1.3.7 | 2026-08-04
   - Liste des joueurs compacte : la barre de recherche est desormais AU-DESSUS
     de la liste (hors de la zone defilante) ; les noms defilent uniquement en
     dessous et ne passent plus derriere la barre (playerlist.js/.css).

v1.3.6 | 2026-08-04
   - Liste des joueurs compacte : la barre de recherche a un fond 100 pourcent
     opaque (les lignes ne transparaissent plus au defilement), z-index releve,
     ombrage, et padding-haut de la liste supprime (playerlist.css).

v1.3.5 | 2026-08-04
   - Liste des joueurs compacte : correctifs. Barre de recherche epinglee A
     L INTERIEUR de la liste (sticky), hauteur forcee en !important (~4 lignes),
     filtrage base sur data-user-id (fonctionne en v13) (playerlist.js/.css).

v1.3.4 | 2026-08-04
   - Nouvelle option Toolkit "Liste des joueurs compacte + recherche" : limite
     la liste des joueurs a ~4 lignes (defilement) et ajoute une barre de
     recherche pour filtrer par nom (playerlist.js / playerlist.css).

v1.3.3 | 2026-08-04
   - Fenetre d infos de connexion : le compteur "Documents charges" exclut
     desormais le bruit (messages du chat, reglages, dossiers, utilisateurs,
     combats) et ne compte que le contenu (acteurs, objets, journaux, scenes,
     macros, tables, cartes, playlists) (connstats.js).

v1.3.2 | 2026-08-04
   - Fenetre d infos de connexion : ajout du nombre de documents charges (somme
     des collections de monde) en plus des assets (connstats.js).

v1.3.1 | 2026-08-04
   - Nouvelle fonctionnalite "Pause de party" (categorie Systeme de Party) :
     remplace le pause global natif. Le GM met SA party en pause (bandeau +
     blocage du deplacement de ses joueurs non-GM), sans affecter les autres
     partys. Detourne game.togglePause (bouton + raccourci) et masque
     l indicateur PAUSED natif. Etat partage via le reglage de monde
     partyPauseState (partypause.js / partypause.css). Reglage enablePartyPause,
     necessite un rechargement.

v1.3.0 | 2026-08-04
   - Fenetre d infos de connexion : ajout du nombre d assets charges (ressources
     recuperees par le navigateur, via Resource Timing) (connstats.js).

v1.2.9 | 2026-08-04
   - Fenetre d infos de connexion : disparition auto reglee a 7 s (au lieu de
     12 s). Croix de fermeture en haut a droite inchangee (connstats.js).

v1.2.8 | 2026-08-04
   - Nouvelle fonctionnalite Toolkit "Fenetre d infos de connexion" : au
     chargement, petite fenetre en haut au centre affichant le temps de
     connexion, le nombre de modules actifs et la duree moyenne de connexion
     (historique local, 20 dernieres sessions). Reglage enableConnStats,
     disparition auto apres 12 s (connstats.js / connstats.css).

v1.2.7 | 2026-08-04
   - Onglet Relations restyle dans le meme theme fantasy dore que le Bestiaire :
     barre de titre a filet dore + police Modesto, recherche Bookinsanity, noms
     en serif, filets dores sur les lignes et en-tetes de section (relations.js,
     relations.css).

v1.2.6 | 2026-08-04
   - Nouvelle option "Masquer la barre de macros (GM)", independante de
     l option joueurs. Chaque utilisateur applique le reglage de son role
     (hotbar.js / settings.js, categorie Toolkit).

v1.2.5 | 2026-08-04
   - Fenetre d attribution d XP : la liste des PJ se base desormais sur les
     membres REELS de la party (flags persistants) et non sur sessionData, qui
     se vide au rechargement de Foundry. La cloture fonctionne aussi apres un
     rechargement (party retrouvee via le flag du GM). Le rapport retombe sur
     les membres actuels si le snapshot de session est vide (session.js).

v1.2.4 | 2026-08-04
   - Bouton tutoriel : le hook getSceneControlButtons est desormais toujours
     enregistre et verifie tutoEnabled en interne (toolbar.js / index.js), au
     lieu d etre gate a l init. Corrige la disparition de l icone "?" du groupe
     WestMarch apres un basculement de la case Active du Tutoriel.

v1.2.3 | 2026-08-04
   - "Clore la session" ouvre desormais une fenetre d attribution d XP : un
     champ "XP pour tous" qui remplit tous les PJ, plus un champ par PJ pour
     ajuster individuellement. L XP est ajoute a chaque acteur puis compte comme
     gain dans le rapport. Fermer la fenetre annule la cloture (session.js).

v1.2.2 | 2026-08-04
   - Blocage de mouvement hors tour désormais NATIF (combat.js, hook
     preUpdateToken) : pendant le combat de sa party, un joueur ne peut
     déplacer son token que quand c'est son tour ; le combat d'une autre
     party n'affecte jamais ses joueurs. Nouveau setting "enableCombatTurnLock".
   - Monk's TokenBar n'est plus utilisé ni recommandé (retiré de
     relationships.recommends et des dépendances du readme). L'ancien
     contournement via le flag monks-tokenbar.movement est supprimé.

v1.2.1 | 2026-08-04
   - module.json : ajout du champ "relationships". dnd5e en prérequis (requires),
     et midi-qol, MEJ, Simple Calendar, lib-wrapper, monks-tokenbar en recommandés
     (recommends). À l activation du module, Foundry propose d activer ces
     dépendances (obligatoire pour dnd5e, optionnel pour les autres).

v1.2.0 | 2026-08-04
   - Cases « Activé » ajoutées aussi à Temps morts et Tutoriel : nouveaux
     interrupteurs maîtres tmEnabled / tutoEnabled qui coupent toute la feature
     (bouton sablier + bouton GM pour TM ; bouton ? + fenêtre de bienvenue pour
     le tutoriel). Rechargement requis.

v1.1.9 | 2026-08-04
   - Config : case à cocher « Activé » ajoutée à côté du nom des catégories à
     interrupteur maître (Party, Relations, Bestiaire, Carnet, Carte, Midi) pour
     activer/désactiver la fonctionnalité sans ouvrir la fenêtre. Invite de
     rechargement pour les réglages qui le nécessitent.

v1.1.8 | 2026-08-04
   - Tutoriel : navigation par catégorie ajoutée dans les coins de la bulle 
     « Retour » (haut-gauche : début de la catégorie, puis catégorie précédente)
     et « Suivant » (haut-droite : catégorie suivante). Les boutons Précédent/
     Suivant du bas restent pour naviguer étape par étape.

v1.1.7 | 2026-08-04
   - Onglet Bestiaire stylisé (fantasy) : titre en Modesto Condensed doré, noms
     de créatures en serif (Bookinsanity), filets dorés dégradés au lieu des traits
     gris, accents chauds au survol.

v1.1.6 | 2026-08-04
   - Barre de contrôle du chat : tous les boutons (modes de jet, export/flush,
     boutons party) uniformisés  même taille, bordure, fond, rayon et écart,
     avec survol/actif orange cohérent.

v1.1.5 | 2026-08-04
   - Boutons de gestion party du chat (effacer / importer) : remis sur une seule
     ligne à la fin de la rangée native. Retrait du forçage flex-wrap + séparateur
     qui créait une 2e ligne et faisait déborder les boutons sur la carte.

v1.1.4 | 2026-08-04
   - Onglets de chat (IC / Autre / OOC) refaits : vraie barre horizontale propre
     (segments pleine largeur, onglet actif surligné, pastille de notif dans le
     bouton) au lieu des icônes rondes flottantes. Template + CSS revus.

v1.1.3 | 2026-08-04
   - Fix éditeur grimoire : la zone d'écriture remplit désormais toute la hauteur
     du dialog (plus de grand vide de parchemin sous les boutons).

v1.1.2 | 2026-08-04
   - Éditeur de notes (Carnet) habillé en "grimoire" : page de parchemin vieilli
     (taches, dégradé, bords assombris), encre sépia, en-tête cuir, titres à
     l'encre rouge/brune, plume plus grande. Classe .carnet-grimoire sur le
     dialog + styles dans carnet.css.

v1.1.1 | 2026-08-04
   - Éditeur de notes (Carnet) : police par défaut "Enchanted Land" (fournie
     dans fonts/EnchantedLand.otf, enregistrée via module.json + CSS), appliquée
     à l'édition et à l'affichage des notes. Repli Signika si absente.

v1.1.0 | 2026-08-04
   - Boutons "Ajouter" de Relations et Bestiaire harmonisés avec le style doré
     des boutons Carnet & Expéditions (retrait du style gris inline, style CSS).

v1.0.9 | 2026-08-04
   - Fix chat : le template des onglets IC/OOC/Autre n'avait pas été copié lors
     de la fusion et le chemin pointait encore vers "modules/westmarch/...". Le
     chat restait bloqué sur l'onglet IC et masquait les cartes de jets (type
     OTHER). Template recréé, chemin corrigé, et les onglets sont désormais
     conditionnés au réglage "Filtrage du chat par party" (désactivable).

v1.0.8 | 2026-08-03
   - Bestiaire : détection des créatures fiabilisée. En plus du lien compendium
     et de compendiumSource, ajout d'un repli par nom (l'acteur du token
     correspond à une entrée du compendium, via son index mis en cache) — la
     détection marche quelle que soit la façon dont le token a été posé.

v1.0.7 | 2026-08-03
   - Relations : retrait du bouton "Ajouter une relation" de l'état vide de
     l'onglet (le bouton "+ Ajouter" du bandeau, GM, reste inchangé).

v1.0.6 | 2026-08-03
   - Fix : les boutons de configuration n'apparaissaient pas (module absent de
     la liste des réglages). registerMenu exige un type sous-classe de
     FormApplication/ApplicationV2 ; le launcher des catégories étend désormais
     ApplicationV2.

v1.0.5 | 2026-08-03
   - Temps morts entièrement paramétrable (nouvelle catégorie "Temps morts") :
     valeurs (base, bonus maîtrise/expertise/outils, mod de carac, seuil du jet
     d20), formules éditables (gain journalier, coût/durée de craft non-magique,
     évaluées en sécurité côté GM) et tables (parchemins 0→9, objets magiques par
     rareté) éditées en champs structurés. Les labels de l'UI reflètent les
     valeurs configurées. Défauts = anciennes règles (aucun changement si non
     modifié).

v1.0.4 | 2026-08-03
   - Bestiaire : utilise désormais uniquement le compendium des créatures
     (réglage "Compendium des créatures"). Le dossier de créatures est abandonné
     (réglage "Dossier des créatures (legacy)" retiré). La détection auto
     reconnaît aussi les acteurs importés depuis ce compendium (compendiumSource).

v1.0.3 | 2026-08-03
   - Rapport de session refondu : plus de "Create Party with Log" ni de journaux
     auto. Le "Create Party" normal démarre le suivi ; "Clore la session" envoie
     le récap (même contenu qu'avant : joueurs/XP, ennemis, PNJ, objets) sur un
     webhook Discord (nouveau réglage "URL du Webhook Discord (rapport de session)"
     dans la section Système de Party).

v1.0.2 | 2026-08-03
   - Config du module refondue en menus par catégorie : chaque grande section
     (Party, Serveur, Toolkit, Fiche PJ, Carte, Midi, Tutoriel) est un bouton
     "Configurer" qui ouvre une fenêtre dédiée. Tous les réglages passent en
     config:false et sont édités via ces fenêtres (registerMenu + DialogV2).

v1.0.1 | 2026-08-03
   - Retrait de la fonctionnalité Webhook Discord (chat IC par scène) et de la
     lib TurndownService associée.
   - Retrait des mentions de l ancien nom du serveur (branding). Les identifiants legacy des
     anciens modules sont conservés uniquement pour la migration des données.
   - Ajout : masquage de la barre de macros pour les joueurs (réglage Toolkit,
     "enableHideHotbar", live, GM exclu).

v1.0.0 | 2026-08-03
   Fusion initiale des 9 modules Soruta en un module unique
   "soruta-completed-westmarch", ciblé Foundry VTT v14.
   - Namespace unique pour tous les settings et flags.
   - Fiche PJ unifiée : une seule sous-classe compose Relations, Bestiaire,
     Carnet et Expéditions (fin de la cascade de fiches entre modules).
   - Migration automatique et non destructive des données des anciens modules
     au premier lancement (settings + flags de tous les types de documents),
     avec remappage des clés en collision (list → relationsList / bestiaryList).
   - Barre WestMarch, sockets/queries et hooks inter-features conservés.
